using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace TrajectoryEditor
{
    public sealed class TrajectoryPreviewPanel : Control
    {
        private TrajectoryConfig _config = new TrajectoryConfig();

        public TrajectoryPreviewPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.FromArgb(20, 24, 31);
        }

        public void SetConfig(TrajectoryConfig config)
        {
            _config = config ?? new TrajectoryConfig();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle r = ClientRectangle;
            if (r.Width < 120 || r.Height < 120)
                return;

            using var bgBrush = new SolidBrush(Color.FromArgb(20, 24, 31));
            g.FillRectangle(bgBrush, r);

            using var titleFont = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            using var smallFont = new Font("Segoe UI", 8f, FontStyle.Regular);
            using var labelBrush = new SolidBrush(Color.FromArgb(220, 228, 238));
            using var mutedBrush = new SolidBrush(Color.FromArgb(145, 158, 175));

            g.DrawString("2D-превью профилей траекторий", titleFont, labelBrush, 10f, 8f);

            // Верхний график: Артиллерия (мин/макс), Миномёт (мин/макс) и Крылатая ракета
            int topH = (int)((r.Height - 40) * 0.50f);
            Rectangle topRect = new Rectangle(12, 32, r.Width - 24, Math.Max(80, topH - 8));
            Rectangle botRect = new Rectangle(12, topRect.Bottom + 24, r.Width - 24, Math.Max(80, r.Bottom - topRect.Bottom - 36));

            DrawTacticalArcs(g, topRect, smallFont, labelBrush, mutedBrush);
            DrawBallisticAndCruise(g, botRect, smallFont, labelBrush, mutedBrush);
        }

        private void DrawTacticalArcs(Graphics g, Rectangle area, Font font, Brush textBrush, Brush mutedBrush)
        {
            using var boxBrush = new SolidBrush(Color.FromArgb(28, 33, 42));
            using var borderPen = new Pen(Color.FromArgb(55, 64, 80));
            using var gridPen = new Pen(Color.FromArgb(40, 48, 60)) { DashStyle = DashStyle.Dot };

            g.FillRectangle(boxBrush, area);
            g.DrawRectangle(borderPen, area);

            int padL = 38;
            int padR = 14;
            int padT = 22;
            int padB = 22;
            int plotW = Math.Max(40, area.Width - padL - padR);
            int plotH = Math.Max(40, area.Height - padT - padB);
            int x0 = area.Left + padL;
            int y0 = area.Bottom - padB;

            float refDist = Math.Max(
                100f,
                Math.Max(_config.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE, _config.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE));
            float maxApogee = Math.Max(
                50f,
                Math.Max(
                    Math.Max(_config.MAX_ARTILLERY_SHOT_APOGEE, _config.MIN_ARTILLERY_SHOT_APOGEE),
                    Math.Max(_config.MAX_MORTAR_SHOT_APOGEE, _config.MIN_MORTAR_SHOT_APOGEE)));
            maxApogee = Math.Max(maxApogee, _config.CRUISE_MISSILE_TARGET_HEIGHT * 1.4f) * 1.15f;

            for (int i = 1; i <= 3; i++)
            {
                float py = y0 - plotH * (i / 4f);
                g.DrawLine(gridPen, x0, py, x0 + plotW, py);
                string hLabel = $"{(int)Math.Round(maxApogee * (i / 4f))}м";
                g.DrawString(hLabel, font, mutedBrush, area.Left + 3f, py - 7f);
            }

            g.DrawLine(Pens.Gray, x0, y0, x0 + plotW, y0);
            g.DrawLine(Pens.Gray, x0, y0 - plotH, x0, y0);

            float peakFrac = _config.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE > 1f
                ? Math.Clamp(_config.MAX_ARTILLERY_SHOT_APOGEE_DISTANCE / _config.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE, 0.15f, 0.9f)
                : 0.65f;

            // Artillery Max & Min
            DrawSkewedArc(g, x0, y0, plotW, plotH, _config.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE / refDist, _config.MAX_ARTILLERY_SHOT_APOGEE / maxApogee, peakFrac, Color.FromArgb(255, 180, 65), 2f, DashStyle.Solid);
            DrawSkewedArc(g, x0, y0, plotW, plotH, Math.Max(0.08f, _config.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE / refDist), _config.MIN_ARTILLERY_SHOT_APOGEE / maxApogee, peakFrac, Color.FromArgb(255, 180, 65), 1.3f, DashStyle.Dash);

            // Mortar Max & Min
            DrawSkewedArc(g, x0, y0, plotW, plotH, _config.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE / refDist, _config.MAX_MORTAR_SHOT_APOGEE / maxApogee, 0.55f, Color.FromArgb(86, 200, 255), 2f, DashStyle.Solid);
            DrawSkewedArc(g, x0, y0, plotW, plotH, Math.Max(0.10f, _config.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE / refDist), _config.MIN_MORTAR_SHOT_APOGEE / maxApogee, 0.50f, Color.FromArgb(86, 200, 255), 1.3f, DashStyle.Dash);

            // Cruise missile profile
            float cruiseY = y0 - Math.Clamp(_config.CRUISE_MISSILE_TARGET_HEIGHT / maxApogee, 0.02f, 0.95f) * plotH;
            float diveAngleRad = Math.Clamp(_config.CRUISE_MISSILE_DIVE_ANGLE, 5f, 89f) * (float)(Math.PI / 180.0);
            float diveDxPx = (_config.CRUISE_MISSILE_TARGET_HEIGHT / maxApogee) * plotH / (float)Math.Tan(diveAngleRad);
            float kneeX = Math.Max(x0 + plotW * 0.25f, x0 + plotW - diveDxPx);
            using (var cruisePen = new Pen(Color.FromArgb(120, 235, 150), 2f))
            {
                g.DrawLine(cruisePen, x0, cruiseY, kneeX, cruiseY);
                g.DrawLine(cruisePen, kneeX, cruiseY, x0 + plotW, y0);
            }

            g.DrawString($"Арт (20/40) / Миномёт (30) / Крылатая (200) | Эталон {refDist:0}м", font, textBrush, area.Left + 8f, area.Top + 4f);
            g.DrawString("Оранжев: Арт (сплош. max / пунктир min)  |  Голуб: Миномёт  |  Зелён: Крылатая", font, mutedBrush, x0, area.Bottom - 17f);
        }

        private void DrawBallisticAndCruise(Graphics g, Rectangle area, Font font, Brush textBrush, Brush mutedBrush)
        {
            using var boxBrush = new SolidBrush(Color.FromArgb(28, 33, 42));
            using var borderPen = new Pen(Color.FromArgb(55, 64, 80));
            using var gridPen = new Pen(Color.FromArgb(40, 48, 60)) { DashStyle = DashStyle.Dot };

            g.FillRectangle(boxBrush, area);
            g.DrawRectangle(borderPen, area);

            int padL = 44;
            int padR = 14;
            int padT = 24;
            int padB = 22;
            int plotW = Math.Max(40, area.Width - padL - padR);
            int plotH = Math.Max(40, area.Height - padT - padB);
            int x0 = area.Left + padL;
            int y0 = area.Bottom - padB;

            float apo = Math.Max(100f, _config.BALLISTIC_MISSILES_APOAPSIS);
            float maxY = apo * 1.15f;

            for (int i = 1; i <= 3; i++)
            {
                float py = y0 - plotH * (i / 4f);
                g.DrawLine(gridPen, x0, py, x0 + plotW, py);
                g.DrawString($"{(int)Math.Round(maxY * (i / 4f))}м", font, mutedBrush, area.Left + 3f, py - 7f);
            }

            g.DrawLine(Pens.Gray, x0, y0, x0 + plotW, y0);
            g.DrawLine(Pens.Gray, x0, y0 - plotH, x0, y0);

            float tMin = Math.Clamp(_config.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION, 0f, 1f);
            float tMax = Math.Clamp(_config.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION, tMin, 1f);

            const int steps = 80;
            PointF[] pts = new PointF[steps + 1];
            for (int i = 0; i <= steps; i++)
            {
                float t = i / (float)steps;
                float hNorm = 4f * t * (1f - t) * (apo / maxY);
                pts[i] = new PointF(x0 + t * plotW, y0 - hNorm * plotH);
            }

            using (var basePen = new Pen(Color.FromArgb(145, 130, 255), 2f))
                g.DrawLines(basePen, pts);

            int iStart = (int)Math.Floor(tMin * steps);
            int iEnd = (int)Math.Ceiling(tMax * steps);
            if (iEnd > iStart)
            {
                PointF[] interceptPts = new PointF[iEnd - iStart + 1];
                Array.Copy(pts, iStart, interceptPts, 0, interceptPts.Length);
                using var redPen = new Pen(Color.FromArgb(255, 95, 110), 3.2f);
                g.DrawLines(redPen, interceptPts);
            }

            g.DrawString($"Баллистическая (300): апогей {apo:0}м | Перехват ПРО: {tMin:P0}–{tMax:P0}", font, textBrush, area.Left + 8f, area.Top + 4f);
            g.DrawString("Фиолетовый: траектория  |  Красный участок: окно перехвата ПРО", font, mutedBrush, x0, area.Bottom - 17f);
        }

        private static void DrawSkewedArc(
            Graphics g,
            int x0,
            int y0,
            int plotW,
            int plotH,
            float widthFrac,
            float heightFrac,
            float peakFrac,
            Color color,
            float thickness,
            DashStyle dash)
        {
            widthFrac = Math.Clamp(widthFrac, 0.05f, 1f);
            heightFrac = Math.Clamp(heightFrac, 0f, 1f);

            const int steps = 48;
            PointF[] pts = new PointF[steps + 1];
            double p = Math.Log(0.5) / Math.Log(Math.Clamp(peakFrac, 0.1f, 0.9f));

            for (int i = 0; i <= steps; i++)
            {
                double u = i / (double)steps;
                double s = Math.Pow(u, p);
                float yNorm = (float)(4.0 * s * (1.0 - s)) * heightFrac;
                pts[i] = new PointF(x0 + (float)u * widthFrac * plotW, y0 - yNorm * plotH);
            }

            using var pen = new Pen(color, thickness) { DashStyle = dash };
            g.DrawLines(pen, pts);
        }
    }
}
