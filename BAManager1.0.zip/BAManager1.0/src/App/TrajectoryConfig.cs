using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace TrajectoryEditor
{
    public sealed class CurveKeyDto
    {
        public float Time { get; set; }
        public float Value { get; set; }
        public float InTangent { get; set; }
        public float OutTangent { get; set; }

        public CurveKeyDto Clone() => new CurveKeyDto
        {
            Time = Time,
            Value = Value,
            InTangent = InTangent,
            OutTangent = OutTangent
        };
    }

    public sealed class PlanesSection
    {
        public float BombingStartTimeOffset { get; set; } = 3f;
        public float BombingStartTimeOffsetHighDrag { get; set; } = 3f;
        public float BombDropOffset { get; set; } = -25f;
        public float BombDropOffsetHighDrag { get; set; } = -25f;
        public float BombDropOffsetAmmoAoeMult { get; set; } = 0.8f;
        public bool EnableStratBomberCircling { get; set; } = true;

        public float StrafeMinLength { get; set; } = 100f;
        public float StrafeMaxLength { get; set; } = 400f;
        public float StrafeSearchRadius { get; set; } = 50f;
        public float StrafeStartTimeOffset { get; set; } = 1f;
        public float StrafeWeaponPointOffset { get; set; } = 1.75f;

        public float PrecisionMinAllowedAngle { get; set; } = 10f;
        public ushort PrecisionFlyAwayExtraDistance { get; set; } = 300;

        public float HighAltitude { get; set; } = 400f;
        public float LowAltitude { get; set; } = 100f;
        public ushort FuelRedZoneBaseValue { get; set; } = 20;
        public float FuelOrangeZoneSizeRatio { get; set; } = 1f;
        public uint FuelOutChance { get; set; } = 100u;
        public uint DeathChance { get; set; } = 0u;
        public float NextPointStepMultiplier { get; set; } = 0.5f;
        public float DecreaseSpeedAngle { get; set; } = 30f;

        public float PlaneVsPlaneStopDistance { get; set; } = 200f;
        public float PlaneVsPlaneEscapeDistance { get; set; } = 120f;
        public float PlaneVsHeliDiveAngle { get; set; } = 15f;
        public float PlaneVsHeliNoseUpExtraHeight { get; set; } = 10f;

        public float DEATH_MASS { get; set; } = 50f;
        public float DEATH_DRAG { get; set; } = 0.03f;
        public float DEATH_ANGULAR_DRAG { get; set; } = 100f;
        public float DEATH_ENGINE_POWER_MULT { get; set; } = 2f;
        public float DEATH_ROTATE_POWER_MULT { get; set; } = 0.15f;
        public float DEATH_START_EPOWER_MULT { get; set; } = 1.5f;
        public float DEATH_START_RPOWER_MULT { get; set; } = 0f;
        public float DEATH_BLAST_POWER_MULT { get; set; } = 50f;
    }

    public sealed class SupplySection
    {
        public int SupplyValueBought { get; set; } = 10;
        public int SupplyExchangeRate { get; set; } = 1000;
        public float ResupplyRadius { get; set; } = 75f;
        public float AmmoCostMultiplier { get; set; } = 4f;
        public float RepairRate { get; set; } = 0.35f;
        public float RepairCost { get; set; } = 25f;
        public float HealingCost { get; set; } = 0.5f;
        public float HealingRate { get; set; } = 1f;
        public float AbilityResupplyRate { get; set; } = 50f;
        public float AbilityMultiplierHeal { get; set; } = 0.5f;
        public float AbilityMultiplierRepair { get; set; } = 0.5f;
        public float AbilityMultiplierRearm { get; set; } = 0.5f;
        public float ViewDistance { get; set; } = 0f;
        public bool ShowEnemySupplyRadius { get; set; } = true;
    }

    public sealed class CombatFormulasSection
    {
        public float ARMOR_PENETRATION_EFFECTIVENESS { get; set; } = 1f;
        public float MINIMAL_DAMAGE_COEFFICIENT { get; set; } = 0.1f;
        public float HE_ARMOR_EFFECTIVENESS { get; set; } = 1f;
        public float HEAT_CURVE_COEFFICIENT { get; set; } = 2f;
        public float CQCTick { get; set; } = 0.3f;
        public float CQCChance { get; set; } = 1f;
        public float PLANES_DAMAGE_SCORE_MULTIPLIER { get; set; } = 1f;
        public float RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES { get; set; } = 1f;
        public float RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES { get; set; } = 1f;

        public float SEAD_SCORE_MULTIPLIER { get; set; } = 0.99f;
        public float MINIMAL_CHANCE_TO_KILL { get; set; } = 0.8f;
        public float GUIDED_SELECTION_DAMAGE_TRESHHOLD { get; set; } = 1.4f;
        public float APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD { get; set; } = 5f;
        public bool GUIDED_IGNORE_UNGUIDED_ON_PLANES { get; set; } = true;
        public bool GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES { get; set; } = true;
        public bool ACTIVE_APS_IGNORES_ONE_MISSILE { get; set; } = true;
        public bool HP_LIMIT_WEAPON_SCORE { get; set; } = true;
        public bool PRIORITIZE_ONE_SHOT_TARGETS { get; set; } = true;
        public bool PREVENT_GUIDED_OVERKILL { get; set; } = true;
        public float MISSILE_OVERKILL_CLEAR_DELAY { get; set; } = 0.25f;
        public bool FORCE_MISSILE_MISS_DAMAGE { get; set; } = true;
        public float MISSILE_MISS_OVERKILL_CLEAR_DELAY { get; set; } = 1f;
        public int MAX_FLARES_COUNT_MISSILE_INITIAL { get; set; } = 100;
        public int MAX_FLARES_COUNT_MISSILE_REROLL { get; set; } = 1;
        public float AUTOFLARES_PLANES_DELAY { get; set; } = 1.5f;
        public float AUTOFLARES_HELICOPTERS_DELAY { get; set; } = 0.5f;
        public bool AUTOSMOKE_TRIGGER_BY_GUNS { get; set; } = false;
        public bool AUTOSMOKE_TRIGGER_BY_MISSILES { get; set; } = true;
        public float AUTOSMOKE_DELAY_MIN { get; set; } = 3f;
        public float AUTOSMOKE_DELAY_MAX { get; set; } = 5f;
        public bool AUTOSMOKE_AI_TRIGGER_BY_GUNS { get; set; } = true;
        public bool AUTOSMOKE_AI_TRIGGER_BY_MISSILES { get; set; } = true;
        public float AUTOSMOKE_AI_DELAY_MIN { get; set; } = 2f;
        public float AUTOSMOKE_AI_DELAY_MAX { get; set; } = 8f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY { get; set; } = 0.25f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM { get; set; } = 0.5f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD { get; set; } = 0.75f;
        public float MAX_TIME_WITHOUT_TARGET { get; set; } = 1f;
    }

    public sealed class GameConfigSection
    {
        public float DefaultPlayerMoney { get; set; } = 1000f;
        public float DefaultIncomePerMin { get; set; } = 300f;
        public float UpkeepMultiplier { get; set; } = 1.66667f;
        public float PlanesUpkeepMultiplier { get; set; } = 0f;
        public float DeadUnitsValueMultiplier { get; set; } = 0f;
        public float DeckCategoryValueMargin { get; set; } = 0.1f;

        public float DespawnDelaySec { get; set; } = 5f;
        public float RefundMultiplier { get; set; } = 1f;
        public float RefundLostAmmoTimeMultiplier { get; set; } = 0f;
        public float RepurchaseDelayFloor { get; set; } = 30f;
        public float RepurchaseDelayMultiplier { get; set; } = 0.5f;
        public float PlanesRefundFloor { get; set; } = 60f;
        public float PlanesRefundHPMultiplier { get; set; } = 0.5f;
        public float PlanesRefundAmmoCoeff_K { get; set; } = 1f;
        public float PlanesRefundAmmoCoeff_P { get; set; } = 5f;
        public bool PlanesDeathIsMultiplierOfRefund { get; set; } = true;
        public float PlanesDeathRefundMultiplier { get; set; } = 2.5f;
        public float MinimumRefundPercent { get; set; } = 20f;
        public float MaximumRefundPercent { get; set; } = 90f;
        public float HealthCostMultiplier { get; set; } = 0.5f;
        public bool ResurrectionEnabled { get; set; } = true;
        public float ResurrectDelayFloor { get; set; } = 420f;
        public float ResurrectDelayMultiplier { get; set; } = 1.5f;
        public float PlanesDeathPenalty { get; set; } = 0f;

        public float PhysicsElasticity { get; set; } = 0.275f;
        public float CoverSnapDistance { get; set; } = 8f;
        public float CoverSnapSingleUnitModifier { get; set; } = 1f;
        public float SprintSpeed { get; set; } = 10f;
        public float GlobalForestSpeedMultiplier { get; set; } = 0.5f;
        public float InfantryForestSpeedMultiplier { get; set; } = 1f;
        public float HelicopterLowMultiplier { get; set; } = 0.5f;
        public float HelicopterCrashLowAltitude { get; set; } = 20f;
        public uint HouseUnloadDelay { get; set; } = 3u;
        public float TransportUnloadDelay { get; set; } = 0f;
        public float HouseUnloadSprintMultiplier { get; set; } = 1.5f;
        public int OnTransportDeathCargoForcedStressPercentage { get; set; } = 100;
        public int OnTransportUnloadCargoForcedStressPercentage { get; set; } = 50;
        public int OnTransportDeathCargoKillFloor { get; set; } = 30;
        public float OnTransportDeathCargoKillMultiplier { get; set; } = 1f;
        public int OnTransportDeathCargoKillHLFloor { get; set; } = 50;
        public float OnTransportDeathCargoKillHLMultiplier { get; set; } = 0.5f;
        public int OnTransportDeathCargoKillHHFloor { get; set; } = 100;
        public float OnTransportDeathCargoKillHHMultiplier { get; set; } = 0f;
        public int OnTransportDeathCargoKillAirFloor { get; set; } = 100;
        public float OnTransportDeathCargoKillAirMultiplier { get; set; } = 0f;
        public int OnBuildingDestroyPrecentage { get; set; } = 60;
        public uint TransportLoadDistance { get; set; } = 10u;
        public uint TransportLoadDistanceWithAnimation { get; set; } = 18u;
        public float WaitingTimeForLoadingInQueue { get; set; } = 0.3f;
        public float TransportLoadingHelpPointsOffset { get; set; } = 0.6f;
        public float MaxTimeForLoadOneUnit { get; set; } = 5f;
    }

    public sealed class FogOfWarSection
    {
        public float MinimumDetectionDistance { get; set; } = 45f;
        public float MaxShootableForestDistance { get; set; } = 45f;
        public float LaserForestMaxRange { get; set; } = 45f;
        public float LaserOwnForestRange { get; set; } = 25f;
        public float FlashReduction { get; set; } = 0.15f;
        public float MaxFlashValue { get; set; } = 4.5f;
        public float MaxAntiVisible { get; set; } = 1.5f;
        public float SpottedPenalty { get; set; } = 2f;
        public float SpottedPenaltyBuildings { get; set; } = 2f;
        public float SneakMinAntivisible { get; set; } = 0.2f;
    }

    public sealed class BuffsSection
    {
        public float ShockedLevelMultiplier { get; set; } = 0.5f;
        public float PanickedLevelMultiplier { get; set; } = 0.8f;
        public float ShockedLevelMultiplierInfantry { get; set; } = 0.4f;
        public float PanickedLevelMultiplierInfantry { get; set; } = 0.8f;
        public float StressRecoveryMultiplier { get; set; } = 1f;
        public float StressDamageModThreshold { get; set; } = 36f;
        public float CriticalBaseProbability { get; set; } = 0.02f;
        public int RedCritsActivationThreshold { get; set; } = 2;
        public float MinorAimTimeMultiplier { get; set; } = 1.5f;
        public float MajorAimTimeMultiplier { get; set; } = 2f;
        public float MinorOpticsMultiplier { get; set; } = 0.66f;
        public float MajorOpticsMultiplier { get; set; } = 0.33f;
        public float MinorMobilityMultiplier { get; set; } = 0.75f;
        public float MinorMobilityMultiplierRotation { get; set; } = 0.5f;
        public float MinorDispersionMultiplier { get; set; } = 1.15f;
        public float MajorDispersionMultiplier { get; set; } = 1.52f;
        public float MinorLoadingMultiplier { get; set; } = 1.5f;
        public float MajorLoadingMultiplier { get; set; } = 2f;
    }

    public sealed class BuildingsSection
    {
        public int BuildingDamageThreshold { get; set; } = 5;
        public float DamageModifierFloor { get; set; } = 0.18f;
        public float DamageModifierPerSoldier { get; set; } = 0.02f;
        public float HitColliderReduction { get; set; } = 1f;
    }

    public sealed class InfantrySection
    {
        public uint BaseSquadSize { get; set; } = 1u;
        public float InfantryDeathTime { get; set; } = 30f;
        public float HorizontalTurretRotationSpeed { get; set; } = 180f;
        public float StartMovingMaxDelay { get; set; } = 0.5f;
        public float RunSpeed { get; set; } = 5f;
        public float SprintSpeed { get; set; } = 10f;
        public float KneelRunSpeed { get; set; } = 3f;
        public float ProneRunSpeed { get; set; } = 1f;
        public float ProneSprintSpeed { get; set; } = 2f;
        public float RotationSpeed { get; set; } = 180f;
        public float ShootAimRotationSpeed { get; set; } = 11f;
        public float DistanceForSprint { get; set; } = 2f;
        public float DistanceForSoldierStop { get; set; } = 0.2f;
    }

    public sealed class CustomFormulaDto
    {
        public bool Enabled { get; set; }
        public string Expression { get; set; } = string.Empty;
    }

    public sealed class CustomTrajectoryDto
    {
        public int Id { get; set; } = 1000;
        public string Name { get; set; } = "Новая траектория";
        public string Description { get; set; } = string.Empty;
        public int BaseTrajectoryType { get; set; } = 20;

        public bool UseCustomHeightFormula { get; set; } = true;
        public string HeightFormula { get; set; } = "apogee * 4 * t * (1 - t)";
        public float MinRefDistance { get; set; } = 100f;
        public float MinApogee { get; set; } = 40f;
        public float MaxRefDistance { get; set; } = 2000f;
        public float MaxApogee { get; set; } = 450f;

        public float GravityMultiplier { get; set; } = 1f;
        public float SpeedMultiplier { get; set; } = 1f;
        public float AccelerationMultiplier { get; set; } = 1f;
        public float BurnTimeMultiplier { get; set; } = 1f;
        public float RotationSpeedMultiplier { get; set; } = 1f;

        public int LoftHeightOverride { get; set; } = -1;
        public int LoftAngleOverride { get; set; } = -1;
        public bool ForceTopAttack { get; set; }
        public bool AllowPrecisionStrike { get; set; }

        public CustomTrajectoryDto Clone(int newId, string newName) => new CustomTrajectoryDto
        {
            Id = newId,
            Name = newName,
            Description = Description,
            BaseTrajectoryType = BaseTrajectoryType,
            UseCustomHeightFormula = UseCustomHeightFormula,
            HeightFormula = HeightFormula,
            MinRefDistance = MinRefDistance,
            MinApogee = MinApogee,
            MaxRefDistance = MaxRefDistance,
            MaxApogee = MaxApogee,
            GravityMultiplier = GravityMultiplier,
            SpeedMultiplier = SpeedMultiplier,
            AccelerationMultiplier = AccelerationMultiplier,
            BurnTimeMultiplier = BurnTimeMultiplier,
            RotationSpeedMultiplier = RotationSpeedMultiplier,
            LoftHeightOverride = LoftHeightOverride,
            LoftAngleOverride = LoftAngleOverride,
            ForceTopAttack = ForceTopAttack,
            AllowPrecisionStrike = AllowPrecisionStrike
        };

        public override string ToString() => $"#{Id} — {Name} [{TrajectoryCatalog.FormatTrajectoryShort(BaseTrajectoryType)}]";
    }

    public sealed class WeaponTrajectoryAssignmentDto
    {
        public int AmmunitionId { get; set; }
        public string AmmunitionName { get; set; } = string.Empty;
        public string WeaponHint { get; set; } = string.Empty;
        public int CustomTrajectoryId { get; set; }
        public bool OverrideBaseTrajectoryType { get; set; } = true;
    }

    public sealed class TrajectoryConfig
    {
        public bool Enabled { get; set; } = true;

        // Общие и DirectShot (10)
        public float G { get; set; } = 70f;
        public float MIN_POINT_DISPERSION { get; set; } = 15f;
        public float MAX_POINT_DISPERSION_MULTIPLIER { get; set; } = 3f;
        public float ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS { get; set; } = 0f;
        public float BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE { get; set; } = 10f;
        public float MAX_WEAPON_AIMING_IMPRECISION { get; set; } = 0.5f;
        public float MAX_WEAPON_AIMING_CHECK_TRESHOLD { get; set; } = 30f;

        // Артиллерия (20), Миномёты (30), РСЗО (40)
        public float MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1000f;
        public float MAX_ARTILLERY_SHOT_APOGEE_DISTANCE { get; set; } = 650f;
        public float MAX_ARTILLERY_SHOT_APOGEE { get; set; } = 250f;
        public float MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE { get; set; } = 100f;
        public float MIN_ARTILLERY_SHOT_APOGEE { get; set; } = 10f;
        public float MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1000f;
        public float MAX_MORTAR_SHOT_APOGEE { get; set; } = 350f;
        public float MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1f;
        public float MIN_MORTAR_SHOT_APOGEE { get; set; } = 400f;
        public List<CurveKeyDto> ARTILLERY_DISPERSION_CDF { get; set; } = DefaultArtilleryCurve();

        // Ракеты (100 / 110 / 120)
        public float START_LEAD_MISSILE_SPEED_PROPORTION { get; set; } = 0.4f;
        public float FULL_LEAD_MISSILE_SPEED_PROPORTION { get; set; } = 0.9f;
        public float MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION { get; set; } = 10f;
        public float MISSILE_DECELERATION_PROPORTION { get; set; } = 0.13f;
        public float MISSILE_DEATH_SPEED_PROPORTION { get; set; } = 0.3f;
        public float LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION { get; set; } = 0.33f;
        public float MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION { get; set; } = 0.2f;
        public float MISSILE_NO_TARGET_SUPPORT_TIME { get; set; } = 2f;
        public float MISSILE_NO_TARGET_SUPPORT_TIME_TG { get; set; } = 0f;
        public bool SEAD_MISSILES_GO_TO_LAST_POSITION { get; set; } = false;
        public float MINIMAL_MISSILE_MISS_DISTANCE { get; set; } = 100f;
        public float MAX_MISSILE_MISS_DISTANCE_PROPORTION { get; set; } = 0.8f;
        public float MAX_MISSILE_MISS_DISTANCE_CAP { get; set; } = 200f;
        public float MISSILE_MISS_ADDITIONAL_CLEARENCE { get; set; } = 10f;
        public float RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN { get; set; } = 0.6f;
        public float RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX { get; set; } = 1.4f;
        public float RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER { get; set; } = 0f;
        public float MISSILE_MERGE_POWER { get; set; } = 1f;
        public byte MISSILE_SWITCH_RULE { get; set; } = 10;

        // Крылатые ракеты (200)
        public float CRUISE_MISSILE_TARGET_HEIGHT { get; set; } = 65f;
        public float CRUISE_MISSILE_DIVE_ANGLE { get; set; } = 60f;
        public float PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE { get; set; } = 30f;
        public float CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT { get; set; } = 1f;
        public int CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION { get; set; } = 15;
        public float[] CRUISE_MISSILE_PID { get; set; } = new[] { 0.2f, 0f, 13f };
        public List<CurveKeyDto> CRUISE_MISSILE_HEIGHTS_COEFFICIENTS { get; set; } = DefaultCruiseCurve();

        // Баллистические ракеты (300)
        public float BALLISTIC_MISSILES_APOAPSIS { get; set; } = 2500f;
        public float INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION { get; set; } = 0.33f;
        public float INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION { get; set; } = 1f;

        // Бомбы (400 / 410)
        public float BOMBS_GRAVITY_MULTIPLYER { get; set; } = 1f;
        public float HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER { get; set; } = 0.5f;
        public float HIGH_DRAG_BOMBS_DECELERATION_PROPORTION { get; set; } = 0.1f;
        public float BOMB_HORIZONTAL_MARGIN { get; set; } = 30f;
        public float BOMB_UPPER_MARGIN { get; set; } = -1f;
        public bool DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN { get; set; } = true;

        // Лазерное планирование (610) и Сорванные ракеты (666)
        public float LASER_MAX_GLIDING_ANGLE { get; set; } = 10f;
        public float LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE { get; set; } = 90f;
        public float MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME { get; set; } = 1.5f;
        public float MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN { get; set; } = 0.4f;
        public float MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX { get; set; } = 1.2f;
        public float SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS { get; set; } = 0f;

        // Новые секции
        public PlanesSection Planes { get; set; } = new PlanesSection();
        public SupplySection Supply { get; set; } = new SupplySection();
        public CombatFormulasSection CombatFormulas { get; set; } = new CombatFormulasSection();
        public GameConfigSection GameConfig { get; set; } = new GameConfigSection();
        public FogOfWarSection FogOfWar { get; set; } = new FogOfWarSection();
        public BuffsSection Buffs { get; set; } = new BuffsSection();
        public BuildingsSection Buildings { get; set; } = new BuildingsSection();
        public InfantrySection Infantry { get; set; } = new InfantrySection();

        // Пользовательские формулы (живой патч) и конструктор траекторий
        public Dictionary<string, CustomFormulaDto> FormulaOverrides { get; set; } = new Dictionary<string, CustomFormulaDto>(StringComparer.Ordinal);
        public List<CustomTrajectoryDto> CustomTrajectories { get; set; } = new List<CustomTrajectoryDto>();
        public List<WeaponTrajectoryAssignmentDto> WeaponTrajectoryAssignments { get; set; } = new List<WeaponTrajectoryAssignmentDto>();
        public List<int> PrecisionStrikeAmmoIds { get; set; } = new List<int>();

        public static List<CurveKeyDto> DefaultArtilleryCurve() => new List<CurveKeyDto>
        {
            new CurveKeyDto { Time = 0f, Value = 0f, InTangent = 2f, OutTangent = 2f },
            new CurveKeyDto { Time = 1f, Value = 1f, InTangent = 0.048455f, OutTangent = 0.048455f }
        };

        public static List<CurveKeyDto> DefaultCruiseCurve() => new List<CurveKeyDto>
        {
            new CurveKeyDto { Time = 0f, Value = 0f, InTangent = 6.60151f, OutTangent = 6.60151f },
            new CurveKeyDto { Time = 0.108248f, Value = 1.00001f, InTangent = 5.42224f, OutTangent = 0.158478f },
            new CurveKeyDto { Time = 1f, Value = 0.05f, InTangent = -0.999213f, OutTangent = -0.999213f }
        };

        private static readonly JsonSerializerOptions JsonOpts = new JsonSerializerOptions
        {
            WriteIndented = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true
        };

        public static TrajectoryConfig LoadOrCreate(string path)
        {
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                TrajectoryConfig loaded = JsonSerializer.Deserialize<TrajectoryConfig>(json, JsonOpts);
                if (loaded != null)
                {
                    Normalize(loaded);
                    return loaded;
                }
            }
            var created = new TrajectoryConfig();
            created.Save(path);
            return created;
        }

        public void Save(string path)
        {
            Normalize(this);
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir))
                Directory.CreateDirectory(dir);
            string json = JsonSerializer.Serialize(this, JsonOpts);
            string tmpPath = path + ".tmp";
            File.WriteAllText(tmpPath, json);
            File.Move(tmpPath, path, overwrite: true);
        }

        private static void Normalize(TrajectoryConfig c)
        {
            if (c.ARTILLERY_DISPERSION_CDF == null || c.ARTILLERY_DISPERSION_CDF.Count == 0)
                c.ARTILLERY_DISPERSION_CDF = DefaultArtilleryCurve();
            if (c.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS == null || c.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS.Count == 0)
                c.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS = DefaultCruiseCurve();
            if (c.CRUISE_MISSILE_PID == null || c.CRUISE_MISSILE_PID.Length < 3)
                c.CRUISE_MISSILE_PID = new[] { 0.2f, 0f, 13f };

            c.Planes ??= new PlanesSection();
            c.Supply ??= new SupplySection();
            c.CombatFormulas ??= new CombatFormulasSection();
            c.GameConfig ??= new GameConfigSection();
            c.FogOfWar ??= new FogOfWarSection();
            c.Buffs ??= new BuffsSection();
            c.Buildings ??= new BuildingsSection();
            c.Infantry ??= new InfantrySection();

            c.FormulaOverrides ??= new Dictionary<string, CustomFormulaDto>(StringComparer.Ordinal);
            c.CustomTrajectories ??= new List<CustomTrajectoryDto>();
            c.CustomTrajectories.RemoveAll(x => x == null);
            c.WeaponTrajectoryAssignments ??= new List<WeaponTrajectoryAssignmentDto>();
            c.WeaponTrajectoryAssignments.RemoveAll(x => x == null);
            c.PrecisionStrikeAmmoIds ??= new List<int>();
            c.PrecisionStrikeAmmoIds = c.PrecisionStrikeAmmoIds.Where(id => id > 0).Distinct().OrderBy(id => id).ToList();
        }
    }

    public enum SettingValueKind
    {
        Float,
        Int,
        UInt,
        UShort,
        Bool,
        SwitchRuleEnum
    }

    public sealed class GlobalSettingMeta
    {
        public string Key { get; }
        public string Category { get; }
        public SettingValueKind Kind { get; }
        public object VanillaValue { get; }
        public string DescriptionRu { get; }
        public Func<TrajectoryConfig, object> Getter { get; }
        public Action<TrajectoryConfig, object> Setter { get; }

        public GlobalSettingMeta(
            string key,
            string category,
            SettingValueKind kind,
            object vanillaValue,
            string descriptionRu,
            Func<TrajectoryConfig, object> getter,
            Action<TrajectoryConfig, object> setter)
        {
            Key = key;
            Category = category;
            Kind = kind;
            VanillaValue = vanillaValue;
            DescriptionRu = descriptionRu;
            Getter = getter;
            Setter = setter;
        }
    }

    public sealed class NamedIntOption
    {
        public int Value { get; }
        public string Label { get; }

        public NamedIntOption(int value, string label)
        {
            Value = value;
            Label = label;
        }

        public override string ToString() => Label;
    }

    public sealed class AmmoFieldMeta
    {
        public string Name { get; }
        public string Group { get; }
        public string Label { get; }
        public bool IsBool { get; }
        public bool IsInt { get; }
        public bool IsTrajectoryEnum { get; }
        public bool IsSeekerEnum { get; }

        public AmmoFieldMeta(
            string name,
            string group,
            string label,
            bool isBool = false,
            bool isInt = false,
            bool isTrajectoryEnum = false,
            bool isSeekerEnum = false)
        {
            Name = name;
            Group = group;
            Label = label;
            IsBool = isBool;
            IsInt = isInt;
            IsTrajectoryEnum = isTrajectoryEnum;
            IsSeekerEnum = isSeekerEnum;
        }
    }

    public static class TrajectoryCatalog
    {
        public const string CatAll = "Все категории";
        public const string CatDirect = "Общие и DirectShot (10)";
        public const string CatArty = "Артиллерия (20), Миномёты (30), РСЗО (40)";
        public const string CatMissile = "Ракеты (100 / 110 / 120)";
        public const string CatCruise = "Крылатые ракеты (200)";
        public const string CatBallistic = "Баллистические ракеты (300)";
        public const string CatBomb = "Бомбы (400 / 410)";
        public const string CatLaserDead = "Лазер (610) и DeadMissile (666)";

        public static readonly string[] Categories =
        {
            CatAll,
            CatDirect,
            CatArty,
            CatMissile,
            CatCruise,
            CatBallistic,
            CatBomb,
            CatLaserDead
        };

        // Категории: Авиация
        public const string PlBombing = "Бомбинг ран (Bombing Run)";
        public const string PlStrafe = "Штурмовой заход (Strafe)";
        public const string PlPrecision = "Пресижен страйк (Precision Strike)";
        public const string PlAltFuel = "Высоты и топливо";
        public const string PlAirCombat = "Воздушный бой и падение";

        public static readonly string[] PlanesCategories =
        {
            CatAll,
            PlBombing,
            PlStrafe,
            PlPrecision,
            PlAltFuel,
            PlAirCombat
        };

        // Категории: Саплай и экономика
        public const string SeSupply = "Цена саплая и логистика";
        public const string SeEconomy = "Экономика и доход";
        public const string SeRefund = "Возврат юнитов (Refund) и респавн";

        public static readonly string[] SupplyEconomyCategories =
        {
            CatAll,
            SeSupply,
            SeEconomy,
            SeRefund
        };

        // Категории: Формулы игры
        public const string GfDamage = "Урон, броня, пробитие и CQC";
        public const string GfTargeting = "ИИ стрельбы, Overkill, ЛТЦ и автодымы";
        public const string GfFow = "Видимость, оптика и лес (FoW)";
        public const string GfBuffs = "Стресс, паника и криты";
        public const string GfBuildings = "Здания и укрытия";
        public const string GfInfantryTransport = "Пехота, скорости и транспорт";

        public static readonly string[] GameFormulaCategories =
        {
            CatAll,
            GfDamage,
            GfTargeting,
            GfFow,
            GfBuffs,
            GfBuildings,
            GfInfantryTransport
        };

        public static readonly IReadOnlyList<NamedIntOption> TrajectoryTypes = new[]
        {
            new NamedIntOption(0, "0 — None (без снаряда)"),
            new NamedIntOption(10, "10 — DirectShot (прямая наводка)"),
            new NamedIntOption(20, "20 — Artillery (гаубичная дуга)"),
            new NamedIntOption(30, "30 — Mortar (миномётная дуга)"),
            new NamedIntOption(40, "40 — MLRS (РСЗО)"),
            new NamedIntOption(100, "100 — PursuitMissile (чистое преследование)"),
            new NamedIntOption(110, "110 — LeadPursuitMissile (частичное упреждение)"),
            new NamedIntOption(120, "120 — LeadMissile (полное упреждение)"),
            new NamedIntOption(200, "200 — CruiseMissile (крылатая)"),
            new NamedIntOption(300, "300 — BallisticMissile (баллистическая)"),
            new NamedIntOption(400, "400 — LowDragBomb (обычная/КАБ бомба)"),
            new NamedIntOption(410, "410 — HighDragBomb (штурмовая тормозная)"),
            new NamedIntOption(600, "600 — LaserMissile (рантайм-лазер ракета)"),
            new NamedIntOption(610, "610 — LaserGuidedFreeFaling (рантайм-лазер бомба/снаряд)"),
            new NamedIntOption(666, "666 — DeadMissile (рантайм сорванная ракета)")
        };

        public static readonly IReadOnlyList<NamedIntOption> SeekerTypes = new[]
        {
            new NamedIntOption(0, "0 — None"),
            new NamedIntOption(10, "10 — FireAndForget"),
            new NamedIntOption(50, "50 — TerminalGuidance"),
            new NamedIntOption(100, "100 — SemiActive"),
            new NamedIntOption(200, "200 — SEAD"),
            new NamedIntOption(300, "300 — Laser")
        };

        public static readonly IReadOnlyList<NamedIntOption> SwitchRules = new[]
        {
            new NamedIntOption(0, "0 — NoSwitch (не переключаться)"),
            new NamedIntOption(10, "10 — SelfDefense (самооборона)"),
            new NamedIntOption(20, "20 — AnySEAD (любой ПРЛ)"),
            new NamedIntOption(30, "30 — AnyProjectile (любая ракета/снаряд)")
        };

        public static string FormatTrajectoryShort(int id) => id switch
        {
            0 => "0: None",
            10 => "10: DirectShot",
            20 => "20: Artillery",
            30 => "30: Mortar",
            40 => "40: MLRS",
            100 => "100: PursuitMissile",
            110 => "110: LeadPursuitMissile",
            120 => "120: LeadMissile",
            200 => "200: CruiseMissile",
            300 => "300: BallisticMissile",
            400 => "400: LowDragBomb",
            410 => "410: HighDragBomb",
            600 => "600: LaserMissile",
            610 => "610: LaserFreeFall",
            666 => "666: DeadMissile",
            _ => id.ToString(CultureInfo.InvariantCulture)
        };

        public static string FormatSwitchRule(byte value)
        {
            foreach (NamedIntOption opt in SwitchRules)
                if (opt.Value == value) return opt.Label;
            return value.ToString(CultureInfo.InvariantCulture);
        }

        private static GlobalSettingMeta F(string key, string cat, float def, string desc, Func<TrajectoryConfig, float> get, Action<TrajectoryConfig, float> set)
            => new GlobalSettingMeta(key, cat, SettingValueKind.Float, def, desc, c => get(c), (c, v) => set(c, Convert.ToSingle(v, CultureInfo.InvariantCulture)));

        private static GlobalSettingMeta I(string key, string cat, int def, string desc, Func<TrajectoryConfig, int> get, Action<TrajectoryConfig, int> set)
            => new GlobalSettingMeta(key, cat, SettingValueKind.Int, def, desc, c => get(c), (c, v) => set(c, Convert.ToInt32(v, CultureInfo.InvariantCulture)));

        private static GlobalSettingMeta U(string key, string cat, uint def, string desc, Func<TrajectoryConfig, uint> get, Action<TrajectoryConfig, uint> set)
            => new GlobalSettingMeta(key, cat, SettingValueKind.UInt, def, desc, c => get(c), (c, v) => set(c, Convert.ToUInt32(v, CultureInfo.InvariantCulture)));

        private static GlobalSettingMeta US(string key, string cat, ushort def, string desc, Func<TrajectoryConfig, ushort> get, Action<TrajectoryConfig, ushort> set)
            => new GlobalSettingMeta(key, cat, SettingValueKind.UShort, def, desc, c => get(c), (c, v) => set(c, Convert.ToUInt16(v, CultureInfo.InvariantCulture)));

        private static GlobalSettingMeta B(string key, string cat, bool def, string desc, Func<TrajectoryConfig, bool> get, Action<TrajectoryConfig, bool> set)
            => new GlobalSettingMeta(key, cat, SettingValueKind.Bool, def, desc, c => get(c), (c, v) => set(c, Convert.ToBoolean(v, CultureInfo.InvariantCulture)));

        public static readonly IReadOnlyList<GlobalSettingMeta> GlobalSettings = new GlobalSettingMeta[]
        {
            F("G", CatDirect, 70f, "Базовое ускорение свободного падения для баллистических снарядов.", c => c.G, (c, v) => c.G = v),
            F("MIN_POINT_DISPERSION", CatDirect, 15f, "Минимальный разброс при стрельбе по точке/земле (м).", c => c.MIN_POINT_DISPERSION, (c, v) => c.MIN_POINT_DISPERSION = v),
            F("MAX_POINT_DISPERSION_MULTIPLIER", CatDirect, 3f, "Максимальный множитель разброса при стрельбе по точке.", c => c.MAX_POINT_DISPERSION_MULTIPLIER, (c, v) => c.MAX_POINT_DISPERSION_MULTIPLIER = v),
            F("ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS", CatDirect, 0f, "Дополнительный габарит самолётов для неуправляемых снарядов.", c => c.ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS, (c, v) => c.ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS = v),
            F("BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE", CatDirect, 10f, "Пороговый угол (°) попадания в крышу здания при прицеливании.", c => c.BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE, (c, v) => c.BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE = v),
            F("MAX_WEAPON_AIMING_IMPRECISION", CatDirect, 0.5f, "Допустимая неточность наведения башни/пусковой перед выстрелом.", c => c.MAX_WEAPON_AIMING_IMPRECISION, (c, v) => c.MAX_WEAPON_AIMING_IMPRECISION = v),
            F("MAX_WEAPON_AIMING_CHECK_TRESHOLD", CatDirect, 30f, "Угловой порог (°) проверки готовности наведения оружия.", c => c.MAX_WEAPON_AIMING_CHECK_TRESHOLD, (c, v) => c.MAX_WEAPON_AIMING_CHECK_TRESHOLD = v),

            F("MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE", CatArty, 1000f, "Дальняя эталонная дистанция для кривой дуги Artillery (20) и MLRS (40).", c => c.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE, (c, v) => c.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE = v),
            F("MAX_ARTILLERY_SHOT_APOGEE_DISTANCE", CatArty, 650f, "Позиция пика траектории (апогея) на дальнем эталоне артиллерии.", c => c.MAX_ARTILLERY_SHOT_APOGEE_DISTANCE, (c, v) => c.MAX_ARTILLERY_SHOT_APOGEE_DISTANCE = v),
            F("MAX_ARTILLERY_SHOT_APOGEE", CatArty, 250f, "Высота апогея дуги на дальнем эталоне артиллерии (м).", c => c.MAX_ARTILLERY_SHOT_APOGEE, (c, v) => c.MAX_ARTILLERY_SHOT_APOGEE = v),
            F("MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE", CatArty, 100f, "Ближняя эталонная дистанция для дуги Artillery (20) и MLRS (40).", c => c.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE, (c, v) => c.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE = v),
            F("MIN_ARTILLERY_SHOT_APOGEE", CatArty, 10f, "Высота апогея дуги на ближнем эталоне артиллерии (м).", c => c.MIN_ARTILLERY_SHOT_APOGEE, (c, v) => c.MIN_ARTILLERY_SHOT_APOGEE = v),
            F("MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE", CatArty, 1000f, "Дальняя эталонная дистанция для дуги миномёта Mortar (30).", c => c.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE, (c, v) => c.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE = v),
            F("MAX_MORTAR_SHOT_APOGEE", CatArty, 350f, "Высота апогея миномёта на дальнем эталоне (м).", c => c.MAX_MORTAR_SHOT_APOGEE, (c, v) => c.MAX_MORTAR_SHOT_APOGEE = v),
            F("MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE", CatArty, 1f, "Ближняя эталонная дистанция для миномёта Mortar (30).", c => c.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE, (c, v) => c.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE = v),
            F("MIN_MORTAR_SHOT_APOGEE", CatArty, 400f, "Высота апогея миномёта на ближнем эталоне (крутая навесная дуга).", c => c.MIN_MORTAR_SHOT_APOGEE, (c, v) => c.MIN_MORTAR_SHOT_APOGEE = v),

            F("START_LEAD_MISSILE_SPEED_PROPORTION", CatMissile, 0.4f, "Доля от MaxSpeed, с которой ракета начинает включать упреждение.", c => c.START_LEAD_MISSILE_SPEED_PROPORTION, (c, v) => c.START_LEAD_MISSILE_SPEED_PROPORTION = v),
            F("FULL_LEAD_MISSILE_SPEED_PROPORTION", CatMissile, 0.9f, "Доля от MaxSpeed, при которой упреждение достигает 100% своего коэффициента.", c => c.FULL_LEAD_MISSILE_SPEED_PROPORTION, (c, v) => c.FULL_LEAD_MISSILE_SPEED_PROPORTION = v),
            F("MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION", CatMissile, 10f, "Просадка от гравитации до включения маршевого двигателя.", c => c.MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION, (c, v) => c.MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION = v),
            F("MISSILE_DECELERATION_PROPORTION", CatMissile, 0.13f, "Доля замедления ракеты после выгорания топлива (BurnTime).", c => c.MISSILE_DECELERATION_PROPORTION, (c, v) => c.MISSILE_DECELERATION_PROPORTION = v),
            F("MISSILE_DEATH_SPEED_PROPORTION", CatMissile, 0.3f, "Порог падения скорости (доля от максимальной), ниже которого ракета гибнет.", c => c.MISSILE_DEATH_SPEED_PROPORTION, (c, v) => c.MISSILE_DEATH_SPEED_PROPORTION = v),
            F("LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION", CatMissile, 0.33f, "Доля пути прямого участка при горке (LoftAngle/LoftHeight).", c => c.LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION, (c, v) => c.LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION = v),
            F("MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION", CatMissile, 0.2f, "Доля траектории лофтинга, после которой проверяется прямая видимость (LoS).", c => c.MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION, (c, v) => c.MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION = v),
            F("MISSILE_NO_TARGET_SUPPORT_TIME", CatMissile, 2f, "Время (с) удержания траектории при потере цели для воздушных/обычных целей.", c => c.MISSILE_NO_TARGET_SUPPORT_TIME, (c, v) => c.MISSILE_NO_TARGET_SUPPORT_TIME = v),
            F("MISSILE_NO_TARGET_SUPPORT_TIME_TG", CatMissile, 0f, "Время (с) удержания траектории при потере наземной цели.", c => c.MISSILE_NO_TARGET_SUPPORT_TIME_TG, (c, v) => c.MISSILE_NO_TARGET_SUPPORT_TIME_TG = v),
            B("SEAD_MISSILES_GO_TO_LAST_POSITION", CatMissile, false, "Продолжают ли ПРЛ (SEAD) ракеты полёт в последнюю известную точку РЛС.", c => c.SEAD_MISSILES_GO_TO_LAST_POSITION, (c, v) => c.SEAD_MISSILES_GO_TO_LAST_POSITION = v),
            F("MINIMAL_MISSILE_MISS_DISTANCE", CatMissile, 100f, "Минимальный радиус отклонения при срыве/промахе ракеты (м).", c => c.MINIMAL_MISSILE_MISS_DISTANCE, (c, v) => c.MINIMAL_MISSILE_MISS_DISTANCE = v),
            F("MAX_MISSILE_MISS_DISTANCE_PROPORTION", CatMissile, 0.8f, "Максимальная доля дистанции отклонения при промахе.", c => c.MAX_MISSILE_MISS_DISTANCE_PROPORTION, (c, v) => c.MAX_MISSILE_MISS_DISTANCE_PROPORTION = v),
            F("MAX_MISSILE_MISS_DISTANCE_CAP", CatMissile, 200f, "Верхний предел радиуса промаха ракеты (м).", c => c.MAX_MISSILE_MISS_DISTANCE_CAP, (c, v) => c.MAX_MISSILE_MISS_DISTANCE_CAP = v),
            F("MISSILE_MISS_ADDITIONAL_CLEARENCE", CatMissile, 10f, "Дополнительный зазор дистанции при промахе ракеты (м).", c => c.MISSILE_MISS_ADDITIONAL_CLEARENCE, (c, v) => c.MISSILE_MISS_ADDITIONAL_CLEARENCE = v),
            F("RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN", CatMissile, 0.6f, "Мин. множитель дистанции радиовзрывателя при промахе.", c => c.RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN, (c, v) => c.RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN = v),
            F("RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX", CatMissile, 1.4f, "Макс. множитель дистанции радиовзрывателя при промахе.", c => c.RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX, (c, v) => c.RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX = v),
            F("RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER", CatMissile, 0f, "Случайный множитель порога срабатывания радиовзрывателя.", c => c.RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER, (c, v) => c.RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER = v),
            F("MISSILE_MERGE_POWER", CatMissile, 1f, "Сила смешивания/сглаживания вектора наведения ракеты.", c => c.MISSILE_MERGE_POWER, (c, v) => c.MISSILE_MERGE_POWER = v),
            new GlobalSettingMeta(
                "MISSILE_SWITCH_RULE",
                CatMissile,
                SettingValueKind.SwitchRuleEnum,
                (byte)10,
                "Правило перенацеливания ракет/ГСН: 0=NoSwitch, 10=SelfDefense, 20=AnySEAD, 30=AnyProjectile.",
                c => c.MISSILE_SWITCH_RULE,
                (c, v) => c.MISSILE_SWITCH_RULE = Convert.ToByte(v, CultureInfo.InvariantCulture)),

            F("CRUISE_MISSILE_TARGET_HEIGHT", CatCruise, 65f, "Целевая крейсерская высота крылатой ракеты над землёй (м).", c => c.CRUISE_MISSILE_TARGET_HEIGHT, (c, v) => c.CRUISE_MISSILE_TARGET_HEIGHT = v),
            F("CRUISE_MISSILE_DIVE_ANGLE", CatCruise, 60f, "Угол финального пикирования на цель (°).", c => c.CRUISE_MISSILE_DIVE_ANGLE, (c, v) => c.CRUISE_MISSILE_DIVE_ANGLE = v),
            F("PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE", CatCruise, 30f, "Угол снижения крылатой ракеты после сброса с самолёта (°).", c => c.PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE, (c, v) => c.PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE = v),
            F("CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT", CatCruise, 1f, "Коэффициент упреждающего сканирования рельефа перед крылатой ракетой.", c => c.CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT, (c, v) => c.CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT = v),
            I("CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION", CatCruise, 15, "Число шагов выборки высот рельефа перед крылатой ракетой.", c => c.CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION, (c, v) => c.CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION = v),

            F("BALLISTIC_MISSILES_APOAPSIS", CatBallistic, 2500f, "Высота апогея дуги баллистических ракет (м).", c => c.BALLISTIC_MISSILES_APOAPSIS, (c, v) => c.BALLISTIC_MISSILES_APOAPSIS = v),
            F("INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION", CatBallistic, 0.33f, "Минимальная доля траектории (0..1), с которой ПРО может перехватывать.", c => c.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION, (c, v) => c.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION = v),
            F("INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION", CatBallistic, 1f, "Максимальная доля траектории (0..1), до которой возможен перехват.", c => c.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION, (c, v) => c.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION = v),

            F("BOMBS_GRAVITY_MULTIPLYER", CatBomb, 1f, "Множитель гравитации для LowDragBomb (400).", c => c.BOMBS_GRAVITY_MULTIPLYER, (c, v) => c.BOMBS_GRAVITY_MULTIPLYER = v),
            F("HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER", CatBomb, 0.5f, "Уменьшенный множитель гравитации для штурмовых бомб HighDragBomb (410).", c => c.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER, (c, v) => c.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER = v),
            F("HIGH_DRAG_BOMBS_DECELERATION_PROPORTION", CatBomb, 0.1f, "Интенсивность торможения горизонтальной скорости у HighDragBomb (410).", c => c.HIGH_DRAG_BOMBS_DECELERATION_PROPORTION, (c, v) => c.HIGH_DRAG_BOMBS_DECELERATION_PROPORTION = v),
            F("BOMB_HORIZONTAL_MARGIN", CatBomb, 30f, "Горизонтальный допуск зоны сброса авиабомб (м).", c => c.BOMB_HORIZONTAL_MARGIN, (c, v) => c.BOMB_HORIZONTAL_MARGIN = v),
            F("BOMB_UPPER_MARGIN", CatBomb, -1f, "Верхний допуск сброса авиабомб (-1 = отключён).", c => c.BOMB_UPPER_MARGIN, (c, v) => c.BOMB_UPPER_MARGIN = v),
            B("DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN", CatBomb, true, "Отключать ли лазерное наведение на этапе боевого захода бомбардировщика.", c => c.DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN, (c, v) => c.DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN = v),

            F("LASER_MAX_GLIDING_ANGLE", CatLaserDead, 10f, "Макс. угол планирования для LaserGuidedFreeFaling (610), °.", c => c.LASER_MAX_GLIDING_ANGLE, (c, v) => c.LASER_MAX_GLIDING_ANGLE = v),
            F("LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE", CatLaserDead, 90f, "Эталонный угол потери скорости при довороте вверх по лазеру (610), °.", c => c.LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE, (c, v) => c.LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE = v),
            F("MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME", CatLaserDead, 1.5f, "Минимальное время полёта после перехода в DeadMissile (666), с.", c => c.MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME, (c, v) => c.MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME = v),
            F("MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN", CatLaserDead, 0.4f, "Мин. интервал смены точки хаотичного увода для DeadMissile (666), с.", c => c.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN, (c, v) => c.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN = v),
            F("MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX", CatLaserDead, 1.2f, "Макс. интервал смены точки хаотичного увода для DeadMissile (666), с.", c => c.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX, (c, v) => c.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX = v),
            F("SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS", CatLaserDead, 0f, "Вероятность самоликвидации ЗУР сразу при потере цели.", c => c.SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS, (c, v) => c.SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS = v)
        };

        public static readonly IReadOnlyList<GlobalSettingMeta> PlanesSettings = new GlobalSettingMeta[]
        {
            // Бомбинг ран
            F("BombingStartTimeOffset", PlBombing, 3f, "За сколько секунд до точки расчёта начинается сброс обычных бомб (LowDragBomb).", c => c.Planes.BombingStartTimeOffset, (c, v) => c.Planes.BombingStartTimeOffset = v),
            F("BombingStartTimeOffsetHighDrag", PlBombing, 3f, "За сколько секунд до точки расчёта начинается сброс тормозных бомб (HighDragBomb).", c => c.Planes.BombingStartTimeOffsetHighDrag, (c, v) => c.Planes.BombingStartTimeOffsetHighDrag = v),
            F("BombDropOffset", PlBombing, -25f, "Продольное смещение центра линии сброса обычных бомб (м; отрицательное — недолет/ближе к точке).", c => c.Planes.BombDropOffset, (c, v) => c.Planes.BombDropOffset = v),
            F("BombDropOffsetHighDrag", PlBombing, -25f, "Продольное смещение центра линии сброса тормозных бомб (м).", c => c.Planes.BombDropOffsetHighDrag, (c, v) => c.Planes.BombDropOffsetHighDrag = v),
            F("BombDropOffsetAmmoAoeMult", PlBombing, 0.8f, "Множитель AOE-радиуса бомбы при расчёте шага/смещения серии бомбометания.", c => c.Planes.BombDropOffsetAmmoAoeMult, (c, v) => c.Planes.BombDropOffsetAmmoAoeMult = v),
            B("EnableStratBomberCircling", PlBombing, true, "Включает круговой/широкий разворот стратегических бомбардировщиков на бомбинг ране.", c => c.Planes.EnableStratBomberCircling, (c, v) => c.Planes.EnableStratBomberCircling = v),

            // Штурмовой заход (Strafe)
            F("StrafeMinLength", PlStrafe, 100f, "Минимальная длина полосы штурмовки при протяжке мышью (м).", c => c.Planes.StrafeMinLength, (c, v) => c.Planes.StrafeMinLength = v),
            F("StrafeMaxLength", PlStrafe, 400f, "Максимальная длина полосы штурмового захода (м).", c => c.Planes.StrafeMaxLength, (c, v) => c.Planes.StrafeMaxLength = v),
            F("StrafeSearchRadius", PlStrafe, 50f, "Радиус поиска целей вокруг линии штурмового захода (м).", c => c.Planes.StrafeSearchRadius, (c, v) => c.Planes.StrafeSearchRadius = v),
            F("StrafeStartTimeOffset", PlStrafe, 1f, "Опережение начала стрельбы до входа в точку штурмовки (с).", c => c.Planes.StrafeStartTimeOffset, (c, v) => c.Planes.StrafeStartTimeOffset = v),
            F("StrafeWeaponPointOffset", PlStrafe, 1.75f, "Смещение точки прицеливания оружия на штурмовом заходе (с/коэф.).", c => c.Planes.StrafeWeaponPointOffset, (c, v) => c.Planes.StrafeWeaponPointOffset = v),

            // Пресижен страйк (Precision Strike)
            F("PrecisionMinAllowedAngle", PlPrecision, 10f, "Минимально допустимый угол входа самолёта для точечного сброса/пуска (Precision Strike), °.", c => c.Planes.PrecisionMinAllowedAngle, (c, v) => c.Planes.PrecisionMinAllowedAngle = v),
            US("PrecisionFlyAwayExtraDistance", PlPrecision, 300, "Дополнительная дистанция ухода/выравнивания после выполнения Precision Strike (м).", c => c.Planes.PrecisionFlyAwayExtraDistance, (c, v) => c.Planes.PrecisionFlyAwayExtraDistance = v),

            // Высоты и топливо
            F("HighAltitude", PlAltFuel, 400f, "Высота полёта самолёта на верхнем эшелоне (High Altitude).", c => c.Planes.HighAltitude, (c, v) => c.Planes.HighAltitude = v),
            F("LowAltitude", PlAltFuel, 100f, "Высота полёта самолёта на нижнем эшелоне / форсажном проходе (Low Altitude).", c => c.Planes.LowAltitude, (c, v) => c.Planes.LowAltitude = v),
            US("FuelRedZoneBaseValue", PlAltFuel, 20, "Базовый порог красной зоны топлива (% или ед.), при котором самолёт уходит на базу.", c => c.Planes.FuelRedZoneBaseValue, (c, v) => c.Planes.FuelRedZoneBaseValue = v),
            F("FuelOrangeZoneSizeRatio", PlAltFuel, 1f, "Размер оранжевой предупреждающей зоны топлива (коэффициент).", c => c.Planes.FuelOrangeZoneSizeRatio, (c, v) => c.Planes.FuelOrangeZoneSizeRatio = v),
            U("FuelOutChance", PlAltFuel, 100u, "Шанс принудительной эвакуации/аварии при полном выгорании топлива.", c => c.Planes.FuelOutChance, (c, v) => c.Planes.FuelOutChance = v),
            U("DeathChance", PlAltFuel, 0u, "Шанс мгновенного разрушения при критическом исчерпании топлива.", c => c.Planes.DeathChance, (c, v) => c.Planes.DeathChance = v),
            F("NextPointStepMultiplier", PlAltFuel, 0.5f, "Множитель шага переключения следующей путевой точки маршрута самолёта.", c => c.Planes.NextPointStepMultiplier, (c, v) => c.Planes.NextPointStepMultiplier = v),
            F("DecreaseSpeedAngle", PlAltFuel, 30f, "Угол разворота (°), при котором самолёт начинает снижать скорость в вираже.", c => c.Planes.DecreaseSpeedAngle, (c, v) => c.Planes.DecreaseSpeedAngle = v),

            // Воздушный бой и физика падения
            F("PlaneVsPlaneStopDistance", PlAirCombat, 200f, "Дистанция отворота/прекращения сближения при атаке самолётом другого самолёта (м).", c => c.Planes.PlaneVsPlaneStopDistance, (c, v) => c.Planes.PlaneVsPlaneStopDistance = v),
            F("PlaneVsPlaneEscapeDistance", PlAirCombat, 120f, "Дистанция выхода из воздушного боя после сближения (м).", c => c.Planes.PlaneVsPlaneEscapeDistance, (c, v) => c.Planes.PlaneVsPlaneEscapeDistance = v),
            F("PlaneVsHeliDiveAngle", PlAirCombat, 15f, "Угол пикирования самолёта при атаке вертолёта (°).", c => c.Planes.PlaneVsHeliDiveAngle, (c, v) => c.Planes.PlaneVsHeliDiveAngle = v),
            F("PlaneVsHeliNoseUpExtraHeight", PlAirCombat, 10f, "Запас высоты выхода из пикирования над вертолётом (м).", c => c.Planes.PlaneVsHeliNoseUpExtraHeight, (c, v) => c.Planes.PlaneVsHeliNoseUpExtraHeight = v),
            F("DEATH_MASS", PlAirCombat, 50f, "Физика падения сбитого самолёта: масса.", c => c.Planes.DEATH_MASS, (c, v) => c.Planes.DEATH_MASS = v),
            F("DEATH_DRAG", PlAirCombat, 0.03f, "Физика падения сбитого самолёта: аэродинамическое сопротивление.", c => c.Planes.DEATH_DRAG, (c, v) => c.Planes.DEATH_DRAG = v),
            F("DEATH_ANGULAR_DRAG", PlAirCombat, 100f, "Физика падения сбитого самолёта: угловое торможение.", c => c.Planes.DEATH_ANGULAR_DRAG, (c, v) => c.Planes.DEATH_ANGULAR_DRAG = v),
            F("DEATH_ENGINE_POWER_MULT", PlAirCombat, 2f, "Физика падения: множитель тяги при разрушении.", c => c.Planes.DEATH_ENGINE_POWER_MULT, (c, v) => c.Planes.DEATH_ENGINE_POWER_MULT = v),
            F("DEATH_ROTATE_POWER_MULT", PlAirCombat, 0.15f, "Физика падения: множитель вращающего момента.", c => c.Planes.DEATH_ROTATE_POWER_MULT, (c, v) => c.Planes.DEATH_ROTATE_POWER_MULT = v),
            F("DEATH_START_EPOWER_MULT", PlAirCombat, 1.5f, "Физика падения: начальный импульс тяги.", c => c.Planes.DEATH_START_EPOWER_MULT, (c, v) => c.Planes.DEATH_START_EPOWER_MULT = v),
            F("DEATH_START_RPOWER_MULT", PlAirCombat, 0f, "Физика падения: начальный вращающий импульс.", c => c.Planes.DEATH_START_RPOWER_MULT, (c, v) => c.Planes.DEATH_START_RPOWER_MULT = v),
            F("DEATH_BLAST_POWER_MULT", PlAirCombat, 50f, "Физика падения: сила взрывного импульса.", c => c.Planes.DEATH_BLAST_POWER_MULT, (c, v) => c.Planes.DEATH_BLAST_POWER_MULT = v)
        };

        public static readonly IReadOnlyList<GlobalSettingMeta> SupplyAndEconomySettings = new GlobalSettingMeta[]
        {
            // Саплай
            I("SupplyValueBought", SeSupply, 10, "Цена в очках реквизиции за 1 шаг покупки саплая (по умолчанию 10 очков = 1 тонна).", c => c.Supply.SupplyValueBought, (c, v) => c.Supply.SupplyValueBought = v),
            I("SupplyExchangeRate", SeSupply, 1000, "Сколько единиц саплая (кг) выдаётся за 1 шаг покупки (по умолчанию 1000 кг = 1 т).", c => c.Supply.SupplyExchangeRate, (c, v) => c.Supply.SupplyExchangeRate = v),
            F("ResupplyRadius", SeSupply, 75f, "Базовый радиус раздачи припасов вокруг склада саплая (м).", c => c.Supply.ResupplyRadius, (c, v) => c.Supply.ResupplyRadius = v),
            F("AmmoCostMultiplier", SeSupply, 4f, "Глобальный множитель расхода саплая на пополнение БК (умножает Ammunitions.SupplyCost).", c => c.Supply.AmmoCostMultiplier, (c, v) => c.Supply.AmmoCostMultiplier = v),
            F("RepairRate", SeSupply, 0.35f, "Скорость ремонта техники на точке саплая (HP/тик).", c => c.Supply.RepairRate, (c, v) => c.Supply.RepairRate = v),
            F("RepairCost", SeSupply, 25f, "Стоимость ремонта в единицах саплая.", c => c.Supply.RepairCost, (c, v) => c.Supply.RepairCost = v),
            F("HealingCost", SeSupply, 0.5f, "Стоимость лечения пехоты в единицах саплая.", c => c.Supply.HealingCost, (c, v) => c.Supply.HealingCost = v),
            F("HealingRate", SeSupply, 1f, "Скорость лечения/восполнения пехоты на саплае.", c => c.Supply.HealingRate, (c, v) => c.Supply.HealingRate = v),
            F("AbilityResupplyRate", SeSupply, 50f, "Скорость пополнения зарядов способностей (дымы, КАЗ, ловушки).", c => c.Supply.AbilityResupplyRate, (c, v) => c.Supply.AbilityResupplyRate = v),
            F("AbilityMultiplierHeal", SeSupply, 0.5f, "Множитель ускорения лечения от способностей.", c => c.Supply.AbilityMultiplierHeal, (c, v) => c.Supply.AbilityMultiplierHeal = v),
            F("AbilityMultiplierRepair", SeSupply, 0.5f, "Множитель ускорения ремонта от способностей.", c => c.Supply.AbilityMultiplierRepair, (c, v) => c.Supply.AbilityMultiplierRepair = v),
            F("AbilityMultiplierRearm", SeSupply, 0.5f, "Множитель пополнения БК/способностей от перков.", c => c.Supply.AbilityMultiplierRearm, (c, v) => c.Supply.AbilityMultiplierRearm = v),
            F("ViewDistance", SeSupply, 0f, "Собственная дальность обзора ящика саплая (0 = не даёт вижена).", c => c.Supply.ViewDistance, (c, v) => c.Supply.ViewDistance = v),
            B("ShowEnemySupplyRadius", SeSupply, true, "Показывать ли радиус обнаруженного вражеского склада саплая.", c => c.Supply.ShowEnemySupplyRadius, (c, v) => c.Supply.ShowEnemySupplyRadius = v),

            // Экономика и доход
            F("DefaultPlayerMoney", SeEconomy, 1000f, "Стартовые очки реквизиции игрока.", c => c.GameConfig.DefaultPlayerMoney, (c, v) => c.GameConfig.DefaultPlayerMoney = v),
            F("DefaultIncomePerMin", SeEconomy, 300f, "Базовый доход очков реквизиции в минуту.", c => c.GameConfig.DefaultIncomePerMin, (c, v) => c.GameConfig.DefaultIncomePerMin = v),
            F("UpkeepMultiplier", SeEconomy, 1.66667f, "Множитель удержания очков за армию на поле боя (Upkeep).", c => c.GameConfig.UpkeepMultiplier, (c, v) => c.GameConfig.UpkeepMultiplier = v),
            F("PlanesUpkeepMultiplier", SeEconomy, 0f, "Дополнительный множитель Upkeep для авиации.", c => c.GameConfig.PlanesUpkeepMultiplier, (c, v) => c.GameConfig.PlanesUpkeepMultiplier = v),
            F("DeadUnitsValueMultiplier", SeEconomy, 0f, "Учёт потерянных юнитов в расчёте экономики/дохода.", c => c.GameConfig.DeadUnitsValueMultiplier, (c, v) => c.GameConfig.DeadUnitsValueMultiplier = v),
            F("DeckCategoryValueMargin", SeEconomy, 0.1f, "Допустимый перевес лимита категории в конструкторе деки (0.1 = +10%).", c => c.GameConfig.DeckCategoryValueMargin, (c, v) => c.GameConfig.DeckCategoryValueMargin = v),

            // Возврат и респавн
            F("DespawnDelaySec", SeRefund, 5f, "Задержка перед возвратом (Refund) юнита у края карты, с.", c => c.GameConfig.DespawnDelaySec, (c, v) => c.GameConfig.DespawnDelaySec = v),
            F("RefundMultiplier", SeRefund, 1f, "Общий множитель возврата очков за отозванный юнит.", c => c.GameConfig.RefundMultiplier, (c, v) => c.GameConfig.RefundMultiplier = v),
            F("RefundLostAmmoTimeMultiplier", SeRefund, 0f, "Влияние потраченного БК на задержку перезакупа наземных юнитов.", c => c.GameConfig.RefundLostAmmoTimeMultiplier, (c, v) => c.GameConfig.RefundLostAmmoTimeMultiplier = v),
            F("RepurchaseDelayFloor", SeRefund, 30f, "Минимальная задержка повторного вызова отозванного юнита (с).", c => c.GameConfig.RepurchaseDelayFloor, (c, v) => c.GameConfig.RepurchaseDelayFloor = v),
            F("RepurchaseDelayMultiplier", SeRefund, 0.5f, "Множитель задержки повторного вызова отозванного юнита.", c => c.GameConfig.RepurchaseDelayMultiplier, (c, v) => c.GameConfig.RepurchaseDelayMultiplier = v),
            F("PlanesRefundFloor", SeRefund, 60f, "Минимальный кулдаун самолёта после возврата (с).", c => c.GameConfig.PlanesRefundFloor, (c, v) => c.GameConfig.PlanesRefundFloor = v),
            F("PlanesRefundHPMultiplier", SeRefund, 0.5f, "Влияние потерянного HP самолёта на время возврата в ангар.", c => c.GameConfig.PlanesRefundHPMultiplier, (c, v) => c.GameConfig.PlanesRefundHPMultiplier = v),
            F("PlanesRefundAmmoCoeff_K", SeRefund, 1f, "Коэффициент K влияния израсходованного БК самолёта на кулдаун.", c => c.GameConfig.PlanesRefundAmmoCoeff_K, (c, v) => c.GameConfig.PlanesRefundAmmoCoeff_K = v),
            F("PlanesRefundAmmoCoeff_P", SeRefund, 5f, "Коэффициент P влияния израсходованного БК самолёта на кулдаун.", c => c.GameConfig.PlanesRefundAmmoCoeff_P, (c, v) => c.GameConfig.PlanesRefundAmmoCoeff_P = v),
            B("PlanesDeathIsMultiplierOfRefund", SeRefund, true, "Считать ли кулдаун сбитого самолёта как множитель от обычного возврата.", c => c.GameConfig.PlanesDeathIsMultiplierOfRefund, (c, v) => c.GameConfig.PlanesDeathIsMultiplierOfRefund = v),
            F("PlanesDeathRefundMultiplier", SeRefund, 2.5f, "Множитель кулдауна при гибели самолёта.", c => c.GameConfig.PlanesDeathRefundMultiplier, (c, v) => c.GameConfig.PlanesDeathRefundMultiplier = v),
            F("MinimumRefundPercent", SeRefund, 20f, "Минимальный процент возврата очков за повреждённый юнит (%).", c => c.GameConfig.MinimumRefundPercent, (c, v) => c.GameConfig.MinimumRefundPercent = v),
            F("MaximumRefundPercent", SeRefund, 90f, "Максимальный процент возврата очков (%).", c => c.GameConfig.MaximumRefundPercent, (c, v) => c.GameConfig.MaximumRefundPercent = v),
            F("HealthCostMultiplier", SeRefund, 0.5f, "Множитель штрафа стоимости при неполном HP на возврате.", c => c.GameConfig.HealthCostMultiplier, (c, v) => c.GameConfig.HealthCostMultiplier = v),
            B("ResurrectionEnabled", SeRefund, true, "Разрешено ли восстановление (респавн) уничтоженных юнитов в деке.", c => c.GameConfig.ResurrectionEnabled, (c, v) => c.GameConfig.ResurrectionEnabled = v),
            F("ResurrectDelayFloor", SeRefund, 420f, "Минимальный кулдаун респавна уничтоженного юнита (с).", c => c.GameConfig.ResurrectDelayFloor, (c, v) => c.GameConfig.ResurrectDelayFloor = v),
            F("ResurrectDelayMultiplier", SeRefund, 1.5f, "Множитель кулдауна респавна уничтоженного юнита.", c => c.GameConfig.ResurrectDelayMultiplier, (c, v) => c.GameConfig.ResurrectDelayMultiplier = v),
            F("PlanesDeathPenalty", SeRefund, 0f, "Фиксированный штраф к задержке после потери самолёта (с).", c => c.GameConfig.PlanesDeathPenalty, (c, v) => c.GameConfig.PlanesDeathPenalty = v)
        };

        public static readonly IReadOnlyList<GlobalSettingMeta> GameFormulaSettings = new GlobalSettingMeta[]
        {
            // Урон, броня, пробитие и CQC
            F("ARMOR_PENETRATION_EFFECTIVENESS", GfDamage, 1f, "Эффективность кинетического/общего бронепробития (кривая урона по броне).", c => c.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS, (c, v) => c.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS = v),
            F("MINIMAL_DAMAGE_COEFFICIENT", GfDamage, 0.1f, "Минимальная доля урона даже при неполном/неудачном пробитии.", c => c.CombatFormulas.MINIMAL_DAMAGE_COEFFICIENT, (c, v) => c.CombatFormulas.MINIMAL_DAMAGE_COEFFICIENT = v),
            F("HE_ARMOR_EFFECTIVENESS", GfDamage, 1f, "Эффективность фугасного (HE) урона против брони.", c => c.CombatFormulas.HE_ARMOR_EFFECTIVENESS, (c, v) => c.CombatFormulas.HE_ARMOR_EFFECTIVENESS = v),
            F("HEAT_CURVE_COEFFICIENT", GfDamage, 2f, "Коэффициент кривой кумулятивного (HEAT) урона против брони.", c => c.CombatFormulas.HEAT_CURVE_COEFFICIENT, (c, v) => c.CombatFormulas.HEAT_CURVE_COEFFICIENT = v),
            F("CQCTick", GfDamage, 0.3f, "Интервал тика ближнего боя (CQC) в зданиях/на близкой дистанции (с).", c => c.CombatFormulas.CQCTick, (c, v) => c.CombatFormulas.CQCTick = v),
            F("CQCChance", GfDamage, 1f, "Базовый шанс срабатывания CQC-атаки за тик.", c => c.CombatFormulas.CQCChance, (c, v) => c.CombatFormulas.CQCChance = v),
            F("PLANES_DAMAGE_SCORE_MULTIPLIER", GfDamage, 1f, "Множитель оценки приоритета урона по самолётам при выборе цели.", c => c.CombatFormulas.PLANES_DAMAGE_SCORE_MULTIPLIER, (c, v) => c.CombatFormulas.PLANES_DAMAGE_SCORE_MULTIPLIER = v),
            F("RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES", GfDamage, 1f, "Множитель дальности перехвата ПРЛ (SEAD) ракет комплексами ПВО.", c => c.CombatFormulas.RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES, (c, v) => c.CombatFormulas.RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES = v),
            F("RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES", GfDamage, 1f, "Множитель дальности перехвата прочих ракет/бомб комплексами ПВО/ПРО.", c => c.CombatFormulas.RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES, (c, v) => c.CombatFormulas.RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES = v),

            // ИИ стрельбы, Overkill, ЛТЦ и автодымы
            F("SEAD_SCORE_MULTIPLIER", GfTargeting, 0.99f, "Весовой множитель цели SEAD при приоритизации перехвата.", c => c.CombatFormulas.SEAD_SCORE_MULTIPLIER, (c, v) => c.CombatFormulas.SEAD_SCORE_MULTIPLIER = v),
            F("MINIMAL_CHANCE_TO_KILL", GfTargeting, 0.8f, "Порог расчётного шанса уничтожения в системе выбора целей.", c => c.CombatFormulas.MINIMAL_CHANCE_TO_KILL, (c, v) => c.CombatFormulas.MINIMAL_CHANCE_TO_KILL = v),
            F("GUIDED_SELECTION_DAMAGE_TRESHHOLD", GfTargeting, 1.4f, "Порог урона для выбора управляемых ракет по обычной цели.", c => c.CombatFormulas.GUIDED_SELECTION_DAMAGE_TRESHHOLD, (c, v) => c.CombatFormulas.GUIDED_SELECTION_DAMAGE_TRESHHOLD = v),
            F("APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD", GfTargeting, 5f, "Порог урона/залпа для преодоления активной защиты (APS).", c => c.CombatFormulas.APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD, (c, v) => c.CombatFormulas.APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD = v),
            B("GUIDED_IGNORE_UNGUIDED_ON_PLANES", GfTargeting, true, "Игнорировать ли неуправляемые снаряды при расчёте overkill по самолётам.", c => c.CombatFormulas.GUIDED_IGNORE_UNGUIDED_ON_PLANES, (c, v) => c.CombatFormulas.GUIDED_IGNORE_UNGUIDED_ON_PLANES = v),
            B("GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES", GfTargeting, true, "Игнорировать ли неуправляемые перехваты при расчёте overkill по ракетам.", c => c.CombatFormulas.GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES, (c, v) => c.CombatFormulas.GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES = v),
            B("ACTIVE_APS_IGNORES_ONE_MISSILE", GfTargeting, true, "Учитывает ли overkill-система, что активный КАЗ собьёт первую ракету.", c => c.CombatFormulas.ACTIVE_APS_IGNORES_ONE_MISSILE, (c, v) => c.CombatFormulas.ACTIVE_APS_IGNORES_ONE_MISSILE = v),
            B("HP_LIMIT_WEAPON_SCORE", GfTargeting, true, "Ограничивать ли полезность выстрела текущим HP цели.", c => c.CombatFormulas.HP_LIMIT_WEAPON_SCORE, (c, v) => c.CombatFormulas.HP_LIMIT_WEAPON_SCORE = v),
            B("PRIORITIZE_ONE_SHOT_TARGETS", GfTargeting, true, "Отдавать ли приоритет целям, которые уничтожаются одним попаданием.", c => c.CombatFormulas.PRIORITIZE_ONE_SHOT_TARGETS, (c, v) => c.CombatFormulas.PRIORITIZE_ONE_SHOT_TARGETS = v),
            B("PREVENT_GUIDED_OVERKILL", GfTargeting, true, "Запретить пуск лишних управляемых ракет сверх нужного урона (Overkill protection).", c => c.CombatFormulas.PREVENT_GUIDED_OVERKILL, (c, v) => c.CombatFormulas.PREVENT_GUIDED_OVERKILL = v),
            F("MISSILE_OVERKILL_CLEAR_DELAY", GfTargeting, 0.25f, "Задержка снятия overkill-резерва после промаха/попадания ракеты (с).", c => c.CombatFormulas.MISSILE_OVERKILL_CLEAR_DELAY, (c, v) => c.CombatFormulas.MISSILE_OVERKILL_CLEAR_DELAY = v),
            B("FORCE_MISSILE_MISS_DAMAGE", GfTargeting, true, "Наносить ли осколочный урон ракетой даже при расчётном промахе.", c => c.CombatFormulas.FORCE_MISSILE_MISS_DAMAGE, (c, v) => c.CombatFormulas.FORCE_MISSILE_MISS_DAMAGE = v),
            F("MISSILE_MISS_OVERKILL_CLEAR_DELAY", GfTargeting, 1f, "Задержка снятия overkill-резерва для промахнувшейся ракеты (с).", c => c.CombatFormulas.MISSILE_MISS_OVERKILL_CLEAR_DELAY, (c, v) => c.CombatFormulas.MISSILE_MISS_OVERKILL_CLEAR_DELAY = v),
            I("MAX_FLARES_COUNT_MISSILE_INITIAL", GfTargeting, 100, "Макс. счётчик проверок ЛТЦ при первом пуске ракеты.", c => c.CombatFormulas.MAX_FLARES_COUNT_MISSILE_INITIAL, (c, v) => c.CombatFormulas.MAX_FLARES_COUNT_MISSILE_INITIAL = v),
            I("MAX_FLARES_COUNT_MISSILE_REROLL", GfTargeting, 1, "Число повторных бросков проверки ЛТЦ.", c => c.CombatFormulas.MAX_FLARES_COUNT_MISSILE_REROLL, (c, v) => c.CombatFormulas.MAX_FLARES_COUNT_MISSILE_REROLL = v),
            F("AUTOFLARES_PLANES_DELAY", GfTargeting, 1.5f, "Задержка автоматического отстрела ЛТЦ самолётами (с).", c => c.CombatFormulas.AUTOFLARES_PLANES_DELAY, (c, v) => c.CombatFormulas.AUTOFLARES_PLANES_DELAY = v),
            F("AUTOFLARES_HELICOPTERS_DELAY", GfTargeting, 0.5f, "Задержка автоматического отстрела ЛТЦ вертолётами (с).", c => c.CombatFormulas.AUTOFLARES_HELICOPTERS_DELAY, (c, v) => c.CombatFormulas.AUTOFLARES_HELICOPTERS_DELAY = v),
            B("AUTOSMOKE_TRIGGER_BY_GUNS", GfTargeting, false, "Автодымы игрока при обстреле пушками.", c => c.CombatFormulas.AUTOSMOKE_TRIGGER_BY_GUNS, (c, v) => c.CombatFormulas.AUTOSMOKE_TRIGGER_BY_GUNS = v),
            B("AUTOSMOKE_TRIGGER_BY_MISSILES", GfTargeting, true, "Автодымы игрока при пуске ПТУР по технике.", c => c.CombatFormulas.AUTOSMOKE_TRIGGER_BY_MISSILES, (c, v) => c.CombatFormulas.AUTOSMOKE_TRIGGER_BY_MISSILES = v),
            F("AUTOSMOKE_DELAY_MIN", GfTargeting, 3f, "Мин. перезарядка/задержка автодымов игрока (с).", c => c.CombatFormulas.AUTOSMOKE_DELAY_MIN, (c, v) => c.CombatFormulas.AUTOSMOKE_DELAY_MIN = v),
            F("AUTOSMOKE_DELAY_MAX", GfTargeting, 5f, "Макс. перезарядка/задержка автодымов игрока (с).", c => c.CombatFormulas.AUTOSMOKE_DELAY_MAX, (c, v) => c.CombatFormulas.AUTOSMOKE_DELAY_MAX = v),
            B("AUTOSMOKE_AI_TRIGGER_BY_GUNS", GfTargeting, true, "Автодымы ИИ при обстреле пушками.", c => c.CombatFormulas.AUTOSMOKE_AI_TRIGGER_BY_GUNS, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_TRIGGER_BY_GUNS = v),
            B("AUTOSMOKE_AI_TRIGGER_BY_MISSILES", GfTargeting, true, "Автодымы ИИ при пуске ракет.", c => c.CombatFormulas.AUTOSMOKE_AI_TRIGGER_BY_MISSILES, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_TRIGGER_BY_MISSILES = v),
            F("AUTOSMOKE_AI_DELAY_MIN", GfTargeting, 2f, "Мин. задержка автодымов ИИ (с).", c => c.CombatFormulas.AUTOSMOKE_AI_DELAY_MIN, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_DELAY_MIN = v),
            F("AUTOSMOKE_AI_DELAY_MAX", GfTargeting, 8f, "Макс. задержка автодымов ИИ (с).", c => c.CombatFormulas.AUTOSMOKE_AI_DELAY_MAX, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_DELAY_MAX = v),
            F("AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY", GfTargeting, 0.25f, "Шанс автодымов лёгкого ИИ.", c => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY = v),
            F("AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM", GfTargeting, 0.5f, "Шанс автодымов среднего ИИ.", c => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM = v),
            F("AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD", GfTargeting, 0.75f, "Шанс автодымов сложного ИИ.", c => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD, (c, v) => c.CombatFormulas.AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD = v),
            F("MAX_TIME_WITHOUT_TARGET", GfTargeting, 1f, "Сколько секунд оружие удерживает сектор/готовность без активной цели.", c => c.CombatFormulas.MAX_TIME_WITHOUT_TARGET, (c, v) => c.CombatFormulas.MAX_TIME_WITHOUT_TARGET = v),

            // Видимость, оптика и лес (FoW)
            F("MinimumDetectionDistance", GfFow, 45f, "Дистанция гарантированного обнаружения вплотную (м).", c => c.FogOfWar.MinimumDetectionDistance, (c, v) => c.FogOfWar.MinimumDetectionDistance = v),
            F("MaxShootableForestDistance", GfFow, 45f, "Макс. глубина леса, сквозь которую проходит прямой огонь (м).", c => c.FogOfWar.MaxShootableForestDistance, (c, v) => c.FogOfWar.MaxShootableForestDistance = v),
            F("LaserForestMaxRange", GfFow, 45f, "Макс. глубина леса для лазерного целеуказания чужих юнитов (м).", c => c.FogOfWar.LaserForestMaxRange, (c, v) => c.FogOfWar.LaserForestMaxRange = v),
            F("LaserOwnForestRange", GfFow, 25f, "Макс. глубина собственного леса, сквозь которую светит лазер (м).", c => c.FogOfWar.LaserOwnForestRange, (c, v) => c.FogOfWar.LaserOwnForestRange = v),
            F("FlashReduction", GfFow, 0.15f, "Скорость спада демаскирующей вспышки выстрела.", c => c.FogOfWar.FlashReduction, (c, v) => c.FogOfWar.FlashReduction = v),
            F("MaxFlashValue", GfFow, 4.5f, "Максимальное значение накопленной вспышки от стрельбы.", c => c.FogOfWar.MaxFlashValue, (c, v) => c.FogOfWar.MaxFlashValue = v),
            F("MaxAntiVisible", GfFow, 1.5f, "Потолок накопленной демаскировки.", c => c.FogOfWar.MaxAntiVisible, (c, v) => c.FogOfWar.MaxAntiVisible = v),
            F("SpottedPenalty", GfFow, 2f, "Штраф к скрытности открытого юнита после засвета.", c => c.FogOfWar.SpottedPenalty, (c, v) => c.FogOfWar.SpottedPenalty = v),
            F("SpottedPenaltyBuildings", GfFow, 2f, "Штраф к скрытности юнита в здании после засвета.", c => c.FogOfWar.SpottedPenaltyBuildings, (c, v) => c.FogOfWar.SpottedPenaltyBuildings = v),
            F("SneakMinAntivisible", GfFow, 0.2f, "Минимальный порог демаскировки в режиме скрытности.", c => c.FogOfWar.SneakMinAntivisible, (c, v) => c.FogOfWar.SneakMinAntivisible = v),

            // Стресс, паника и криты
            F("ShockedLevelMultiplier", GfBuffs, 0.5f, "Порог стресса для статуса Shocked у техники (доля).", c => c.Buffs.ShockedLevelMultiplier, (c, v) => c.Buffs.ShockedLevelMultiplier = v),
            F("PanickedLevelMultiplier", GfBuffs, 0.8f, "Порог стресса для статуса Panicked у техники (доля).", c => c.Buffs.PanickedLevelMultiplier, (c, v) => c.Buffs.PanickedLevelMultiplier = v),
            F("ShockedLevelMultiplierInfantry", GfBuffs, 0.4f, "Порог стресса для статуса Shocked у пехоты.", c => c.Buffs.ShockedLevelMultiplierInfantry, (c, v) => c.Buffs.ShockedLevelMultiplierInfantry = v),
            F("PanickedLevelMultiplierInfantry", GfBuffs, 0.8f, "Порог стресса для статуса Panicked у пехоты.", c => c.Buffs.PanickedLevelMultiplierInfantry, (c, v) => c.Buffs.PanickedLevelMultiplierInfantry = v),
            F("StressRecoveryMultiplier", GfBuffs, 1f, "Множитель скорости восстановления стресса.", c => c.Buffs.StressRecoveryMultiplier, (c, v) => c.Buffs.StressRecoveryMultiplier = v),
            F("StressDamageModThreshold", GfBuffs, 36f, "Порог накопления стресса для модификатора.", c => c.Buffs.StressDamageModThreshold, (c, v) => c.Buffs.StressDamageModThreshold = v),
            F("CriticalBaseProbability", GfBuffs, 0.02f, "Базовая вероятность критического повреждения модуля техники.", c => c.Buffs.CriticalBaseProbability, (c, v) => c.Buffs.CriticalBaseProbability = v),
            I("RedCritsActivationThreshold", GfBuffs, 2, "Количество критов одного типа/уровня для перехода в красный крит.", c => c.Buffs.RedCritsActivationThreshold, (c, v) => c.Buffs.RedCritsActivationThreshold = v),
            F("MinorAimTimeMultiplier", GfBuffs, 1.5f, "Штраф времени прицеливания при малом стрессе/крите.", c => c.Buffs.MinorAimTimeMultiplier, (c, v) => c.Buffs.MinorAimTimeMultiplier = v),
            F("MajorAimTimeMultiplier", GfBuffs, 2f, "Штраф времени прицеливания при сильном стрессе/крите.", c => c.Buffs.MajorAimTimeMultiplier, (c, v) => c.Buffs.MajorAimTimeMultiplier = v),
            F("MinorOpticsMultiplier", GfBuffs, 0.66f, "Множитель оптики при малом стрессе/повреждении оптики.", c => c.Buffs.MinorOpticsMultiplier, (c, v) => c.Buffs.MinorOpticsMultiplier = v),
            F("MajorOpticsMultiplier", GfBuffs, 0.33f, "Множитель оптики при сильном стрессе/повреждении оптики.", c => c.Buffs.MajorOpticsMultiplier, (c, v) => c.Buffs.MajorOpticsMultiplier = v),
            F("MinorMobilityMultiplier", GfBuffs, 0.75f, "Множитель скорости при повреждении ходовой.", c => c.Buffs.MinorMobilityMultiplier, (c, v) => c.Buffs.MinorMobilityMultiplier = v),
            F("MinorMobilityMultiplierRotation", GfBuffs, 0.5f, "Множитель скорости поворота при повреждении ходовой.", c => c.Buffs.MinorMobilityMultiplierRotation, (c, v) => c.Buffs.MinorMobilityMultiplierRotation = v),
            F("MinorDispersionMultiplier", GfBuffs, 1.15f, "Множитель разброса при малом стрессе.", c => c.Buffs.MinorDispersionMultiplier, (c, v) => c.Buffs.MinorDispersionMultiplier = v),
            F("MajorDispersionMultiplier", GfBuffs, 1.52f, "Множитель разброса при сильном стрессе.", c => c.Buffs.MajorDispersionMultiplier, (c, v) => c.Buffs.MajorDispersionMultiplier = v),
            F("MinorLoadingMultiplier", GfBuffs, 1.5f, "Множитель времени перезарядки при малом стрессе.", c => c.Buffs.MinorLoadingMultiplier, (c, v) => c.Buffs.MinorLoadingMultiplier = v),
            F("MajorLoadingMultiplier", GfBuffs, 2f, "Множитель времени перезарядки при сильном стрессе.", c => c.Buffs.MajorLoadingMultiplier, (c, v) => c.Buffs.MajorLoadingMultiplier = v),

            // Здания и укрытия
            I("BuildingDamageThreshold", GfBuildings, 5, "Порог урона для разрушения/пробития элементов здания.", c => c.Buildings.BuildingDamageThreshold, (c, v) => c.Buildings.BuildingDamageThreshold = v),
            F("DamageModifierFloor", GfBuildings, 0.18f, "Минимальный множитель урона по пехоте в здании (нижняя граница).", c => c.Buildings.DamageModifierFloor, (c, v) => c.Buildings.DamageModifierFloor = v),
            F("DamageModifierPerSoldier", GfBuildings, 0.02f, "Прибавка множителя урона по пехоте в здании за каждого бойца.", c => c.Buildings.DamageModifierPerSoldier, (c, v) => c.Buildings.DamageModifierPerSoldier = v),
            F("HitColliderReduction", GfBuildings, 1f, "Коэффициент уменьшения хитбокса зданий при проверке попаданий.", c => c.Buildings.HitColliderReduction, (c, v) => c.Buildings.HitColliderReduction = v),
            F("CoverSnapDistance", GfBuildings, 8f, "Дистанция привязки пехоты к укрытию/зданию (м).", c => c.GameConfig.CoverSnapDistance, (c, v) => c.GameConfig.CoverSnapDistance = v),
            F("CoverSnapSingleUnitModifier", GfBuildings, 1f, "Модификатор дистанции привязки для одиночного бойца.", c => c.GameConfig.CoverSnapSingleUnitModifier, (c, v) => c.GameConfig.CoverSnapSingleUnitModifier = v),
            I("OnBuildingDestroyPrecentage", GfBuildings, 60, "Процент урона по отряду внутри при обрушении здания (%).", c => c.GameConfig.OnBuildingDestroyPrecentage, (c, v) => c.GameConfig.OnBuildingDestroyPrecentage = v),

            // Пехота, скорости и транспорт
            U("BaseSquadSize", GfInfantryTransport, 1u, "Базовый коэффициент численности отряда пехоты.", c => c.Infantry.BaseSquadSize, (c, v) => c.Infantry.BaseSquadSize = v),
            F("InfantryDeathTime", GfInfantryTransport, 30f, "Время лежания погибших моделей пехоты до исчезновения (с).", c => c.Infantry.InfantryDeathTime, (c, v) => c.Infantry.InfantryDeathTime = v),
            F("HorizontalTurretRotationSpeed", GfInfantryTransport, 180f, "Скорость поворота оружия бойца (°/с).", c => c.Infantry.HorizontalTurretRotationSpeed, (c, v) => c.Infantry.HorizontalTurretRotationSpeed = v),
            F("StartMovingMaxDelay", GfInfantryTransport, 0.5f, "Макс. случайная задержка старта движения бойца в отряде (с).", c => c.Infantry.StartMovingMaxDelay, (c, v) => c.Infantry.StartMovingMaxDelay = v),
            F("Infantry.RunSpeed", GfInfantryTransport, 5f, "Скорость обычного бега пехоты.", c => c.Infantry.RunSpeed, (c, v) => c.Infantry.RunSpeed = v),
            F("Infantry.SprintSpeed", GfInfantryTransport, 10f, "Скорость спринта пехоты (InfantryConfig).", c => c.Infantry.SprintSpeed, (c, v) => c.Infantry.SprintSpeed = v),
            F("GameConfig.SprintSpeed", GfInfantryTransport, 10f, "Глобальная скорость спринта (GameConfig).", c => c.GameConfig.SprintSpeed, (c, v) => c.GameConfig.SprintSpeed = v),
            F("KneelRunSpeed", GfInfantryTransport, 3f, "Скорость движения пехоты на колене / в приседе.", c => c.Infantry.KneelRunSpeed, (c, v) => c.Infantry.KneelRunSpeed = v),
            F("ProneRunSpeed", GfInfantryTransport, 1f, "Скорость переползания пехоты.", c => c.Infantry.ProneRunSpeed, (c, v) => c.Infantry.ProneRunSpeed = v),
            F("ProneSprintSpeed", GfInfantryTransport, 2f, "Скорость ускоренного ползания пехоты.", c => c.Infantry.ProneSprintSpeed, (c, v) => c.Infantry.ProneSprintSpeed = v),
            F("Infantry.RotationSpeed", GfInfantryTransport, 180f, "Скорость разворота пехоты (°/с).", c => c.Infantry.RotationSpeed, (c, v) => c.Infantry.RotationSpeed = v),
            F("ShootAimRotationSpeed", GfInfantryTransport, 11f, "Скорость доводки корпуса при прицеливании пехоты.", c => c.Infantry.ShootAimRotationSpeed, (c, v) => c.Infantry.ShootAimRotationSpeed = v),
            F("DistanceForSprint", GfInfantryTransport, 2f, "Дистанция, с которой пехота переходит на спринт (м).", c => c.Infantry.DistanceForSprint, (c, v) => c.Infantry.DistanceForSprint = v),
            F("DistanceForSoldierStop", GfInfantryTransport, 0.2f, "Порог остановки бойца в точке назначения (м).", c => c.Infantry.DistanceForSoldierStop, (c, v) => c.Infantry.DistanceForSoldierStop = v),
            F("GlobalForestSpeedMultiplier", GfInfantryTransport, 0.5f, "Множитель скорости техники/юнитов в лесу.", c => c.GameConfig.GlobalForestSpeedMultiplier, (c, v) => c.GameConfig.GlobalForestSpeedMultiplier = v),
            F("InfantryForestSpeedMultiplier", GfInfantryTransport, 1f, "Множитель скорости пехоты в лесу.", c => c.GameConfig.InfantryForestSpeedMultiplier, (c, v) => c.GameConfig.InfantryForestSpeedMultiplier = v),
            F("PhysicsElasticity", GfInfantryTransport, 0.275f, "Упругость столкновений техники.", c => c.GameConfig.PhysicsElasticity, (c, v) => c.GameConfig.PhysicsElasticity = v),
            F("HelicopterLowMultiplier", GfInfantryTransport, 0.5f, "Множитель высоты/скорости вертолёта на малой высоте.", c => c.GameConfig.HelicopterLowMultiplier, (c, v) => c.GameConfig.HelicopterLowMultiplier = v),
            F("HelicopterCrashLowAltitude", GfInfantryTransport, 20f, "Высота срабатывания столкновения падающего вертолёта с землёй.", c => c.GameConfig.HelicopterCrashLowAltitude, (c, v) => c.GameConfig.HelicopterCrashLowAltitude = v),
            U("HouseUnloadDelay", GfInfantryTransport, 3u, "Задержка высадки пехоты сразу в здание.", c => c.GameConfig.HouseUnloadDelay, (c, v) => c.GameConfig.HouseUnloadDelay = v),
            F("TransportUnloadDelay", GfInfantryTransport, 0f, "Базовая задержка высадки десанта из транспорта (с).", c => c.GameConfig.TransportUnloadDelay, (c, v) => c.GameConfig.TransportUnloadDelay = v),
            F("HouseUnloadSprintMultiplier", GfInfantryTransport, 1.5f, "Множитель ускорения пехоты при высадке в здание.", c => c.GameConfig.HouseUnloadSprintMultiplier, (c, v) => c.GameConfig.HouseUnloadSprintMultiplier = v),
            U("TransportLoadDistance", GfInfantryTransport, 10u, "Дистанция мгновенной посадки в транспорт (м).", c => c.GameConfig.TransportLoadDistance, (c, v) => c.GameConfig.TransportLoadDistance = v),
            U("TransportLoadDistanceWithAnimation", GfInfantryTransport, 18u, "Дистанция посадки с анимацией подбегания (м).", c => c.GameConfig.TransportLoadDistanceWithAnimation, (c, v) => c.GameConfig.TransportLoadDistanceWithAnimation = v),
            F("WaitingTimeForLoadingInQueue", GfInfantryTransport, 0.3f, "Интервал ожидания очереди на посадку в транспорт (с).", c => c.GameConfig.WaitingTimeForLoadingInQueue, (c, v) => c.GameConfig.WaitingTimeForLoadingInQueue = v),
            F("TransportLoadingHelpPointsOffset", GfInfantryTransport, 0.6f, "Смещение вспомогательных точек посадки у транспорта.", c => c.GameConfig.TransportLoadingHelpPointsOffset, (c, v) => c.GameConfig.TransportLoadingHelpPointsOffset = v),
            F("MaxTimeForLoadOneUnit", GfInfantryTransport, 5f, "Таймаут ожидания одного бойца/отряда при посадке (с).", c => c.GameConfig.MaxTimeForLoadOneUnit, (c, v) => c.GameConfig.MaxTimeForLoadOneUnit = v),
            I("OnTransportDeathCargoForcedStressPercentage", GfInfantryTransport, 100, "Принудительный стресс десанту при уничтожении транспорта (%).", c => c.GameConfig.OnTransportDeathCargoForcedStressPercentage, (c, v) => c.GameConfig.OnTransportDeathCargoForcedStressPercentage = v),
            I("OnTransportUnloadCargoForcedStressPercentage", GfInfantryTransport, 50, "Принудительный стресс десанту при аварийной высадке (%).", c => c.GameConfig.OnTransportUnloadCargoForcedStressPercentage, (c, v) => c.GameConfig.OnTransportUnloadCargoForcedStressPercentage = v),
            I("OnTransportDeathCargoKillFloor", GfInfantryTransport, 30, "Мин. урон/потери десанта при гибели наземного транспорта (%).", c => c.GameConfig.OnTransportDeathCargoKillFloor, (c, v) => c.GameConfig.OnTransportDeathCargoKillFloor = v),
            F("OnTransportDeathCargoKillMultiplier", GfInfantryTransport, 1f, "Множитель потерь десанта при гибели наземного транспорта.", c => c.GameConfig.OnTransportDeathCargoKillMultiplier, (c, v) => c.GameConfig.OnTransportDeathCargoKillMultiplier = v),
            I("OnTransportDeathCargoKillHLFloor", GfInfantryTransport, 50, "Мин. потери десанта при крушении вертолёта на малой высоте (%).", c => c.GameConfig.OnTransportDeathCargoKillHLFloor, (c, v) => c.GameConfig.OnTransportDeathCargoKillHLFloor = v),
            F("OnTransportDeathCargoKillHLMultiplier", GfInfantryTransport, 0.5f, "Множитель потерь десанта при крушении вертолёта на малой высоте.", c => c.GameConfig.OnTransportDeathCargoKillHLMultiplier, (c, v) => c.GameConfig.OnTransportDeathCargoKillHLMultiplier = v),
            I("OnTransportDeathCargoKillHHFloor", GfInfantryTransport, 100, "Мин. потери десанта при крушении вертолёта на большой высоте (%).", c => c.GameConfig.OnTransportDeathCargoKillHHFloor, (c, v) => c.GameConfig.OnTransportDeathCargoKillHHFloor = v),
            F("OnTransportDeathCargoKillHHMultiplier", GfInfantryTransport, 0f, "Множитель потерь десанта при крушении вертолёта на большой высоте.", c => c.GameConfig.OnTransportDeathCargoKillHHMultiplier, (c, v) => c.GameConfig.OnTransportDeathCargoKillHHMultiplier = v),
            I("OnTransportDeathCargoKillAirFloor", GfInfantryTransport, 100, "Мин. потери десанта при гибели самолёта (%).", c => c.GameConfig.OnTransportDeathCargoKillAirFloor, (c, v) => c.GameConfig.OnTransportDeathCargoKillAirFloor = v),
            F("OnTransportDeathCargoKillAirMultiplier", GfInfantryTransport, 0f, "Множитель потерь десанта при гибели самолёта.", c => c.GameConfig.OnTransportDeathCargoKillAirMultiplier, (c, v) => c.GameConfig.OnTransportDeathCargoKillAirMultiplier = v)
        };

        public static readonly IReadOnlyList<AmmoFieldMeta> AmmoFields = new[]
        {
            new AmmoFieldMeta("TrajectoryType", "Тип и ГСН", "TrajectoryType", isInt: true, isTrajectoryEnum: true),
            new AmmoFieldMeta("Seeker", "Тип и ГСН", "Seeker (ГСН)", isInt: true, isSeekerEnum: true),

            new AmmoFieldMeta("LaserGuided", "Флаги", "LaserGuided", isBool: true),
            new AmmoFieldMeta("CanReaquire", "Флаги", "CanReaquire", isBool: true),
            new AmmoFieldMeta("CanBeIntercepted", "Флаги", "CanBeIntercepted", isBool: true),
            new AmmoFieldMeta("CanBeTargeted", "Флаги", "CanBeTargeted", isBool: true),
            new AmmoFieldMeta("Airburst", "Флаги", "Airburst", isBool: true),
            new AmmoFieldMeta("TopArmorAttack", "Флаги", "TopArmorAttack", isBool: true),
            new AmmoFieldMeta("IsTopArmorArmorAttack", "Флаги", "IsTopArmorArmorAttack", isBool: true),

            new AmmoFieldMeta("MinimalRange", "Дальности", "MinimalRange"),
            new AmmoFieldMeta("GroundRange", "Дальности", "GroundRange"),
            new AmmoFieldMeta("LowAltRange", "Дальности", "LowAltRange"),
            new AmmoFieldMeta("HighAltRange", "Дальности", "HighAltRange"),
            new AmmoFieldMeta("NonSeadProjectileRangeOverride", "Дальности", "NonSeadRangeOverride"),
            new AmmoFieldMeta("SeadProjectileRangeOverride", "Дальности", "SeadRangeOverride"),
            new AmmoFieldMeta("OverflyHeight", "Дальности", "OverflyHeight"),

            new AmmoFieldMeta("MuzzleVelocity", "Скорость и двигатель", "MuzzleVelocity"),
            new AmmoFieldMeta("MaxSpeed", "Скорость и двигатель", "MaxSpeed"),
            new AmmoFieldMeta("Acceleration", "Скорость и двигатель", "Acceleration"),
            new AmmoFieldMeta("BurnTime", "Скорость и двигатель", "BurnTime"),
            new AmmoFieldMeta("AimStartDelay", "Скорость и двигатель", "AimStartDelay"),
            new AmmoFieldMeta("MainEngineIgnitionDelay", "Скорость и двигатель", "MainEngineIgnitionDelay"),

            new AmmoFieldMeta("DispersionHorizontalRadius", "Разброс", "DispersionHorizontalRadius"),
            new AmmoFieldMeta("DispersionVerticalRadius", "Разброс", "DispersionVerticalRadius"),
            new AmmoFieldMeta("DispersionMinimal", "Разброс", "DispersionMinimal"),

            new AmmoFieldMeta("LaunchMarginAngle", "Углы и ГСН", "LaunchMarginAngle"),
            new AmmoFieldMeta("LoftAngle", "Углы и ГСН", "LoftAngle"),
            new AmmoFieldMeta("LoftHeight", "Углы и ГСН", "LoftHeight"),
            new AmmoFieldMeta("RotationSpeed", "Углы и ГСН", "RotationSpeed"),
            new AmmoFieldMeta("PreEgnitionRotationSpeed", "Углы и ГСН", "PreEgnitionRotationSpeed"),
            new AmmoFieldMeta("SeekerAngle", "Углы и ГСН", "SeekerAngle"),
            new AmmoFieldMeta("MaxSeekerDistance", "Углы и ГСН", "MaxSeekerDistance"),
            new AmmoFieldMeta("RadioFuseDistance", "Углы и ГСН", "RadioFuseDistance")
        };

        public static IReadOnlyList<CustomTrajectoryDto> CreateTrajectoryTemplates() => new[]
        {
            new CustomTrajectoryDto
            {
                Id = 1001,
                Name = "Сверхвысокая дуга (Top-Attack)",
                Description = "Высокий асимметричный профиль дуги с крутым заходом сверху и флагом Top-Attack.",
                BaseTrajectoryType = 20,
                UseCustomHeightFormula = true,
                HeightFormula = "apogee * pow(t, 0.45) * pow(1 - t, 0.25) * 2.2",
                MinRefDistance = 100f,
                MinApogee = 80f,
                MaxRefDistance = 2000f,
                MaxApogee = 600f,
                ForceTopAttack = true
            },
            new CustomTrajectoryDto
            {
                Id = 1002,
                Name = "Гиперзвуковой прямой выстрел (Railgun)",
                Description = "Почти плоская траектория прямой наводкой с минимальной гравитацией и x2 скоростью.",
                BaseTrajectoryType = 10,
                UseCustomHeightFormula = false,
                HeightFormula = "0",
                GravityMultiplier = 0.08f,
                SpeedMultiplier = 2.0f
            },
            new CustomTrajectoryDto
            {
                Id = 1003,
                Name = "Волнообразная / змейка-дуга",
                Description = "Баллистическая/РСЗО дуга с синусоидальной модуляцией высоты по траектории.",
                BaseTrajectoryType = 40,
                UseCustomHeightFormula = true,
                HeightFormula = "apogee * 4 * t * (1 - t) + 35 * sin(t * 18.8495559)",
                MinRefDistance = 200f,
                MinApogee = 50f,
                MaxRefDistance = 2000f,
                MaxApogee = 240f
            },
            new CustomTrajectoryDto
            {
                Id = 1004,
                Name = "Ступенчатая горка-пикирование",
                Description = "Быстрый набор потолка на старте, полёт на полке и крутое пикирование в цель.",
                BaseTrajectoryType = 20,
                UseCustomHeightFormula = true,
                HeightFormula = "t < 0.2 ? apogee * (t / 0.2) : (t < 0.8 ? apogee : apogee * ((1 - t) / 0.2))",
                MinRefDistance = 200f,
                MinApogee = 120f,
                MaxRefDistance = 2000f,
                MaxApogee = 380f,
                ForceTopAttack = true
            },
            new CustomTrajectoryDto
            {
                Id = 1005,
                Name = "Гиперманевренная ракета с горкой",
                Description = "Ускорение, скорость, манёвр и выраженная горка + удар в крышу для ПТУР/ЗУР.",
                BaseTrajectoryType = 120,
                UseCustomHeightFormula = false,
                HeightFormula = "apogee * 4 * t * (1 - t)",
                SpeedMultiplier = 1.35f,
                AccelerationMultiplier = 1.5f,
                RotationSpeedMultiplier = 1.8f,
                LoftHeightOverride = 180,
                LoftAngleOverride = 35,
                ForceTopAttack = true
            }
        };
    }
}
