using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using TrajectoryEditorShared;

namespace TrajectoryEditor
{
    public sealed class FormulaReferenceControl : UserControl
    {
        public event Action<int> NavigateToTabRequested;
        public event Action ConfigChanged;
        public event Action SaveRequested;

        private TrajectoryConfig _config = new TrajectoryConfig();
        private bool _suppressEvents;

        private TextBox _txtSearch;
        private CheckBox _chkOnlyEditable;
        private ListBox _lstCategories;
        private ListBox _lstFormulas;
        private Label _lblCount;
        private Button _btnGoToEdit;
        private RichTextBox _rtb;

        // Панель живого редактирования формулы
        private GroupBox _grpEditor;
        private CheckBox _chkOverrideEnabled;
        private Label _lblVarsHint;
        private TextBox _txtFormulaExpr;
        private TextBox _txtTestInputs;
        private Label _lblValidation;
        private Button _btnApplyFormula;
        private Button _btnResetFormula;
        private Button _btnSaveFormula;
        private Label _lblStatus;

        private readonly List<FormulaEntry> _visibleInCategory = new List<FormulaEntry>();
        private FormulaEntry _selectedSingleFormula;
        private int _currentPrimaryTabIndex = -1;

        public FormulaReferenceControl()
        {
            BuildUi();
        }

        private void BuildUi()
        {
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1
            };
            UiLayoutHelper.ApplyInitialSplit(split, minPanel1: 240, minPanel2: 480, fixedPanel1: 325);

            // Левая панель: поиск, фильтр редактируемых, категории и список формул
            var leftLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 6,
                ColumnCount = 1,
                Padding = new Padding(6)
            };
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 36f));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 64f));

            _txtSearch = new TextBox
            {
                Dock = DockStyle.Fill,
                PlaceholderText = "Поиск формулы, класса или параметра..."
            };
            _txtSearch.TextChanged += (_, _) => RebuildFormulaList();

            _chkOnlyEditable = new CheckBox
            {
                Text = "Только изменяемые в игре (10)",
                AutoSize = true,
                Margin = new Padding(0, 6, 0, 2)
            };
            _chkOnlyEditable.CheckedChanged += (_, _) => RebuildFormulaList();

            var lblCat = new Label
            {
                Text = "Категории формул",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 6, 0, 3)
            };

            _lstCategories = new ListBox
            {
                Dock = DockStyle.Fill,
                IntegralHeight = false
            };
            foreach (string cat in FormulaCatalog.Categories)
                _lstCategories.Items.Add(cat);
            _lstCategories.SelectedIndex = 0;
            _lstCategories.SelectedIndexChanged += (_, _) =>
            {
                if (_suppressEvents) return;
                RebuildFormulaList();
            };

            var lblList = new Label
            {
                Text = "Формулы в выборке",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 8, 0, 3)
            };

            _lstFormulas = new ListBox
            {
                Dock = DockStyle.Fill,
                IntegralHeight = false
            };
            _lstFormulas.SelectedIndexChanged += (_, _) =>
            {
                if (_suppressEvents) return;
                RenderSelectedFormulas();
            };

            leftLayout.Controls.Add(_txtSearch, 0, 0);
            leftLayout.Controls.Add(_chkOnlyEditable, 0, 1);
            leftLayout.Controls.Add(lblCat, 0, 2);
            leftLayout.Controls.Add(_lstCategories, 0, 3);
            leftLayout.Controls.Add(lblList, 0, 4);
            leftLayout.Controls.Add(_lstFormulas, 0, 5);
            split.Panel1.Controls.Add(leftLayout);

            // Правая панель: сверху описание, снизу редактор формулы
            var rightSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal
            };
            UiLayoutHelper.ApplyInitialSplit(rightSplit, ratio: 0.62, minPanel1: 200, minPanel2: 180);

            var topRightLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                Padding = new Padding(6, 6, 6, 3)
            };
            topRightLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            topRightLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            var toolbar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(4),
                BackColor = Color.FromArgb(242, 244, 248),
                WrapContents = true
            };

            _lblCount = new Label
            {
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                ForeColor = Color.FromArgb(26, 59, 110),
                Margin = new Padding(4, 6, 14, 4)
            };

            var btnCopy = new Button
            {
                Text = "Копировать текст",
                AutoSize = true
            };
            btnCopy.Click += (_, _) =>
            {
                if (!string.IsNullOrEmpty(_rtb.Text))
                    Clipboard.SetText(_rtb.Text);
            };

            _btnGoToEdit = new Button
            {
                Text = "Перейти к параметрам →",
                AutoSize = true,
                BackColor = Color.FromArgb(224, 236, 250)
            };
            _btnGoToEdit.Click += (_, _) =>
            {
                if (_currentPrimaryTabIndex >= 0)
                    NavigateToTabRequested?.Invoke(_currentPrimaryTabIndex);
            };

            toolbar.Controls.AddRange(new Control[] { _lblCount, btnCopy, _btnGoToEdit });

            _rtb = new RichTextBox
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ScrollBars = RichTextBoxScrollBars.Vertical,
                WordWrap = true,
                DetectUrls = false
            };

            topRightLayout.Controls.Add(toolbar, 0, 0);
            topRightLayout.Controls.Add(_rtb, 0, 1);
            rightSplit.Panel1.Controls.Add(topRightLayout);

            // Нижний редактор формулы
            _grpEditor = new GroupBox
            {
                Text = "Редактор формулы (живой патч в игре через TrajectoryEditorMod)",
                Dock = DockStyle.Fill,
                Padding = new Padding(8)
            };

            var edLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 5,
                ColumnCount = 2
            };
            edLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65f));
            edLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35f));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            _chkOverrideEnabled = new CheckBox
            {
                Text = "Включить свою формулу в игре",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 2, 0, 4)
            };
            _chkOverrideEnabled.CheckedChanged += (_, _) =>
            {
                if (_suppressEvents) return;
                CommitEditorToConfig();
            };

            _lblVarsHint = new Label
            {
                AutoSize = true,
                ForeColor = Color.FromArgb(45, 70, 110),
                Margin = new Padding(0, 0, 0, 4)
            };

            var lblExprHdr = new Label
            {
                Text = "Выражение (поддержка: + - * / % ^, ?:, < > <= >= == != && ||, min, max, clamp, sqrt, pow, sin, cos, abs, if, lerp):",
                AutoSize = true,
                Margin = new Padding(0, 2, 6, 2)
            };
            var lblTestHdr = new Label
            {
                Text = "Тестовые входы (var=val; ...):",
                AutoSize = true,
                Margin = new Padding(6, 2, 0, 2)
            };

            _txtFormulaExpr = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 10f)
            };
            _txtFormulaExpr.TextChanged += (_, _) => UpdateValidationAndTestPreview();

            _txtTestInputs = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 9.5f),
                Margin = new Padding(6, 0, 0, 0)
            };
            _txtTestInputs.TextChanged += (_, _) => UpdateValidationAndTestPreview();

            _lblValidation = new Label
            {
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 4, 0, 4)
            };

            var btnFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(0, 2, 0, 0),
                WrapContents = true
            };

            _btnApplyFormula = new Button { Text = "Применить выражение", AutoSize = true };
            _btnApplyFormula.Click += (_, _) => CommitEditorToConfig();

            _btnResetFormula = new Button { Text = "Сбросить к ванили", AutoSize = true };
            _btnResetFormula.Click += (_, _) => ResetSelectedFormulaToVanilla();

            _btnSaveFormula = new Button
            {
                Text = "Сохранить (TrajectoryEditor.json)",
                AutoSize = true,
                BackColor = Color.FromArgb(215, 238, 215),
                Font = new Font(Font, FontStyle.Bold)
            };
            _btnSaveFormula.Click += (_, _) =>
            {
                if (CommitEditorToConfig())
                    SaveRequested?.Invoke();
            };

            _lblStatus = new Label { AutoSize = true, Margin = new Padding(10, 6, 4, 4), ForeColor = Color.DimGray };
            btnFlow.Controls.AddRange(new Control[] { _btnApplyFormula, _btnResetFormula, _btnSaveFormula, _lblStatus });

            edLayout.Controls.Add(_chkOverrideEnabled, 0, 0);
            edLayout.SetColumnSpan(_chkOverrideEnabled, 2);
            edLayout.Controls.Add(_lblVarsHint, 0, 1);
            edLayout.SetColumnSpan(_lblVarsHint, 2);
            // Put headers via Panel or insert directly in row 2/3 — adjust to 6 rows cleanly:
            edLayout.Controls.Clear();
            edLayout.RowCount = 6;
            edLayout.RowStyles.Clear();
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            edLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            edLayout.Controls.Add(_chkOverrideEnabled, 0, 0);
            edLayout.SetColumnSpan(_chkOverrideEnabled, 2);
            edLayout.Controls.Add(_lblVarsHint, 0, 1);
            edLayout.SetColumnSpan(_lblVarsHint, 2);
            edLayout.Controls.Add(lblExprHdr, 0, 2);
            edLayout.Controls.Add(lblTestHdr, 1, 2);
            edLayout.Controls.Add(_txtFormulaExpr, 0, 3);
            edLayout.Controls.Add(_txtTestInputs, 1, 3);
            edLayout.Controls.Add(_lblValidation, 0, 4);
            edLayout.SetColumnSpan(_lblValidation, 2);
            edLayout.Controls.Add(btnFlow, 0, 5);
            edLayout.SetColumnSpan(btnFlow, 2);

            _grpEditor.Controls.Add(edLayout);
            rightSplit.Panel2.Controls.Add(_grpEditor);
            split.Panel2.Controls.Add(rightSplit);
            Controls.Add(split);

            RebuildFormulaList();
        }

        public void BindConfig(TrajectoryConfig config)
        {
            _config = config ?? new TrajectoryConfig();
            RebuildFormulaList();
        }

        public void RefreshFromConfigExternal(TrajectoryConfig config)
        {
            _config = config ?? new TrajectoryConfig();
            RenderSelectedFormulas(preserveEditorInputs: _txtFormulaExpr.Focused || _txtTestInputs.Focused);
        }

        public void SetStatus(string text, Color color)
        {
            _lblStatus.Text = text;
            _lblStatus.ForeColor = color;
        }

        private void RebuildFormulaList()
        {
            string prevSelectedTitle = _lstFormulas.SelectedIndex > 0 && _lstFormulas.SelectedIndex - 1 < _visibleInCategory.Count
                ? _visibleInCategory[_lstFormulas.SelectedIndex - 1].Title
                : null;

            _visibleInCategory.Clear();
            string cat = _lstCategories.SelectedItem as string ?? FormulaCatalog.CatAll;
            string query = (_txtSearch.Text ?? string.Empty).Trim();
            bool onlyEdit = _chkOnlyEditable.Checked;

            foreach (FormulaEntry entry in FormulaCatalog.Formulas)
            {
                if (onlyEdit && entry.EditableSpec == null)
                    continue;

                if (!string.Equals(cat, FormulaCatalog.CatAll, StringComparison.Ordinal) &&
                    !string.Equals(entry.Category, cat, StringComparison.Ordinal))
                    continue;

                if (!string.IsNullOrEmpty(query) && !MatchesQuery(entry, query))
                    continue;

                _visibleInCategory.Add(entry);
            }

            _suppressEvents = true;
            try
            {
                _lstFormulas.Items.Clear();
                _lstFormulas.Items.Add($"— Показать все ({_visibleInCategory.Count}) —");
                int idxToSelect = 0;
                for (int i = 0; i < _visibleInCategory.Count; i++)
                {
                    FormulaEntry fe = _visibleInCategory[i];
                    string prefix = string.Empty;
                    if (fe.EditableSpec != null)
                    {
                        bool active = _config.FormulaOverrides.TryGetValue(fe.EditableSpec.OverrideKey, out CustomFormulaDto ov) && ov.Enabled;
                        prefix = active ? "[АКТИВНА ★] " : "[ИЗМЕНЯЕМАЯ] ";
                    }
                    _lstFormulas.Items.Add(prefix + fe.Title);
                    if (prevSelectedTitle != null && string.Equals(fe.Title, prevSelectedTitle, StringComparison.Ordinal))
                        idxToSelect = i + 1;
                }
                _lstFormulas.SelectedIndex = idxToSelect;
            }
            finally
            {
                _suppressEvents = false;
            }

            RenderSelectedFormulas();
        }

        private static bool MatchesQuery(FormulaEntry e, string q)
        {
            if (e.Title.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (e.EngineRef.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (e.Equation.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (e.VariablesRu.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (e.NotesRu.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (e.EditableSpec != null && e.EditableSpec.OverrideKey.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;

            foreach (FormulaParamRef p in e.Params)
            {
                if (p.Key.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            return false;
        }

        private void RenderSelectedFormulas(bool preserveEditorInputs = false)
        {
            IReadOnlyList<FormulaEntry> toShow;
            int sel = _lstFormulas.SelectedIndex;
            if (sel > 0 && sel - 1 < _visibleInCategory.Count)
            {
                _selectedSingleFormula = _visibleInCategory[sel - 1];
                toShow = new[] { _selectedSingleFormula };
            }
            else
            {
                _selectedSingleFormula = null;
                toShow = _visibleInCategory;
            }

            _lblCount.Text = $"Показано формул: {toShow.Count} из {FormulaCatalog.Formulas.Count}";
            _currentPrimaryTabIndex = toShow.Count > 0 ? toShow[0].PrimaryTabIndex : -1;
            _btnGoToEdit.Enabled = _currentPrimaryTabIndex >= 0;

            using var fontTitle = new Font("Segoe UI", 11f, FontStyle.Bold);
            using var fontCat = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            using var fontRef = new Font("Segoe UI", 8.5f, FontStyle.Italic);
            using var fontEq = new Font("Consolas", 10f, FontStyle.Bold);
            using var fontReg = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            using var fontBold = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            using var fontParam = new Font("Consolas", 9f, FontStyle.Regular);
            using var fontParamMod = new Font("Consolas", 9f, FontStyle.Bold);

            _rtb.SuspendLayout();
            _rtb.Clear();

            if (toShow.Count == 0)
            {
                AppendText("По текущему фильтру формул не найдено.", fontReg, Color.DimGray);
                _rtb.ResumeLayout();
                LoadSelectedFormulaIntoEditor(preserveEditorInputs);
                return;
            }

            for (int i = 0; i < toShow.Count; i++)
            {
                FormulaEntry e = toShow[i];
                if (i > 0)
                    AppendText("────────────────────────────────────────────────────────────────────────────────────\n\n", fontReg, Color.Silver);

                AppendText($"[{e.Category}]", fontCat, Color.SteelBlue);
                if (e.EditableSpec != null)
                {
                    bool active = _config.FormulaOverrides.TryGetValue(e.EditableSpec.OverrideKey, out CustomFormulaDto ov) && ov.Enabled;
                    AppendText(active ? "  [АКТИВНА СВОЯ ФОРМУЛА ★]" : "  [ИЗМЕНЯЕМАЯ В ИГРЕ ★]", fontCat, active ? Color.DarkOrange : Color.ForestGreen);
                }
                AppendText("\n", fontCat, Color.SteelBlue);

                AppendText($"{e.Title}\n", fontTitle, Color.FromArgb(26, 59, 110));
                AppendText($"Код движка: {e.EngineRef}\n\n", fontRef, Color.DimGray);

                AppendText("Формула (ваниль):\n", fontBold, Color.FromArgb(50, 50, 50));
                foreach (string line in e.Equation.Split('\n'))
                    AppendText($"    {line}\n", fontEq, Color.FromArgb(18, 18, 18));
                AppendText("\n", fontReg, Color.Black);

                if (e.EditableSpec != null &&
                    _config.FormulaOverrides.TryGetValue(e.EditableSpec.OverrideKey, out CustomFormulaDto customDto) &&
                    !string.IsNullOrWhiteSpace(customDto.Expression))
                {
                    AppendText(customDto.Enabled ? "Активная пользовательская формула:\n" : "Сохранённая формула (выключена):\n", fontBold, Color.DarkOrange);
                    AppendText($"    {customDto.Expression}\n\n", fontEq, Color.DarkOrange);
                }

                AppendText("Переменные: ", fontBold, Color.FromArgb(50, 50, 50));
                AppendText($"{e.VariablesRu}\n", fontReg, Color.FromArgb(40, 40, 40));

                AppendText("Примечание: ", fontBold, Color.FromArgb(50, 50, 50));
                AppendText($"{e.NotesRu}\n", fontReg, Color.FromArgb(65, 65, 65));

                if (e.Params.Count > 0)
                {
                    AppendText("\nПараметры в текущем конфиге:\n", fontBold, Color.FromArgb(50, 50, 50));
                    foreach (FormulaParamRef p in e.Params)
                    {
                        string cur = p.CurrentTextGetter(_config);
                        bool mod = p.IsModified(_config);
                        string line = $"  • {p.Key} = {cur}  (ваниль: {p.VanillaText})";
                        if (mod) line += "  ★ ИЗМЕНЕНО";
                        AppendText(line + "\n", mod ? fontParamMod : fontParam, mod ? Color.DarkOrange : Color.FromArgb(55, 65, 81));
                    }
                }

                if (e.LiveExampleFunc != null)
                {
                    AppendText("\nРасчёт по текущим значениям: ", fontBold, Color.FromArgb(27, 94, 32));
                    AppendText($"{e.LiveExampleFunc(_config)}\n\n", fontReg, Color.FromArgb(27, 94, 32));
                }
                else
                {
                    AppendText("\n", fontReg, Color.Black);
                }
            }

            _rtb.Select(0, 0);
            _rtb.ScrollToCaret();
            _rtb.ResumeLayout();

            LoadSelectedFormulaIntoEditor(preserveEditorInputs);
        }

        private void LoadSelectedFormulaIntoEditor(bool preserveInputs)
        {
            if (preserveInputs && _selectedSingleFormula?.EditableSpec != null)
                return;

            EditableFormulaSpec spec = _selectedSingleFormula?.EditableSpec;
            bool editable = spec != null;

            _suppressEvents = true;
            try
            {
                _chkOverrideEnabled.Enabled = editable;
                _txtFormulaExpr.Enabled = editable;
                _txtTestInputs.Enabled = editable;
                _btnApplyFormula.Enabled = editable;
                _btnResetFormula.Enabled = editable;

                if (!editable)
                {
                    _chkOverrideEnabled.Checked = false;
                    _lblVarsHint.Text = _selectedSingleFormula == null
                        ? "Выберите конкретную формулу с пометкой [ИЗМЕНЯЕМАЯ] в списке слева, чтобы изменить её математику."
                        : "Эта формула не имеет отдельного математического хука — её параметры меняются на вкладке «Формулы игры / Саплай / Авиация».";
                    _txtFormulaExpr.Text = string.Empty;
                    _txtTestInputs.Text = string.Empty;
                    _lblValidation.Text = string.Empty;
                    return;
                }

                _lblVarsHint.Text = $"Ключ: {spec.OverrideKey}  |  Доступные переменные: {string.Join(", ", spec.AllowedVariables)}";
                if (_config.FormulaOverrides.TryGetValue(spec.OverrideKey, out CustomFormulaDto dto))
                {
                    _chkOverrideEnabled.Checked = dto.Enabled;
                    _txtFormulaExpr.Text = string.IsNullOrWhiteSpace(dto.Expression) ? spec.DefaultExpression : dto.Expression;
                }
                else
                {
                    _chkOverrideEnabled.Checked = false;
                    _txtFormulaExpr.Text = spec.DefaultExpression;
                }
                _txtTestInputs.Text = spec.DefaultTestInputs;
            }
            finally
            {
                _suppressEvents = false;
            }

            UpdateValidationAndTestPreview();
        }

        private bool ValidateCurrentExpression(EditableFormulaSpec spec, out CompiledExpression compiled, out string errorMsg)
        {
            compiled = null;
            if (!FormulaExpressionEngine.TryCompile(_txtFormulaExpr.Text, out compiled, out errorMsg))
                return false;

            var allowed = new HashSet<string>(spec.AllowedVariables, StringComparer.OrdinalIgnoreCase);
            foreach (string v in compiled.GetReferencedVariables())
            {
                if (!allowed.Contains(v))
                {
                    errorMsg = $"Неизвестная переменная '{v}'. Допустимы: {string.Join(", ", spec.AllowedVariables)}";
                    return false;
                }
            }
            return true;
        }

        private void UpdateValidationAndTestPreview()
        {
            EditableFormulaSpec spec = _selectedSingleFormula?.EditableSpec;
            if (spec == null)
                return;

            if (!ValidateCurrentExpression(spec, out CompiledExpression customCompiled, out string err))
            {
                _lblValidation.Text = $"Ошибка выражения: {err}";
                _lblValidation.ForeColor = Color.Firebrick;
                return;
            }

            Dictionary<string, double> vars = ParseTestInputs(_txtTestInputs.Text, spec);
            double customOut = customCompiled.Evaluate(vars);

            string vanillaStr = "?";
            if (FormulaExpressionEngine.TryCompile(spec.DefaultExpression, out CompiledExpression defCompiled, out _))
                vanillaStr = defCompiled.Evaluate(vars).ToString("0.####", CultureInfo.InvariantCulture);

            string customStr = customOut.ToString("0.####", CultureInfo.InvariantCulture);
            _lblValidation.Text = $"Синтаксис OK  |  Тест-расчёт: Ваниль = {vanillaStr}  |  Своя = {customStr}";
            _lblValidation.ForeColor = _chkOverrideEnabled.Checked ? Color.ForestGreen : Color.FromArgb(26, 59, 110);
        }

        private Dictionary<string, double> ParseTestInputs(string text, EditableFormulaSpec spec)
        {
            var dict = spec.ConfigVarsInjector != null
                ? spec.ConfigVarsInjector(_config)
                : new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(text))
                return dict;

            string[] parts = text.Split(new[] { ';', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string part in parts)
            {
                int eq = part.IndexOf('=');
                if (eq <= 0) continue;
                string key = part.Substring(0, eq).Trim();
                string valStr = part.Substring(eq + 1).Trim().Replace(',', '.');
                if (double.TryParse(valStr, NumberStyles.Float, CultureInfo.InvariantCulture, out double val))
                    dict[key] = val;
            }
            return dict;
        }

        private bool CommitEditorToConfig()
        {
            EditableFormulaSpec spec = _selectedSingleFormula?.EditableSpec;
            if (spec == null)
                return true;

            if (!ValidateCurrentExpression(spec, out _, out string err))
            {
                MessageBox.Show($"Формула содержит ошибку:\n{err}", "Ошибка формулы", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _suppressEvents = true;
                _chkOverrideEnabled.Checked = false;
                _suppressEvents = false;
                return false;
            }

            _config.FormulaOverrides[spec.OverrideKey] = new CustomFormulaDto
            {
                Enabled = _chkOverrideEnabled.Checked,
                Expression = _txtFormulaExpr.Text.Trim()
            };

            UpdateValidationAndTestPreview();
            RebuildFormulaList();
            ConfigChanged?.Invoke();
            return true;
        }

        private void ResetSelectedFormulaToVanilla()
        {
            EditableFormulaSpec spec = _selectedSingleFormula?.EditableSpec;
            if (spec == null)
                return;

            _suppressEvents = true;
            try
            {
                _chkOverrideEnabled.Checked = false;
                _txtFormulaExpr.Text = spec.DefaultExpression;
                _txtTestInputs.Text = spec.DefaultTestInputs;
            }
            finally
            {
                _suppressEvents = false;
            }

            _config.FormulaOverrides.Remove(spec.OverrideKey);
            UpdateValidationAndTestPreview();
            RebuildFormulaList();
            ConfigChanged?.Invoke();
        }

        private void AppendText(string text, Font font, Color color)
        {
            _rtb.SelectionStart = _rtb.TextLength;
            _rtb.SelectionLength = 0;
            _rtb.SelectionFont = font;
            _rtb.SelectionColor = color;
            _rtb.AppendText(text);
        }
    }
}
