using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using HarmonyLib;
using Il2CppBrokenArrow.Client.Ecs.BattleSystem;
using Il2CppBrokenArrow.Client.Ecs.BattleSystem.Ballistics;
using Il2CppBrokenArrow.Client.Ecs.BattleSystem.Components;
using Il2CppBrokenArrow.Client.Ecs.BattleSystem.Systems;
using Il2CppBrokenArrow.Client.Ecs.Commands;
using Il2CppBrokenArrow.Client.Ecs.Configs;
using Il2CppBrokenArrow.Client.Ecs.Controllers;
using Il2CppBrokenArrow.Client.Ecs.FogOfWar;
using Il2CppBrokenArrow.Client.Ecs.Planes;
using Il2CppBrokenArrow.Client.Ecs.Planes.Components;
using Il2CppBrokenArrow.Core.Security;
using Il2CppBrokenArrow.DataBase;
using Il2CppBrokenArrow.DataBase.Enums;
using Il2CppBrokenArrow.DataBase.Models;
using Il2CppBrokenArrow.Shared.Ecs;
using Il2CppDefaultEcs;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using MelonLoader;
using TrajectoryEditorShared;
using UnityEngine;

[assembly: MelonInfo(typeof(TrajectoryEditorMod.TrajectoryEditorMod), "TrajectoryEditorMod", "1.2.7", "Antigravity")]
[assembly: MelonGame(null, null)]
[assembly: HarmonyDontPatchAll]

namespace TrajectoryEditorMod
{
    public sealed class CurveKeyDto
    {
        public float Time { get; set; }
        public float Value { get; set; }
        public float InTangent { get; set; }
        public float OutTangent { get; set; }
    }

    public sealed class PlanesDto
    {
        public float BombingStartTimeOffset { get; set; } = 3f;
        public float BombingStartTimeOffsetHighDrag { get; set; } = 3f;
        public float BombDropOffset { get; set; } = -25f;
        public float BombDropOffsetHighDrag { get; set; } = -25f;
        public float BombDropOffsetAmmoAoeMult { get; set; } = 0.8f;
        public bool EnableStratBomberCircling { get; set; } = true;

        public float StrafeMinLength { get; set; } = 100f;
        public float StrafeMaxLength { get; set; } = 400f;
        public float StrafeSearchRadius { get; set; } = 50f;
        public float StrafeStartTimeOffset { get; set; } = 1f;
        public float StrafeWeaponPointOffset { get; set; } = 1.75f;

        public float PrecisionMinAllowedAngle { get; set; } = 10f;
        public ushort PrecisionFlyAwayExtraDistance { get; set; } = 300;

        public float HighAltitude { get; set; } = 400f;
        public float LowAltitude { get; set; } = 100f;
        public ushort FuelRedZoneBaseValue { get; set; } = 20;
        public float FuelOrangeZoneSizeRatio { get; set; } = 1f;
        public uint FuelOutChance { get; set; } = 100u;
        public uint DeathChance { get; set; } = 0u;
        public float NextPointStepMultiplier { get; set; } = 0.5f;
        public float DecreaseSpeedAngle { get; set; } = 30f;

        public float PlaneVsPlaneStopDistance { get; set; } = 200f;
        public float PlaneVsPlaneEscapeDistance { get; set; } = 120f;
        public float PlaneVsHeliDiveAngle { get; set; } = 15f;
        public float PlaneVsHeliNoseUpExtraHeight { get; set; } = 10f;

        public float DEATH_MASS { get; set; } = 50f;
        public float DEATH_DRAG { get; set; } = 0.03f;
        public float DEATH_ANGULAR_DRAG { get; set; } = 100f;
        public float DEATH_ENGINE_POWER_MULT { get; set; } = 2f;
        public float DEATH_ROTATE_POWER_MULT { get; set; } = 0.15f;
        public float DEATH_START_EPOWER_MULT { get; set; } = 1.5f;
        public float DEATH_START_RPOWER_MULT { get; set; } = 0f;
        public float DEATH_BLAST_POWER_MULT { get; set; } = 50f;
    }

    public sealed class SupplyDto
    {
        public int SupplyValueBought { get; set; } = 10;
        public int SupplyExchangeRate { get; set; } = 1000;
        public float ResupplyRadius { get; set; } = 75f;
        public float AmmoCostMultiplier { get; set; } = 4f;
        public float RepairRate { get; set; } = 0.35f;
        public float RepairCost { get; set; } = 25f;
        public float HealingCost { get; set; } = 0.5f;
        public float HealingRate { get; set; } = 1f;
        public float AbilityResupplyRate { get; set; } = 50f;
        public float AbilityMultiplierHeal { get; set; } = 0.5f;
        public float AbilityMultiplierRepair { get; set; } = 0.5f;
        public float AbilityMultiplierRearm { get; set; } = 0.5f;
        public float ViewDistance { get; set; } = 0f;
        public bool ShowEnemySupplyRadius { get; set; } = true;
    }

    public sealed class CombatFormulasDto
    {
        public float ARMOR_PENETRATION_EFFECTIVENESS { get; set; } = 1f;
        public float MINIMAL_DAMAGE_COEFFICIENT { get; set; } = 0.1f;
        public float HE_ARMOR_EFFECTIVENESS { get; set; } = 1f;
        public float HEAT_CURVE_COEFFICIENT { get; set; } = 2f;
        public float CQCTick { get; set; } = 0.3f;
        public float CQCChance { get; set; } = 1f;
        public float PLANES_DAMAGE_SCORE_MULTIPLIER { get; set; } = 1f;
        public float RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES { get; set; } = 1f;
        public float RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES { get; set; } = 1f;

        public float SEAD_SCORE_MULTIPLIER { get; set; } = 0.99f;
        public float MINIMAL_CHANCE_TO_KILL { get; set; } = 0.8f;
        public float GUIDED_SELECTION_DAMAGE_TRESHHOLD { get; set; } = 1.4f;
        public float APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD { get; set; } = 5f;
        public bool GUIDED_IGNORE_UNGUIDED_ON_PLANES { get; set; } = true;
        public bool GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES { get; set; } = true;
        public bool ACTIVE_APS_IGNORES_ONE_MISSILE { get; set; } = true;
        public bool HP_LIMIT_WEAPON_SCORE { get; set; } = true;
        public bool PRIORITIZE_ONE_SHOT_TARGETS { get; set; } = true;
        public bool PREVENT_GUIDED_OVERKILL { get; set; } = true;
        public float MISSILE_OVERKILL_CLEAR_DELAY { get; set; } = 0.25f;
        public bool FORCE_MISSILE_MISS_DAMAGE { get; set; } = true;
        public float MISSILE_MISS_OVERKILL_CLEAR_DELAY { get; set; } = 1f;
        public int MAX_FLARES_COUNT_MISSILE_INITIAL { get; set; } = 100;
        public int MAX_FLARES_COUNT_MISSILE_REROLL { get; set; } = 1;
        public float AUTOFLARES_PLANES_DELAY { get; set; } = 1.5f;
        public float AUTOFLARES_HELICOPTERS_DELAY { get; set; } = 0.5f;
        public bool AUTOSMOKE_TRIGGER_BY_GUNS { get; set; } = false;
        public bool AUTOSMOKE_TRIGGER_BY_MISSILES { get; set; } = true;
        public float AUTOSMOKE_DELAY_MIN { get; set; } = 3f;
        public float AUTOSMOKE_DELAY_MAX { get; set; } = 5f;
        public bool AUTOSMOKE_AI_TRIGGER_BY_GUNS { get; set; } = true;
        public bool AUTOSMOKE_AI_TRIGGER_BY_MISSILES { get; set; } = true;
        public float AUTOSMOKE_AI_DELAY_MIN { get; set; } = 2f;
        public float AUTOSMOKE_AI_DELAY_MAX { get; set; } = 8f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY { get; set; } = 0.25f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM { get; set; } = 0.5f;
        public float AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD { get; set; } = 0.75f;
        public float MAX_TIME_WITHOUT_TARGET { get; set; } = 1f;
    }

    public sealed class GameConfigDto
    {
        public float DefaultPlayerMoney { get; set; } = 1000f;
        public float DefaultIncomePerMin { get; set; } = 300f;
        public float UpkeepMultiplier { get; set; } = 1.66667f;
        public float PlanesUpkeepMultiplier { get; set; } = 0f;
        public float DeadUnitsValueMultiplier { get; set; } = 0f;
        public float DeckCategoryValueMargin { get; set; } = 0.1f;

        public float DespawnDelaySec { get; set; } = 5f;
        public float RefundMultiplier { get; set; } = 1f;
        public float RefundLostAmmoTimeMultiplier { get; set; } = 0f;
        public float RepurchaseDelayFloor { get; set; } = 30f;
        public float RepurchaseDelayMultiplier { get; set; } = 0.5f;
        public float PlanesRefundFloor { get; set; } = 60f;
        public float PlanesRefundHPMultiplier { get; set; } = 0.5f;
        public float PlanesRefundAmmoCoeff_K { get; set; } = 1f;
        public float PlanesRefundAmmoCoeff_P { get; set; } = 5f;
        public bool PlanesDeathIsMultiplierOfRefund { get; set; } = true;
        public float PlanesDeathRefundMultiplier { get; set; } = 2.5f;
        public float MinimumRefundPercent { get; set; } = 20f;
        public float MaximumRefundPercent { get; set; } = 90f;
        public float HealthCostMultiplier { get; set; } = 0.5f;
        public bool ResurrectionEnabled { get; set; } = true;
        public float ResurrectDelayFloor { get; set; } = 420f;
        public float ResurrectDelayMultiplier { get; set; } = 1.5f;
        public float PlanesDeathPenalty { get; set; } = 0f;

        public float PhysicsElasticity { get; set; } = 0.275f;
        public float CoverSnapDistance { get; set; } = 8f;
        public float CoverSnapSingleUnitModifier { get; set; } = 1f;
        public float SprintSpeed { get; set; } = 10f;
        public float GlobalForestSpeedMultiplier { get; set; } = 0.5f;
        public float InfantryForestSpeedMultiplier { get; set; } = 1f;
        public float HelicopterLowMultiplier { get; set; } = 0.5f;
        public float HelicopterCrashLowAltitude { get; set; } = 20f;
        public uint HouseUnloadDelay { get; set; } = 3u;
        public float TransportUnloadDelay { get; set; } = 0f;
        public float HouseUnloadSprintMultiplier { get; set; } = 1.5f;
        public int OnTransportDeathCargoForcedStressPercentage { get; set; } = 100;
        public int OnTransportUnloadCargoForcedStressPercentage { get; set; } = 50;
        public int OnTransportDeathCargoKillFloor { get; set; } = 30;
        public float OnTransportDeathCargoKillMultiplier { get; set; } = 1f;
        public int OnTransportDeathCargoKillHLFloor { get; set; } = 50;
        public float OnTransportDeathCargoKillHLMultiplier { get; set; } = 0.5f;
        public int OnTransportDeathCargoKillHHFloor { get; set; } = 100;
        public float OnTransportDeathCargoKillHHMultiplier { get; set; } = 0f;
        public int OnTransportDeathCargoKillAirFloor { get; set; } = 100;
        public float OnTransportDeathCargoKillAirMultiplier { get; set; } = 0f;
        public int OnBuildingDestroyPrecentage { get; set; } = 60;
        public uint TransportLoadDistance { get; set; } = 10u;
        public uint TransportLoadDistanceWithAnimation { get; set; } = 18u;
        public float WaitingTimeForLoadingInQueue { get; set; } = 0.3f;
        public float TransportLoadingHelpPointsOffset { get; set; } = 0.6f;
        public float MaxTimeForLoadOneUnit { get; set; } = 5f;
    }

    public sealed class FogOfWarDto
    {
        public float MinimumDetectionDistance { get; set; } = 45f;
        public float MaxShootableForestDistance { get; set; } = 45f;
        public float LaserForestMaxRange { get; set; } = 45f;
        public float LaserOwnForestRange { get; set; } = 25f;
        public float FlashReduction { get; set; } = 0.15f;
        public float MaxFlashValue { get; set; } = 4.5f;
        public float MaxAntiVisible { get; set; } = 1.5f;
        public float SpottedPenalty { get; set; } = 2f;
        public float SpottedPenaltyBuildings { get; set; } = 2f;
        public float SneakMinAntivisible { get; set; } = 0.2f;
    }

    public sealed class BuffsDto
    {
        public float ShockedLevelMultiplier { get; set; } = 0.5f;
        public float PanickedLevelMultiplier { get; set; } = 0.8f;
        public float ShockedLevelMultiplierInfantry { get; set; } = 0.4f;
        public float PanickedLevelMultiplierInfantry { get; set; } = 0.8f;
        public float StressRecoveryMultiplier { get; set; } = 1f;
        public float StressDamageModThreshold { get; set; } = 36f;
        public float CriticalBaseProbability { get; set; } = 0.02f;
        public int RedCritsActivationThreshold { get; set; } = 2;
        public float MinorAimTimeMultiplier { get; set; } = 1.5f;
        public float MajorAimTimeMultiplier { get; set; } = 2f;
        public float MinorOpticsMultiplier { get; set; } = 0.66f;
        public float MajorOpticsMultiplier { get; set; } = 0.33f;
        public float MinorMobilityMultiplier { get; set; } = 0.75f;
        public float MinorMobilityMultiplierRotation { get; set; } = 0.5f;
        public float MinorDispersionMultiplier { get; set; } = 1.15f;
        public float MajorDispersionMultiplier { get; set; } = 1.52f;
        public float MinorLoadingMultiplier { get; set; } = 1.5f;
        public float MajorLoadingMultiplier { get; set; } = 2f;
    }

    public sealed class BuildingsDto
    {
        public int BuildingDamageThreshold { get; set; } = 5;
        public float DamageModifierFloor { get; set; } = 0.18f;
        public float DamageModifierPerSoldier { get; set; } = 0.02f;
        public float HitColliderReduction { get; set; } = 1f;
    }

    public sealed class InfantryDto
    {
        public uint BaseSquadSize { get; set; } = 1u;
        public float InfantryDeathTime { get; set; } = 30f;
        public float HorizontalTurretRotationSpeed { get; set; } = 180f;
        public float StartMovingMaxDelay { get; set; } = 0.5f;
        public float RunSpeed { get; set; } = 5f;
        public float SprintSpeed { get; set; } = 10f;
        public float KneelRunSpeed { get; set; } = 3f;
        public float ProneRunSpeed { get; set; } = 1f;
        public float ProneSprintSpeed { get; set; } = 2f;
        public float RotationSpeed { get; set; } = 180f;
        public float ShootAimRotationSpeed { get; set; } = 11f;
        public float DistanceForSprint { get; set; } = 2f;
        public float DistanceForSoldierStop { get; set; } = 0.2f;
    }

    public sealed class CustomFormulaDto
    {
        public bool Enabled { get; set; }
        public string Expression { get; set; } = string.Empty;
    }

    public sealed class CustomTrajectoryDto
    {
        public int Id { get; set; } = 1000;
        public string Name { get; set; } = "Новая траектория";
        public string Description { get; set; } = string.Empty;
        public int BaseTrajectoryType { get; set; } = 20;

        public bool UseCustomHeightFormula { get; set; } = true;
        public string HeightFormula { get; set; } = "apogee * 4 * t * (1 - t)";
        public float MinRefDistance { get; set; } = 100f;
        public float MinApogee { get; set; } = 40f;
        public float MaxRefDistance { get; set; } = 2000f;
        public float MaxApogee { get; set; } = 450f;

        public float GravityMultiplier { get; set; } = 1f;
        public float SpeedMultiplier { get; set; } = 1f;
        public float AccelerationMultiplier { get; set; } = 1f;
        public float BurnTimeMultiplier { get; set; } = 1f;
        public float RotationSpeedMultiplier { get; set; } = 1f;

        public int LoftHeightOverride { get; set; } = -1;
        public int LoftAngleOverride { get; set; } = -1;
        public bool ForceTopAttack { get; set; }
        public bool AllowPrecisionStrike { get; set; }
    }

    public sealed class WeaponTrajectoryAssignmentDto
    {
        public int AmmunitionId { get; set; }
        public string AmmunitionName { get; set; } = string.Empty;
        public string WeaponHint { get; set; } = string.Empty;
        public int CustomTrajectoryId { get; set; }
        public bool OverrideBaseTrajectoryType { get; set; } = true;
    }

    public sealed class TrajectoryConfigDto
    {
        public bool Enabled { get; set; } = true;

        // Траектории: Общие и DirectShot (10)
        public float G { get; set; } = 70f;
        public float MIN_POINT_DISPERSION { get; set; } = 15f;
        public float MAX_POINT_DISPERSION_MULTIPLIER { get; set; } = 3f;
        public float ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS { get; set; } = 0f;
        public float BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE { get; set; } = 10f;
        public float MAX_WEAPON_AIMING_IMPRECISION { get; set; } = 0.5f;
        public float MAX_WEAPON_AIMING_CHECK_TRESHOLD { get; set; } = 30f;

        // Траектории: Артиллерия (20), Миномёты (30), РСЗО (40)
        public float MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1000f;
        public float MAX_ARTILLERY_SHOT_APOGEE_DISTANCE { get; set; } = 650f;
        public float MAX_ARTILLERY_SHOT_APOGEE { get; set; } = 250f;
        public float MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE { get; set; } = 100f;
        public float MIN_ARTILLERY_SHOT_APOGEE { get; set; } = 10f;
        public float MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1000f;
        public float MAX_MORTAR_SHOT_APOGEE { get; set; } = 350f;
        public float MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE { get; set; } = 1f;
        public float MIN_MORTAR_SHOT_APOGEE { get; set; } = 400f;
        public List<CurveKeyDto> ARTILLERY_DISPERSION_CDF { get; set; } = new List<CurveKeyDto>
        {
            new CurveKeyDto { Time = 0f, Value = 0f, InTangent = 2f, OutTangent = 2f },
            new CurveKeyDto { Time = 1f, Value = 1f, InTangent = 0.048455f, OutTangent = 0.048455f }
        };

        // Траектории: Ракеты (100 / 110 / 120)
        public float START_LEAD_MISSILE_SPEED_PROPORTION { get; set; } = 0.4f;
        public float FULL_LEAD_MISSILE_SPEED_PROPORTION { get; set; } = 0.9f;
        public float MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION { get; set; } = 10f;
        public float MISSILE_DECELERATION_PROPORTION { get; set; } = 0.13f;
        public float MISSILE_DEATH_SPEED_PROPORTION { get; set; } = 0.3f;
        public float LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION { get; set; } = 0.33f;
        public float MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION { get; set; } = 0.2f;
        public float MISSILE_NO_TARGET_SUPPORT_TIME { get; set; } = 2f;
        public float MISSILE_NO_TARGET_SUPPORT_TIME_TG { get; set; } = 0f;
        public bool SEAD_MISSILES_GO_TO_LAST_POSITION { get; set; } = false;
        public float MINIMAL_MISSILE_MISS_DISTANCE { get; set; } = 100f;
        public float MAX_MISSILE_MISS_DISTANCE_PROPORTION { get; set; } = 0.8f;
        public float MAX_MISSILE_MISS_DISTANCE_CAP { get; set; } = 200f;
        public float MISSILE_MISS_ADDITIONAL_CLEARENCE { get; set; } = 10f;
        public float RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN { get; set; } = 0.6f;
        public float RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX { get; set; } = 1.4f;
        public float RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER { get; set; } = 0f;
        public float MISSILE_MERGE_POWER { get; set; } = 1f;
        public byte MISSILE_SWITCH_RULE { get; set; } = 10;

        // Траектории: Крылатые ракеты (200)
        public float CRUISE_MISSILE_TARGET_HEIGHT { get; set; } = 65f;
        public float CRUISE_MISSILE_DIVE_ANGLE { get; set; } = 60f;
        public float PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE { get; set; } = 30f;
        public float CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT { get; set; } = 1f;
        public int CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION { get; set; } = 15;
        public float[] CRUISE_MISSILE_PID { get; set; } = new[] { 0.2f, 0.0f, 13.0f };
        public List<CurveKeyDto> CRUISE_MISSILE_HEIGHTS_COEFFICIENTS { get; set; } = new List<CurveKeyDto>
        {
            new CurveKeyDto { Time = 0f, Value = 0f, InTangent = 6.60151f, OutTangent = 6.60151f },
            new CurveKeyDto { Time = 0.108248f, Value = 1.00001f, InTangent = 5.42224f, OutTangent = 0.158478f },
            new CurveKeyDto { Time = 1f, Value = 0.05f, InTangent = -0.999213f, OutTangent = -0.999213f }
        };

        // Траектории: Баллистические ракеты (300)
        public float BALLISTIC_MISSILES_APOAPSIS { get; set; } = 2500f;
        public float INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION { get; set; } = 0.33f;
        public float INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION { get; set; } = 1.0f;

        // Траектории: Бомбы (400 / 410)
        public float BOMBS_GRAVITY_MULTIPLYER { get; set; } = 1.0f;
        public float HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER { get; set; } = 0.5f;
        public float HIGH_DRAG_BOMBS_DECELERATION_PROPORTION { get; set; } = 0.1f;
        public float BOMB_HORIZONTAL_MARGIN { get; set; } = 30f;
        public float BOMB_UPPER_MARGIN { get; set; } = -1f;
        public bool DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN { get; set; } = true;

        // Траектории: Лазерное планирование (610) и Сорванные ракеты (666)
        public float LASER_MAX_GLIDING_ANGLE { get; set; } = 10f;
        public float LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE { get; set; } = 90f;
        public float MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME { get; set; } = 1.5f;
        public float MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN { get; set; } = 0.4f;
        public float MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX { get; set; } = 1.2f;
        public float SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS { get; set; } = 0f;

        // Секции настроек
        public PlanesDto Planes { get; set; } = new PlanesDto();
        public SupplyDto Supply { get; set; } = new SupplyDto();
        public CombatFormulasDto CombatFormulas { get; set; } = new CombatFormulasDto();
        public GameConfigDto GameConfig { get; set; } = new GameConfigDto();
        public FogOfWarDto FogOfWar { get; set; } = new FogOfWarDto();
        public BuffsDto Buffs { get; set; } = new BuffsDto();
        public BuildingsDto Buildings { get; set; } = new BuildingsDto();
        public InfantryDto Infantry { get; set; } = new InfantryDto();

        // Пользовательские формулы и конструктор траекторий
        public Dictionary<string, CustomFormulaDto> FormulaOverrides { get; set; } = new Dictionary<string, CustomFormulaDto>(StringComparer.Ordinal);
        public List<CustomTrajectoryDto> CustomTrajectories { get; set; } = new List<CustomTrajectoryDto>();
        public List<WeaponTrajectoryAssignmentDto> WeaponTrajectoryAssignments { get; set; } = new List<WeaponTrajectoryAssignmentDto>();
        public List<int> PrecisionStrikeAmmoIds { get; set; } = new List<int>();
    }

    internal sealed class ResolvedTrajectoryOverride
    {
        public WeaponTrajectoryAssignmentDto Assignment;
        public CustomTrajectoryDto Trajectory;
        public CompiledExpression HeightExpr;
    }

    internal sealed class AmmoVanillaSnapshot
    {
        public TrajectoryType TrajectoryType;
        public TargetType TargetType;
        public int LoftHeight;
        public int LoftAngle;
        public float MaxSpeed;
        public float Acceleration;
        public float BurnTime;
        public float RotationSpeed;
        public float PreEgnitionRotationSpeed;
        public bool TopArmorAttack;
    }

    internal sealed class RuntimePatchState
    {
        public bool Enabled;
        public Dictionary<string, CompiledExpression> Formulas = new Dictionary<string, CompiledExpression>(StringComparer.Ordinal);
        public Dictionary<int, ResolvedTrajectoryOverride> AmmoOverrides = new Dictionary<int, ResolvedTrajectoryOverride>();
        public HashSet<int> PrecisionAmmoIds = new HashSet<int>();
        public float Effectiveness = 1f;
        public float MinCoeff = 0.1f;
        public float HeatP = 2f;
        public float HeatK = 1f;
        public float FowMinDist = 45f;
    }

    public sealed class TrajectoryEditorMod : MelonMod
    {
        private const string ConfigRelPath = @"UserData\TrajectoryEditor.json";
        private const string AmmoJsonRelPath = @"UserData\MLDatabaseMod\actual\Ammunitions.json";
        private static readonly JsonSerializerOptions JsonOpts = new JsonSerializerOptions
        {
            WriteIndented = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true
        };

        private static MelonLogger.Instance _log;
        private static string _configPath;
        private static string _ammoJsonPath;
        private static DateTime _lastWriteUtc;
        private static long _lastConfigLength = -1;
        private static string _lastConfigText = string.Empty;
        private static DateTime _lastAmmoWriteUtc;
        private static long _lastAmmoLength = -1;
        private static bool _reloading;
        private static GameController _lastController;
        private static readonly Stopwatch _pollTimer = new Stopwatch();

        internal static volatile RuntimePatchState _runtime = new RuntimePatchState();
        private static readonly Dictionary<int, AmmoVanillaSnapshot> _vanillaAmmo = new Dictionary<int, AmmoVanillaSnapshot>();
        private static readonly Dictionary<ulong, WeaponComponent> _weaponByEntity = new Dictionary<ulong, WeaponComponent>();
        private static readonly HashSet<string> _diagLogged = new HashSet<string>(StringComparer.Ordinal);
        [ThreadStatic] private static bool _inTargetMaintenancePrecision;
        [ThreadStatic] private static ulong _tmActiveWeaponKey;
        [ThreadStatic] private static WeaponComponent _tmActiveWeapon;
        private static readonly Dictionary<ulong, int> _tmRemoveBlockCount = new Dictionary<ulong, int>();

        private static void LogPrecisionDiagOnce(string key, string message)
        {
            if (_log == null || string.IsNullOrEmpty(key))
                return;
            if (_diagLogged.Add(key))
                _log.Msg($"[TrajectoryEditorMod] [PrecisionDiag] {message}");
        }

        public override void OnInitializeMelon()
        {
            _log = LoggerInstance;
            _configPath = Path.GetFullPath(ConfigRelPath);
            _ammoJsonPath = Path.GetFullPath(AmmoJsonRelPath);

            EnsureConfigFile();
            SnapshotAmmoJsonState();
            _pollTimer.Restart();

            TrajectoryConfigDto initialCfg = LoadConfigAndSnapshot();
            if (initialCfg != null)
                RebuildRuntimeState(initialCfg);

            PatchCoreHooks();
            PatchFormulaHooks();
            PatchTrajectoryAndDbHooks();

            _log.Msg($"[TrajectoryEditorMod] Инициализирован v1.2.7. Конфиг: {_configPath} (формул={_runtime.Formulas.Count}, траекторий={_runtime.AmmoOverrides.Count}, precision={_runtime.PrecisionAmmoIds.Count})");
        }

        private void PatchCoreHooks()
        {
            TryPatch(
                typeof(GameConfig).GetMethod(nameof(GameConfig.InitConfigs), BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null, Type.EmptyTypes, null),
                postfix: nameof(GameConfig_InitConfigs_Postfix),
                label: "GameConfig.InitConfigs");

            TryPatch(
                typeof(GameController).GetMethod(nameof(GameController.BattleSystemConstantsLoad), BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null, Type.EmptyTypes, null),
                prefix: nameof(BattleSystemConstantsLoad_Prefix),
                label: "GameController.BattleSystemConstantsLoad");
        }

        private void PatchFormulaHooks()
        {
            const BindingFlags bf = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.DamageFormulaKinetic), bf, null, new[] { typeof(float), typeof(float), typeof(float) }, null),
                prefix: nameof(DamageFormulaKinetic_Prefix),
                label: "BattleSystemHelpers.DamageFormulaKinetic");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.DamageFormulaHEAT), bf, null, new[] { typeof(float), typeof(float), typeof(float) }, null),
                prefix: nameof(DamageFormulaHEAT_Prefix),
                label: "BattleSystemHelpers.DamageFormulaHEAT");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.CalculateHitDamageWithThreshold), bf, null, new[] { typeof(float), typeof(float), typeof(bool) }, null),
                prefix: nameof(CalculateHitDamageWithThreshold_Prefix),
                label: "BattleSystemHelpers.CalculateHitDamageWithThreshold");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.GetPenetration), bf, null, new[] { typeof(ArmorType), typeof(float), typeof(float), typeof(float), typeof(float), typeof(float) }, null),
                prefix: nameof(GetPenetration_Prefix),
                label: "BattleSystemHelpers.GetPenetration");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.CalculateStressDamage), bf, null, new[] { typeof(float), typeof(float), typeof(float), typeof(float) }, null),
                prefix: nameof(CalculateStressDamage_Prefix),
                label: "BattleSystemHelpers.CalculateStressDamage");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.CalculateCountermeasuresEffect), bf, null, new[] { typeof(float), typeof(float), typeof(int) }, null),
                prefix: nameof(CalculateCountermeasuresEffect_Prefix),
                label: "BattleSystemHelpers.CalculateCountermeasuresEffect");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.CalculateMissileHitChance), bf, null, new[] { typeof(float), typeof(float), typeof(float), typeof(float), typeof(int), typeof(float), typeof(float), typeof(float) }, null),
                prefix: nameof(CalculateMissileHitChance8_Prefix),
                label: "BattleSystemHelpers.CalculateMissileHitChance(8)");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.CalculateMissileHitChance), bf, null, new[] { typeof(Ammunitions), typeof(float), typeof(float), typeof(int), typeof(float) }, null),
                prefix: nameof(CalculateMissileHitChance5_Prefix),
                label: "BattleSystemHelpers.CalculateMissileHitChance(5)");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.GetTargetAccuracy), bf, null, new[] { typeof(Ammunitions), typeof(Units), typeof(float) }, null),
                postfix: nameof(GetTargetAccuracy_Postfix),
                label: "BattleSystemHelpers.GetTargetAccuracy");

            TryPatch(
                typeof(FogOfWarUnit).GetMethod(nameof(FogOfWarUnit.CalculateVisionRangeForTarget), BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance),
                postfix: nameof(CalculateVisionRangeForTarget_Postfix),
                label: "FogOfWarUnit.CalculateVisionRangeForTarget");

            TryPatch(
                typeof(AircraftHelper).GetMethod(nameof(AircraftHelper.GetRotationRadius), bf, null, new[] { typeof(float), typeof(float) }, null),
                prefix: nameof(GetRotationRadius_Prefix),
                label: "AircraftHelper.GetRotationRadius");
        }

        private void PatchTrajectoryAndDbHooks()
        {
            const BindingFlags bfInst = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            const BindingFlags bfStat = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

            TryPatch(
                typeof(DataBaseService).GetMethod(nameof(DataBaseService.Load), bfInst, null, Type.EmptyTypes, null),
                postfix: nameof(DataBaseService_Load_Postfix),
                label: "DataBaseService.Load");

            TryPatch(
                typeof(DataBaseService).GetMethod(nameof(DataBaseService.LoadByJson), bfInst, null, Type.EmptyTypes, null),
                postfix: nameof(DataBaseService_Load_Postfix),
                label: "DataBaseService.LoadByJson");

            TryPatch(
                typeof(Ammunitions).GetMethod(nameof(Ammunitions.IsPrecisionAmmo), bfInst, null, Type.EmptyTypes, null),
                postfix: nameof(Ammunitions_IsPrecisionAmmo_Postfix),
                label: "Ammunitions.IsPrecisionAmmo");

            TryPatch(
                typeof(PrecisionStrikeCommand).GetMethod(nameof(PrecisionStrikeCommand.PreActivate), bfInst, null, new[] { typeof(Entity) }, null),
                postfix: nameof(PrecisionStrikeCommand_PreActivate_Postfix),
                label: "PrecisionStrikeCommand.PreActivate");

            TryPatch(
                typeof(PrecisionStrikeCommand).GetMethod(nameof(PrecisionStrikeCommand.IsCompleted), bfInst, null, new[] { typeof(Entity) }, null),
                postfix: nameof(PrecisionStrikeCommand_IsCompleted_Postfix),
                label: "PrecisionStrikeCommand.IsCompleted");

            TryPatch(
                typeof(PrecisionStrikeCommand).GetMethod(nameof(PrecisionStrikeCommand.OnActivate), bfInst, null, new[] { typeof(Entity) }, null),
                postfix: nameof(PrecisionStrikeCommand_OnActivate_Postfix),
                label: "PrecisionStrikeCommand.OnActivate");

            TryPatch(
                typeof(PrecisionStrikeSystem).GetMethod(nameof(PrecisionStrikeSystem.InternalUpdate), bfInst, null, new[] { typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(PrecisionStrikeSystem_InternalUpdate_Prefix),
                postfix: nameof(PrecisionStrikeSystem_InternalUpdate_Postfix),
                label: "PrecisionStrikeSystem.InternalUpdate");

            TryPatch(
                typeof(TargetMaintenanceSystem).GetMethod(nameof(TargetMaintenanceSystem.InternalUpdate), bfInst, null, new[] { typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(TargetMaintenance_InternalUpdate_Prefix),
                postfix: nameof(TargetMaintenance_InternalUpdate_Postfix),
                label: "TargetMaintenanceSystem.InternalUpdate");

            TryPatch(
                typeof(BattleSystemHelpers).GetMethod(nameof(BattleSystemHelpers.RemoveGroundTarget), bfStat, null, new[] { typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(RemoveGroundTarget_Prefix),
                label: "BattleSystemHelpers.RemoveGroundTarget");

            TryPatch(
                typeof(WeaponHullRotationSystem).GetMethod(nameof(WeaponHullRotationSystem.InternalUpdate), bfInst, null, new[] { typeof(float), typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(WeaponHullRotation_InternalUpdate_Prefix),
                postfix: nameof(WeaponHullRotation_InternalUpdate_Postfix),
                label: "WeaponHullRotationSystem.InternalUpdate");

            TryPatch(
                typeof(WeaponAimingCalculationSystem).GetMethod(nameof(WeaponAimingCalculationSystem.InternalUpdate), bfInst, null, new[] { typeof(float), typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(WeaponAiming_InternalUpdate_Prefix),
                postfix: nameof(WeaponAiming_InternalUpdate_Postfix),
                label: "WeaponAimingCalculationSystem.InternalUpdate");

            TryPatch(
                typeof(ShootingSystem).GetMethod(nameof(ShootingSystem.InternalUpdate), bfInst, null, new[] { typeof(Entity).MakeByRefType(), typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(Shooting_InternalUpdate_Prefix),
                postfix: nameof(Shooting_InternalUpdate_Postfix),
                label: "ShootingSystem.InternalUpdate");

            TryPatch(
                typeof(ProjectileSpawnerHelper).GetMethod(nameof(ProjectileSpawnerHelper.SpawnTrajectoryShell), bfStat, null, new[] { typeof(ProjectileSpawnerHelper.ShellSpawnData), typeof(TrajectoryStruct) }, null),
                prefix: nameof(SpawnTrajectoryShell_Prefix),
                label: "ProjectileSpawnerHelper.SpawnTrajectoryShell");

            TryPatch(
                typeof(ProjectileSpawnerHelper).GetMethod(nameof(ProjectileSpawnerHelper.SpawnMissile), bfStat, null, new[] { typeof(ProjectileSpawnerHelper.ShellSpawnData), typeof(Entity).MakeByRefType(), typeof(Entity).MakeByRefType() }, null),
                prefix: nameof(SpawnMissile_Prefix),
                label: "ProjectileSpawnerHelper.SpawnMissile");
        }

        private void TryPatch(MethodInfo target, string prefix = null, string postfix = null, string label = null)
        {
            if (target == null)
            {
                _log.Warning($"[TrajectoryEditorMod] Не найден метод для патча: {label}");
                return;
            }
            try
            {
                HarmonyMethod pre = prefix != null ? new HarmonyMethod(typeof(TrajectoryEditorMod).GetMethod(prefix, BindingFlags.Static | BindingFlags.NonPublic)) : null;
                HarmonyMethod post = postfix != null ? new HarmonyMethod(typeof(TrajectoryEditorMod).GetMethod(postfix, BindingFlags.Static | BindingFlags.NonPublic)) : null;
                HarmonyInstance.Patch(target, prefix: pre, postfix: post);
            }
            catch (Exception ex)
            {
                _log.Warning($"[TrajectoryEditorMod] Ошибка патча {label}: {ex.Message}");
            }
        }

        private static GameController GetActiveGameController()
        {
            try
            {
                if (GameController.IsInstanceAlive)
                {
                    GameController inst = GameController.Instance;
                    if (inst != null && !inst.WasCollected)
                    {
                        _lastController = inst;
                        return inst;
                    }
                }
            }
            catch
            {
                // Игнорируем во время смены сцены
            }

            return (_lastController != null && !_lastController.WasCollected) ? _lastController : null;
        }

        private static void SnapshotAmmoJsonState()
        {
            try
            {
                if (!string.IsNullOrEmpty(_ammoJsonPath) && File.Exists(_ammoJsonPath))
                {
                    var afi = new FileInfo(_ammoJsonPath);
                    _lastAmmoWriteUtc = afi.LastWriteTimeUtc;
                    _lastAmmoLength = afi.Length;
                }
            }
            catch { }
        }

        public override void OnUpdate()
        {
            if (_pollTimer.ElapsedMilliseconds < 500)
                return;

            _pollTimer.Restart();

            bool configUpdated = TryHotReloadMainConfig();
            bool ammoUpdated = TryHotReloadAmmunitionsJson();

            if (configUpdated || ammoUpdated)
            {
                int weaponsRefreshed = RefreshLiveWeaponsInWorld();
                if (configUpdated)
                {
                    _log.Msg($"[TrajectoryEditorMod] Горячая перезагрузка выполнена (формул: {_runtime.Formulas.Count}, присвоено БК: {_runtime.AmmoOverrides.Count}, precision: {_runtime.PrecisionAmmoIds.Count}, обновлено орудий: {weaponsRefreshed}).");
                }
            }
        }

        private static bool TryHotReloadMainConfig()
        {
            try
            {
                if (string.IsNullOrEmpty(_configPath) || !File.Exists(_configPath))
                    return false;

                var fi = new FileInfo(_configPath);
                if (fi.LastWriteTimeUtc == _lastWriteUtc && fi.Length == _lastConfigLength)
                    return false;

                string text;
                try
                {
                    text = File.ReadAllText(_configPath);
                }
                catch (IOException)
                {
                    // Файл ещё дописывается редактором — повторим на следующем тике
                    return false;
                }

                if (string.Equals(text, _lastConfigText, StringComparison.Ordinal))
                {
                    _lastWriteUtc = fi.LastWriteTimeUtc;
                    _lastConfigLength = fi.Length;
                    return false;
                }

                TrajectoryConfigDto cfg = DeserializeConfig(text);
                if (cfg == null)
                    return false;

                _diagLogged.Clear();
                RebuildRuntimeState(cfg);
                ApplyAmmoTrajectoryAssignments();

                GameConfig gameConfig = GameConfig.Instance;
                if (gameConfig != null && cfg.Enabled)
                    ApplyAllConfigs(cfg, gameConfig);

                BattleSystemSettings bss = gameConfig?.BattleSystemSettings;
                GameController ctrl = GetActiveGameController();
                if (ctrl != null)
                {
                    _reloading = true;
                    try
                    {
                        ctrl.BattleSystemConstantsLoad();
                        if (bss != null)
                            BallisticsCalculationsHelper.Init(bss);
                    }
                    finally
                    {
                        _reloading = false;
                    }
                }
                else if (bss != null)
                {
                    BallisticsCalculationsHelper.Init(bss);
                }

                _lastWriteUtc = fi.LastWriteTimeUtc;
                _lastConfigLength = fi.Length;
                _lastConfigText = text;
                return true;
            }
            catch (Exception ex)
            {
                _log.Error($"[TrajectoryEditorMod] Ошибка горячей перезагрузки TrajectoryEditor.json: {ex}");
                return false;
            }
        }

        private static bool TryHotReloadAmmunitionsJson()
        {
            try
            {
                if (string.IsNullOrEmpty(_ammoJsonPath) || !File.Exists(_ammoJsonPath))
                    return false;

                var afi = new FileInfo(_ammoJsonPath);
                if (afi.LastWriteTimeUtc == _lastAmmoWriteUtc && afi.Length == _lastAmmoLength)
                    return false;

                DataBaseService db = DataBaseService._instance;
                if (db == null || !db.IsLoaded)
                    return false;

                string json;
                try
                {
                    json = File.ReadAllText(_ammoJsonPath);
                }
                catch (IOException)
                {
                    // Повторим на следующем тике
                    return false;
                }

                int updatedCount = ApplyAmmunitionsJsonLive(db, json);
                _vanillaAmmo.Clear();
                ApplyAmmoTrajectoryAssignments();

                _lastAmmoWriteUtc = afi.LastWriteTimeUtc;
                _lastAmmoLength = afi.Length;
                _log.Msg($"[TrajectoryEditorMod] Горячее обновление Ammunitions.json применено (обновлено записей БД: {updatedCount}).");
                return true;
            }
            catch (Exception ex)
            {
                _log.Warning($"[TrajectoryEditorMod] Ошибка горячей перезагрузки Ammunitions.json: {ex.Message}");
                return false;
            }
        }

        private static void RebuildRuntimeState(TrajectoryConfigDto cfg)
        {
            var next = new RuntimePatchState
            {
                Enabled = cfg.Enabled,
                Effectiveness = cfg.CombatFormulas?.ARMOR_PENETRATION_EFFECTIVENESS ?? 1f,
                MinCoeff = cfg.CombatFormulas?.MINIMAL_DAMAGE_COEFFICIENT ?? 0.1f,
                HeatP = cfg.CombatFormulas?.HEAT_CURVE_COEFFICIENT ?? 2f,
                HeatK = cfg.CombatFormulas?.HE_ARMOR_EFFECTIVENESS ?? 1f,
                FowMinDist = cfg.FogOfWar?.MinimumDetectionDistance ?? 45f
            };

            if (cfg.Enabled && cfg.FormulaOverrides != null)
            {
                foreach (var kv in cfg.FormulaOverrides)
                {
                    if (kv.Value == null || !kv.Value.Enabled || string.IsNullOrWhiteSpace(kv.Value.Expression))
                        continue;

                    if (FormulaExpressionEngine.TryCompile(kv.Value.Expression, out CompiledExpression compiled, out string err))
                        next.Formulas[kv.Key] = compiled;
                    else
                        _log?.Warning($"[TrajectoryEditorMod] Не удалось скомпилировать формулу '{kv.Key}': {err}");
                }
            }

            if (cfg.Enabled && cfg.PrecisionStrikeAmmoIds != null)
            {
                foreach (int ammoId in cfg.PrecisionStrikeAmmoIds)
                {
                    if (ammoId > 0)
                        next.PrecisionAmmoIds.Add(ammoId);
                }
            }

            if (cfg.Enabled && cfg.CustomTrajectories != null && cfg.WeaponTrajectoryAssignments != null)
            {
                var compiledTraj = new Dictionary<int, (CustomTrajectoryDto dto, CompiledExpression expr)>();
                foreach (CustomTrajectoryDto ct in cfg.CustomTrajectories)
                {
                    if (ct == null) continue;
                    CompiledExpression hExpr = null;
                    if (ct.UseCustomHeightFormula && !string.IsNullOrWhiteSpace(ct.HeightFormula))
                    {
                        if (!FormulaExpressionEngine.TryCompile(ct.HeightFormula, out hExpr, out string hErr))
                            _log?.Warning($"[TrajectoryEditorMod] Ошибка HeightFormula в траектории #{ct.Id} ({ct.Name}): {hErr}");
                    }
                    compiledTraj[ct.Id] = (ct, hExpr);
                }

                foreach (WeaponTrajectoryAssignmentDto a in cfg.WeaponTrajectoryAssignments)
                {
                    if (a == null || a.AmmunitionId <= 0) continue;
                    if (compiledTraj.TryGetValue(a.CustomTrajectoryId, out var pair))
                    {
                        next.AmmoOverrides[a.AmmunitionId] = new ResolvedTrajectoryOverride
                        {
                            Assignment = a,
                            Trajectory = pair.dto,
                            HeightExpr = pair.expr
                        };
                        if (pair.dto.AllowPrecisionStrike)
                            next.PrecisionAmmoIds.Add(a.AmmunitionId);
                    }
                }
            }

            _runtime = next;
        }

        private static void ApplyAmmoTrajectoryAssignments()
        {
            try
            {
                DataBaseService db = DataBaseService._instance;
                if (db == null || !db.IsLoaded)
                    return;

                RuntimePatchState rt = _runtime;

                // 1. Сначала возвращаем ваниль для снятых или отключённых боеприпасов
                var toRestore = new List<int>();
                foreach (int ammoId in _vanillaAmmo.Keys)
                {
                    if (!rt.Enabled || (!rt.AmmoOverrides.ContainsKey(ammoId) && !rt.PrecisionAmmoIds.Contains(ammoId)))
                        toRestore.Add(ammoId);
                }

                foreach (int ammoId in toRestore)
                {
                    Ammunitions ammo = db.GetAmmunitionById(ammoId);
                    if (ammo != null && _vanillaAmmo.TryGetValue(ammoId, out AmmoVanillaSnapshot snap))
                    {
                        ammo.TrajectoryType = snap.TrajectoryType;
                        ammo.TargetType = snap.TargetType;
                        ammo.LoftHeight = snap.LoftHeight;
                        ammo.LoftAngle = snap.LoftAngle;
                        ammo.MaxSpeed = snap.MaxSpeed;
                        ammo.Acceleration = snap.Acceleration;
                        ammo.BurnTime = snap.BurnTime;
                        ammo.RotationSpeed = snap.RotationSpeed;
                        ammo.PreEgnitionRotationSpeed = snap.PreEgnitionRotationSpeed;
                        ammo.TopArmorAttack = snap.TopArmorAttack;
                    }
                    _vanillaAmmo.Remove(ammoId);
                }

                if (!rt.Enabled)
                    return;

                // 2. Собираем все боеприпасы с кастомной траекторией и/или Precision Strike
                var touchedIds = new HashSet<int>(rt.AmmoOverrides.Keys);
                foreach (int pid in rt.PrecisionAmmoIds)
                    touchedIds.Add(pid);

                foreach (int ammoId in touchedIds)
                {
                    Ammunitions ammo = db.GetAmmunitionById(ammoId);
                    if (ammo == null)
                        continue;

                    if (!_vanillaAmmo.TryGetValue(ammoId, out AmmoVanillaSnapshot snap))
                    {
                        snap = new AmmoVanillaSnapshot
                        {
                            TrajectoryType = ammo.TrajectoryType,
                            TargetType = ammo.TargetType,
                            LoftHeight = ammo.LoftHeight,
                            LoftAngle = ammo.LoftAngle,
                            MaxSpeed = ammo.MaxSpeed,
                            Acceleration = ammo.Acceleration,
                            BurnTime = ammo.BurnTime,
                            RotationSpeed = ammo.RotationSpeed,
                            PreEgnitionRotationSpeed = ammo.PreEgnitionRotationSpeed,
                            TopArmorAttack = ammo.TopArmorAttack
                        };
                        _vanillaAmmo[ammoId] = snap;
                    }

                    if (rt.AmmoOverrides.TryGetValue(ammoId, out ResolvedTrajectoryOverride ov))
                    {
                        CustomTrajectoryDto ct = ov.Trajectory;
                        ammo.TrajectoryType = ov.Assignment.OverrideBaseTrajectoryType
                            ? (TrajectoryType)ct.BaseTrajectoryType
                            : snap.TrajectoryType;

                        ammo.MaxSpeed = snap.MaxSpeed * Math.Max(0.05f, ct.SpeedMultiplier);
                        ammo.Acceleration = snap.Acceleration * Math.Max(0.05f, ct.AccelerationMultiplier);
                        ammo.BurnTime = snap.BurnTime * Math.Max(0.05f, ct.BurnTimeMultiplier);
                        ammo.RotationSpeed = snap.RotationSpeed * Math.Max(0.05f, ct.RotationSpeedMultiplier);
                        ammo.PreEgnitionRotationSpeed = snap.PreEgnitionRotationSpeed * Math.Max(0.05f, ct.RotationSpeedMultiplier);
                        ammo.LoftHeight = ct.LoftHeightOverride >= 0 ? ct.LoftHeightOverride : snap.LoftHeight;
                        ammo.LoftAngle = ct.LoftAngleOverride >= 0 ? ct.LoftAngleOverride : snap.LoftAngle;
                        ammo.TopArmorAttack = ct.ForceTopAttack || snap.TopArmorAttack;
                    }
                    else
                    {
                        ammo.TrajectoryType = snap.TrajectoryType;
                        ammo.MaxSpeed = snap.MaxSpeed;
                        ammo.Acceleration = snap.Acceleration;
                        ammo.BurnTime = snap.BurnTime;
                        ammo.RotationSpeed = snap.RotationSpeed;
                        ammo.PreEgnitionRotationSpeed = snap.PreEgnitionRotationSpeed;
                        ammo.LoftHeight = snap.LoftHeight;
                        ammo.LoftAngle = snap.LoftAngle;
                        ammo.TopArmorAttack = snap.TopArmorAttack;
                    }

                    bool isPrec = rt.PrecisionAmmoIds.Contains(ammoId);
                    ammo.TargetType = isPrec ? (snap.TargetType | TargetType.Ground) : snap.TargetType;
                    if (isPrec)
                    {
                        LogPrecisionDiagOnce($"db_{ammoId}_{(int)ammo.TargetType}_{(int)ammo.TrajectoryType}",
                            $"Precision БК #{ammoId} ({ammo.Name}): TargetType={(int)snap.TargetType}->{(int)ammo.TargetType}, Traj={(int)ammo.TrajectoryType}, GroundRange={ammo.GroundRange:0.#}");
                    }
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка применения траекторий к БД: {ex.Message}");
            }
        }

        // =====================================================================
        // HARMONY ХУКИ: БАЗА ДАННЫХ И ПОЛЬЗОВАТЕЛЬСКИЕ ТРАЕКТОРИИ
        // =====================================================================

        private static void DataBaseService_Load_Postfix()
        {
            ApplyAmmoTrajectoryAssignments();
        }

        private sealed class PrecisionShotSwapState
        {
            public Ammunitions Ammo;
            public TrajectoryType OrigType;
            public bool SwappedTraj;
            public float OrigRange;
            public bool SwappedRange;
            public int AmmoId;
            public WeaponComponent Weapon;
            public int MagBefore;
            public int ShotsMadeBefore;
        }

        private static ulong EntityKey(Entity e) =>
            ((ulong)(ushort)e.WorldId << 48) | ((ulong)(ushort)e.Version << 32) | (uint)e.EntityId;

        private static bool IsGuidedMissileTrajectory(TrajectoryType tt)
        {
            int t = (int)tt;
            return t == 100 || t == 110 || t == 120;
        }

        private static void RebuildWeaponCache()
        {
            _weaponByEntity.Clear();
            GameController ctrl = GetActiveGameController();
            World world = ctrl?.GameContext;
            if (world == null)
                return;

            var arr = world.GetAll<WeaponComponent>().ToArray();
            if (arr == null)
                return;

            for (int i = 0; i < arr.Length; i++)
            {
                WeaponComponent wc = arr[i];
                if (wc == null || wc.WasCollected)
                    continue;

                Entity wEnt = wc._weaponEntity;
                if (wEnt.IsAlive)
                    _weaponByEntity[EntityKey(wEnt)] = wc;
            }
        }

        private static bool TryGetWeaponComponent(Entity weaponEntity, out WeaponComponent wc)
        {
            ulong key = EntityKey(weaponEntity);
            if (_weaponByEntity.TryGetValue(key, out wc) && wc != null && !wc.WasCollected)
                return true;

            RebuildWeaponCache();
            return _weaponByEntity.TryGetValue(key, out wc) && wc != null && !wc.WasCollected;
        }

        private static void Ammunitions_IsPrecisionAmmo_Postfix(Ammunitions __instance, ref bool __result)
        {
            if (__result || __instance == null)
                return;

            RuntimePatchState rt = _runtime;
            if (rt.Enabled && rt.PrecisionAmmoIds.Contains(__instance.Id))
                __result = true;
        }

        private static void WeaponAiming_InternalUpdate_Prefix(ref Entity weaponEntity, out PrecisionShotSwapState __state)
        {
            __state = null;
            try
            {
                RuntimePatchState rt = _runtime;
                if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0)
                    return;

                Entity w = weaponEntity;
                if (!w.IsAlive || !w.Has<GroundTargetComponent>())
                    return;

                if (!TryGetWeaponComponent(w, out WeaponComponent wc))
                {
                    LogPrecisionDiagOnce($"aim_nowc_{w.EntityId}",
                        $"WeaponAiming: не найден WeaponComponent для entity={w.EntityId} (v={w.Version}, w={w.WorldId}, cache={_weaponByEntity.Count})");
                    return;
                }

                Ammunitions ammo = wc.SelectedAmmunition;
                if (ammo != null && rt.PrecisionAmmoIds.Contains(ammo.Id))
                {
                    TrajectoryType origType = ammo.TrajectoryType;
                    __state = new PrecisionShotSwapState
                    {
                        Ammo = ammo,
                        OrigType = origType,
                        AmmoId = ammo.Id
                    };

                    if (IsGuidedMissileTrajectory(origType))
                    {
                        __state.SwappedTraj = true;
                        ammo.TrajectoryType = (TrajectoryType)200;
                    }

                    if (ammo.GroundRange > 0f)
                    {
                        __state.OrigRange = ammo.GroundRange;
                        __state.SwappedRange = true;
                        ammo.GroundRange += PrecisionRangeBuffer;
                    }

                    LogPrecisionDiagOnce($"aim_{ammo.Id}_{(int)origType}_{(int)ammo.TrajectoryType}",
                        $"WeaponAiming: БК #{ammo.Id} ({ammo.Name}), origTraj={(int)origType} -> activeTraj={(int)ammo.TrajectoryType}, hasTarget={w.Has<TargetComponent>()}");
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка WeaponAiming_InternalUpdate_Prefix: {ex.Message}");
            }
        }

        private static void WeaponAiming_InternalUpdate_Postfix(PrecisionShotSwapState __state)
        {
            if (__state?.Ammo == null)
                return;
            if (__state.SwappedTraj)
                __state.Ammo.TrajectoryType = __state.OrigType;
            if (__state.SwappedRange)
                __state.Ammo.GroundRange = __state.OrigRange;
        }

        private static void Shooting_InternalUpdate_Prefix(ref Entity weaponEntity, out PrecisionShotSwapState __state)
        {
            __state = null;
            try
            {
                RuntimePatchState rt = _runtime;
                if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0)
                    return;

                Entity w = weaponEntity;
                if (!w.IsAlive || !w.Has<GroundTargetComponent>())
                    return;

                if (!TryGetWeaponComponent(w, out WeaponComponent wc))
                {
                    LogPrecisionDiagOnce($"shoot_nowc_{w.EntityId}",
                        $"Shooting: не найден WeaponComponent для entity={w.EntityId} (v={w.Version}, w={w.WorldId}, cache={_weaponByEntity.Count})");
                    return;
                }

                Ammunitions ammo = wc.SelectedAmmunition;
                if (ammo == null || !rt.PrecisionAmmoIds.Contains(ammo.Id))
                    return;

                __state = new PrecisionShotSwapState
                {
                    Ammo = ammo,
                    OrigType = ammo.TrajectoryType,
                    AmmoId = ammo.Id,
                    Weapon = wc,
                    MagBefore = (int)wc.AmmoInMagazine,
                    ShotsMadeBefore = (int)wc.ShotsMade
                };

                if (IsGuidedMissileTrajectory(ammo.TrajectoryType))
                {
                    __state.SwappedTraj = true;
                    ammo.TrajectoryType = (TrajectoryType)200;
                }

                if (ammo.GroundRange > 0f)
                {
                    __state.OrigRange = ammo.GroundRange;
                    __state.SwappedRange = true;
                    ammo.GroundRange += PrecisionRangeBuffer;
                }

                LogPrecisionDiagOnce($"shoot_pre_{ammo.Id}",
                    $"Shooting pre: БК #{ammo.Id} ({ammo.Name}), mag={(int)wc.AmmoInMagazine}, traj={(int)ammo.TrajectoryType}, isPrecWpn={wc.IsPrecisionWeapon}, hasTarget={w.Has<TargetComponent>()}");
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка Shooting_InternalUpdate_Prefix: {ex.Message}");
            }
        }

        private static void Shooting_InternalUpdate_Postfix(ref Entity weaponEntity, PrecisionShotSwapState __state)
        {
            if (__state == null)
                return;

            try
            {
                WeaponComponent wc = __state.Weapon;
                bool fired = wc != null && !wc.WasCollected &&
                    ((int)wc.AmmoInMagazine < __state.MagBefore || (int)wc.ShotsMade != __state.ShotsMadeBefore);

                if (fired)
                {
                    Entity w = weaponEntity;
                    _tmRemoveBlockCount.Remove(EntityKey(w));
                    bool hadGt = w.IsAlive && w.Has<GroundTargetComponent>();
                    if (hadGt)
                        BattleSystemHelpers.RemoveGroundTarget(ref w);

                    LogPrecisionDiagOnce($"shoot_fired_{__state.AmmoId}",
                        $"Shooting FIRED: БК #{__state.AmmoId}, mag={__state.MagBefore}->{(int)wc.AmmoInMagazine}, shots={__state.ShotsMadeBefore}->{(int)wc.ShotsMade}, hadGroundTarget={hadGt}");

                    ClearWeaponShotCache(wc, resetShotsMade: true);
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка Shooting_InternalUpdate_Postfix: {ex.Message}");
            }
            finally
            {
                if (__state.Ammo != null)
                {
                    if (__state.SwappedTraj)
                        __state.Ammo.TrajectoryType = __state.OrigType;
                    if (__state.SwappedRange)
                        __state.Ammo.GroundRange = __state.OrigRange;
                }
            }
        }

        private const float PrecisionRangeBuffer = 60f;
        private const float PrecisionSteeringInset = 40f;

        private sealed class PrecisionAmmoRangeSwapState
        {
            public List<(Ammunitions ammo, float origRange)> Swaps;
        }

        private sealed class TargetMaintGroundSwapState
        {
            public List<(Ammunitions ammo, float origRange)> Swaps;
            public int AmmoId;
            public bool HadGroundTarget;
        }

        private sealed class HullRotTrajSwapState
        {
            public List<(Ammunitions ammo, TrajectoryType origType)> Swaps;
        }

        private static void PrecisionStrikeCommand_PreActivate_Postfix(PrecisionStrikeCommand __instance, Entity entity)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0 || __instance == null || !entity.IsAlive)
                return;

            if (!entity.Has<AircraftControlComponent>() && __instance._maxShootDistance > 100f)
                __instance._maxShootDistance = MathF.Max(60f, __instance._maxShootDistance - PrecisionSteeringInset);
        }

        private static void PrecisionStrikeCommand_IsCompleted_Postfix(PrecisionStrikeCommand __instance, Entity entity)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0 || __instance == null || !entity.IsAlive)
                return;

            if (!entity.Has<AircraftControlComponent>() && __instance._maxShootDistance > 100f)
                __instance._maxShootDistance = MathF.Max(60f, __instance._maxShootDistance - PrecisionSteeringInset);
        }

        private static void PrecisionStrikeCommand_OnActivate_Postfix(PrecisionStrikeCommand __instance, Entity entity)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0 || __instance == null || !entity.IsAlive)
                return;

            LogPrecisionDiagOnce($"ps_act_{entity.EntityId}",
                $"PrecisionStrikeCommand.OnActivate: unit={entity.EntityId}, maxDist={__instance._maxShootDistance:0.#}, aimTime={__instance._aimTime:0.##}, isPlane={entity.Has<AircraftControlComponent>()}");
        }

        private static void PrecisionStrikeSystem_InternalUpdate_Prefix(ref Entity unitEntity, out PrecisionAmmoRangeSwapState __state)
        {
            __state = null;
            try
            {
                RuntimePatchState rt = _runtime;
                if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0 || !unitEntity.IsAlive)
                    return;

                DataBaseService db = DataBaseService._instance;
                if (db == null || !db.IsLoaded)
                    return;

                var swaps = new List<(Ammunitions ammo, float origRange)>();
                foreach (int ammoId in rt.PrecisionAmmoIds)
                {
                    Ammunitions ammo = db.GetAmmunitionById(ammoId);
                    if (ammo != null && ammo.GroundRange > 0f)
                    {
                        swaps.Add((ammo, ammo.GroundRange));
                        ammo.GroundRange += PrecisionRangeBuffer;
                    }
                }

                if (swaps.Count > 0)
                    __state = new PrecisionAmmoRangeSwapState { Swaps = swaps };
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка PrecisionStrikeSystem_InternalUpdate_Prefix: {ex.Message}");
            }
        }

        private static void PrecisionStrikeSystem_InternalUpdate_Postfix(ref Entity unitEntity, PrecisionAmmoRangeSwapState __state)
        {
            try
            {
                if (unitEntity.IsAlive && _runtime.Enabled && _runtime.PrecisionAmmoIds.Count > 0)
                {
                    if (_weaponByEntity.Count == 0)
                        RebuildWeaponCache();

                    int gtCount = 0;
                    foreach (WeaponComponent wc in _weaponByEntity.Values)
                    {
                        if (wc == null || wc.WasCollected)
                            continue;
                        Entity we = wc._weaponEntity;
                        if (we.IsAlive && we.Has<GroundTargetComponent>())
                            gtCount++;
                    }

                    LogPrecisionDiagOnce($"ps_sys_{unitEntity.EntityId}_{gtCount > 0}",
                        $"PrecisionStrikeSystem: unit={unitEntity.EntityId}, hasPS={unitEntity.Has<PrecisionStrikeComponent>()}, weaponsWithGroundTarget={gtCount}");
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка PrecisionStrikeSystem_InternalUpdate_Postfix: {ex.Message}");
            }
            finally
            {
                if (__state?.Swaps != null)
                {
                    for (int i = 0; i < __state.Swaps.Count; i++)
                    {
                        var pair = __state.Swaps[i];
                        if (pair.ammo != null)
                            pair.ammo.GroundRange = pair.origRange;
                    }
                }
            }
        }

        private static void TargetMaintenance_InternalUpdate_Prefix(ref Entity weaponEntity, out TargetMaintGroundSwapState __state)
        {
            __state = null;
            try
            {
                RuntimePatchState rt = _runtime;
                if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0)
                    return;

                Entity w = weaponEntity;
                if (!w.IsAlive)
                    return;

                if (!w.Has<GroundTargetComponent>())
                {
                    _tmRemoveBlockCount.Remove(EntityKey(w));
                    return;
                }

                if (!TryGetWeaponComponent(w, out WeaponComponent wc))
                    return;

                Ammunitions ammo = wc.SelectedAmmunition;
                if (ammo != null && rt.PrecisionAmmoIds.Contains(ammo.Id))
                {
                    var swaps = new List<(Ammunitions ammo, float origRange)>(1);
                    __state = new TargetMaintGroundSwapState
                    {
                        Swaps = swaps,
                        AmmoId = ammo.Id,
                        HadGroundTarget = true
                    };

                    ammo.TargetType |= TargetType.Ground;
                    if (ammo.GroundRange > 0f)
                    {
                        swaps.Add((ammo, ammo.GroundRange));
                        ammo.GroundRange += PrecisionRangeBuffer;
                    }

                    if (wc.IsEnabled && (int)wc.AmmoInMagazine > 0)
                    {
                        _inTargetMaintenancePrecision = true;
                        _tmActiveWeaponKey = EntityKey(w);
                        _tmActiveWeapon = wc;
                    }
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка TargetMaintenance_InternalUpdate_Prefix: {ex.Message}");
            }
        }

        private static void TargetMaintenance_InternalUpdate_Postfix(ref Entity weaponEntity, TargetMaintGroundSwapState __state)
        {
            if (__state == null)
            {
                _inTargetMaintenancePrecision = false;
                _tmActiveWeaponKey = 0;
                _tmActiveWeapon = null;
                return;
            }

            try
            {
                if (__state.HadGroundTarget)
                {
                    bool stillHasGt = weaponEntity.IsAlive && weaponEntity.Has<GroundTargetComponent>();
                    if (!stillHasGt)
                    {
                        LogPrecisionDiagOnce($"tm_stripped_{__state.AmmoId}",
                            $"TargetMaintenance REMOVED GroundTarget для БК #{__state.AmmoId}!");
                    }
                    else
                    {
                        LogPrecisionDiagOnce($"tm_kept_{__state.AmmoId}",
                            $"TargetMaintenance kept GroundTarget для БК #{__state.AmmoId}.");
                    }
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка TargetMaintenance_InternalUpdate_Postfix: {ex.Message}");
            }
            finally
            {
                _inTargetMaintenancePrecision = false;
                _tmActiveWeaponKey = 0;
                _tmActiveWeapon = null;

                if (__state.Swaps != null)
                {
                    for (int i = 0; i < __state.Swaps.Count; i++)
                    {
                        var pair = __state.Swaps[i];
                        if (pair.ammo != null)
                            pair.ammo.GroundRange = pair.origRange;
                    }
                }
            }
        }

        private static bool RemoveGroundTarget_Prefix(ref Entity weaponEntity)
        {
            if (!_inTargetMaintenancePrecision)
                return true;

            ulong key = EntityKey(weaponEntity);
            if (key != _tmActiveWeaponKey)
                return true;

            WeaponComponent wc = _tmActiveWeapon;
            if (wc == null || wc.WasCollected || !wc.IsEnabled || (int)wc.AmmoInMagazine <= 0)
                return true;

            int selId = wc.SelectedAmmunitionId;
            Ammunitions ammo = wc.SelectedAmmunition;
            string ammoDiag = ammo != null
                ? $"tgt={(int)ammo.TargetType}, traj={(int)ammo.TrajectoryType}, gr={ammo.GroundRange:0.#}, min={ammo.MinimalRange:0.#}, dmg={ammo.Damage:0.#}, smoke={ammo.GenerateSmoke}, laser={ammo.LaserGuided}"
                : "ammo=null";

            LogPrecisionDiagOnce($"tm_block_{selId}",
                $"Blocked RemoveGroundTarget in TM: selId={selId}, mag={(int)wc.AmmoInMagazine}, shots={(int)wc.ShotsMade}, enabled={wc.IsEnabled}, isPrec={wc.IsPrecisionWeapon}, {ammoDiag}");

            _tmRemoveBlockCount.TryGetValue(key, out int count);
            if (count < 2)
            {
                _tmRemoveBlockCount[key] = count + 1;
                return false;
            }

            return true;
        }

        private static void WeaponHullRotation_InternalUpdate_Prefix(ref Entity unit, out HullRotTrajSwapState __state)
        {
            __state = null;
            try
            {
                RuntimePatchState rt = _runtime;
                if (!rt.Enabled || rt.PrecisionAmmoIds.Count == 0)
                    return;

                Entity u = unit;
                if (!u.IsAlive || !u.Has<PrecisionStrikeComponent>())
                    return;

                DataBaseService db = DataBaseService._instance;
                if (db == null || !db.IsLoaded)
                    return;

                var swaps = new List<(Ammunitions ammo, TrajectoryType origType)>();
                foreach (int ammoId in rt.PrecisionAmmoIds)
                {
                    Ammunitions ammo = db.GetAmmunitionById(ammoId);
                    if (ammo != null && IsGuidedMissileTrajectory(ammo.TrajectoryType))
                    {
                        swaps.Add((ammo, ammo.TrajectoryType));
                        ammo.TrajectoryType = (TrajectoryType)200;
                    }
                }

                if (swaps.Count > 0)
                {
                    __state = new HullRotTrajSwapState { Swaps = swaps };
                    LogPrecisionDiagOnce($"hullrot_{u.EntityId}",
                        $"WeaponHullRotation: swapped {swaps.Count} precision missile(s) to 200 for unit={u.EntityId}");
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка WeaponHullRotation_InternalUpdate_Prefix: {ex.Message}");
            }
        }

        private static void WeaponHullRotation_InternalUpdate_Postfix(HullRotTrajSwapState __state)
        {
            if (__state?.Swaps == null)
                return;

            for (int i = 0; i < __state.Swaps.Count; i++)
            {
                var pair = __state.Swaps[i];
                if (pair.ammo != null)
                    pair.ammo.TrajectoryType = pair.origType;
            }
        }

        private static void ClearWeaponShotCache(WeaponComponent wc, bool resetShotsMade)
        {
            if (wc == null || wc.WasCollected)
                return;

            BallisticDataStruct shotData = wc.CachedShotData;
            shotData.Clear();
            wc.CachedShotData = shotData;

            TrajectoryStruct trajData = wc.CachedTrajectoryStruct;
            if (trajData != null)
            {
                trajData.Clear();
                wc.CachedTrajectoryStruct = trajData;
            }

            if (resetShotsMade)
                wc.ShotsMade = (GInt)0;
        }

        private static int RefreshLiveWeaponsInWorld()
        {
            _weaponByEntity.Clear();
            GameController ctrl = GetActiveGameController();
            World world = ctrl?.GameContext;
            DataBaseService db = DataBaseService._instance;
            if (world == null || db == null || !db.IsLoaded)
                return 0;

            int refreshedWeapons = 0;

            try
            {
                var arr = world.GetAll<WeaponComponent>().ToArray();
                if (arr == null)
                    return 0;

                for (int i = 0; i < arr.Length; i++)
                {
                    WeaponComponent wc = arr[i];
                    if (wc == null || wc.WasCollected)
                        continue;

                    Entity wEnt = wc._weaponEntity;
                    if (wEnt.IsAlive)
                        _weaponByEntity[EntityKey(wEnt)] = wc;

                    bool isPrec = false;
                    Ammunitions selAmmo = wc.SelectedAmmunition;
                    if (selAmmo != null && selAmmo.IsPrecisionAmmo())
                        isPrec = true;

                    if (!isPrec)
                    {
                        try
                        {
                            var ammos = wc.Ammunitions;
                            if (ammos != null)
                            {
                                for (int a = 0; a < ammos.Length; a++)
                                {
                                    var entry = ammos[a];
                                    if (entry == null || entry.Item1 <= 0)
                                        continue;

                                    Ammunitions ammo = db.GetAmmunitionById(entry.Item1);
                                    if (ammo != null && ammo.IsPrecisionAmmo())
                                    {
                                        isPrec = true;
                                        break;
                                    }
                                }
                            }
                        }
                        catch { }
                    }

                    wc.IsPrecisionWeapon = isPrec;
                    ClearWeaponShotCache(wc, resetShotsMade: false);
                    refreshedWeapons++;
                }
            }
            catch (Exception ex)
            {
                _log?.Warning($"[TrajectoryEditorMod] Ошибка обновления орудий при hot-reload: {ex.Message}");
            }

            return refreshedWeapons;
        }

        private static int ApplyAmmunitionsJsonLive(DataBaseService db, string json)
        {
            JsonArray arr = JsonNode.Parse(json)?.AsArray();
            if (arr == null)
                return 0;

            int updated = 0;
            foreach (JsonNode node in arr)
            {
                if (node is not JsonObject o || !TryJsonInt(o, "Id", out int id))
                    continue;

                Ammunitions a = db.GetAmmunitionById(id);
                if (a == null)
                    continue;

                if (TryJsonInt(o, "TrajectoryType", out int tt)) a.TrajectoryType = (TrajectoryType)tt;
                if (TryJsonInt(o, "Seeker", out int seeker)) a.Seeker = (SeekerType)seeker;
                if (TryJsonBool(o, "Airburst", out bool ab)) a.Airburst = ab;
                if (TryJsonInt(o, "TargetType", out int tgt)) a.TargetType = (TargetType)tgt;
                if (TryJsonInt(o, "ArmorTargeted", out int arm)) a.ArmorTargeted = (ArmorType)arm;
                if (TryJsonFloat(o, "IgnoreCover", out float ic)) a.IgnoreCover = ic;
                if (TryJsonFloat(o, "DamageOverTimeDuration", out float dot)) a.DamageOverTimeDuration = dot;
                if (TryJsonFloat(o, "CriticMultiplier", out float cm)) a.CriticMultiplier = cm;
                if (TryJsonBool(o, "LaserGuided", out bool lg)) a.LaserGuided = lg;
                if (TryJsonBool(o, "TopArmorAttack", out bool taa)) a.TopArmorAttack = taa;
                if (TryJsonBool(o, "CanBeIntercepted", out bool cbi)) a.CanBeIntercepted = cbi;
                if (TryJsonBool(o, "CanBeTargeted", out bool cbt)) a.CanBeTargeted = cbt;
                if (TryJsonBool(o, "NoDamageFalloff", out bool ndf)) a.NoDamageFalloff = ndf;
                if (TryJsonBool(o, "GenerateSmoke", out bool gs)) a.GenerateSmoke = gs;
                if (TryJsonFloat(o, "SmokeRadius", out float sr)) a.SmokeRadius = sr;
                if (TryJsonFloat(o, "SmokeDuration", out float sd)) a.SmokeDuration = sd;
                if (TryJsonFloat(o, "SmokeFadeDuration", out float sfd)) a.SmokeFadeDuration = sfd;
                if (TryJsonFloat(o, "AimTimeMinOverride", out float atMin)) a.AimTimeMinOverride = atMin;
                if (TryJsonFloat(o, "AimTimeMaxOverride", out float atMax)) a.AimTimeMaxOverride = atMax;
                if (TryJsonBool(o, "PreventReloadWhileTracked", out bool prwt)) a.PreventReloadWhileTracked = prwt;
                if (TryJsonBool(o, "StripingIgnore", out bool si)) a.StripingIgnore = si;

                bool rangeChanged = false;
                if (TryJsonFloat(o, "MinimalRange", out float minR)) { a.MinimalRange = minR; rangeChanged = true; }
                if (TryJsonFloat(o, "GroundRange", out float gR)) { a.GroundRange = gR; rangeChanged = true; }
                if (TryJsonFloat(o, "LowAltRange", out float lR)) { a.LowAltRange = lR; rangeChanged = true; }
                if (TryJsonFloat(o, "HighAltRange", out float hR)) { a.HighAltRange = hR; rangeChanged = true; }
                if (TryJsonFloat(o, "NonSeadProjectileRangeOverride", out float nsR)) { a.NonSeadProjectileRangeOverride = nsR; rangeChanged = true; }
                if (TryJsonFloat(o, "SeadProjectileRangeOverride", out float sR)) { a.SeadProjectileRangeOverride = sR; rangeChanged = true; }
                if (rangeChanged) a._dispersionReferenceRange = 0f;

                if (TryJsonFloat(o, "MuzzleVelocity", out float mv)) a.MuzzleVelocity = mv;
                if (TryJsonFloat(o, "MaxSpeed", out float ms)) a.MaxSpeed = ms;
                if (TryJsonFloat(o, "Acceleration", out float acc)) a.Acceleration = acc;
                if (TryJsonFloat(o, "BurnTime", out float bt)) a.BurnTime = bt;
                if (TryJsonFloat(o, "RotationSpeed", out float rs)) a.RotationSpeed = rs;
                if (TryJsonFloat(o, "PreEgnitionRotationSpeed", out float prs)) a.PreEgnitionRotationSpeed = prs;
                if (TryJsonFloat(o, "LaunchMarginAngle", out float lma)) a.LaunchMarginAngle = lma;
                if (TryJsonFloat(o, "AimStartDelay", out float asd)) a.AimStartDelay = asd;
                if (TryJsonFloat(o, "MainEngineIgnitionDelay", out float meid)) a.MainEngineIgnitionDelay = meid;
                if (TryJsonFloat(o, "SeekerAngle", out float sa)) a.SeekerAngle = sa;
                if (TryJsonFloat(o, "MaxSeekerDistance", out float msd)) a.MaxSeekerDistance = msd;
                if (TryJsonBool(o, "CanReaquire", out bool cr)) a.CanReaquire = cr;
                if (TryJsonFloat(o, "RadioFuseDistance", out float rfd)) a.RadioFuseDistance = rfd;
                if (TryJsonInt(o, "OverflyHeight", out int ofh)) a.OverflyHeight = ofh;
                if (TryJsonInt(o, "LoftAngle", out int la)) a.LoftAngle = la;
                if (TryJsonInt(o, "LoftHeight", out int lh)) a.LoftHeight = lh;

                if (TryJsonFloat(o, "DispersionHorizontalRadius", out float dhr)) a.DispersionHorizontalRadius = dhr;
                if (TryJsonFloat(o, "DispersionVerticalRadius", out float dvr)) a.DispersionVerticalRadius = dvr;
                if (TryJsonFloat(o, "DispersionMinimal", out float dm)) a.DispersionMinimal = dm;

                if (TryJsonFloat(o, "SupplyCost", out float sc)) a.SupplyCost = sc;
                if (TryJsonFloat(o, "ResupplyTime", out float rt)) a.ResupplyTime = rt;
                if (TryJsonFloat(o, "Damage", out float dmg)) a.Damage = dmg;
                if (TryJsonFloat(o, "StressDamage", out float sdmg)) a.StressDamage = sdmg;
                if (TryJsonFloat(o, "PenetrationAtMinRange", out float pmr)) a.PenetrationAtMinRange = pmr;
                if (TryJsonFloat(o, "PenetrationAtGroundRange", out float pgr)) a.PenetrationAtGroundRange = pgr;
                if (TryJsonFloat(o, "HealthAOERadius", out float haoe)) a.HealthAOERadius = haoe;
                if (TryJsonFloat(o, "StressAOERadius", out float saoe)) a.StressAOERadius = saoe;
                if (TryJsonFloat(o, "OverpressureRadius", out float opr)) a.OverpressureRadius = opr;

                updated++;
            }

            return updated;
        }

        private static bool TryJsonInt(JsonObject o, string key, out int value)
        {
            value = 0;
            JsonNode n = o[key];
            if (n == null) return false;
            if (n is JsonValue v && v.TryGetValue<double>(out double d))
            {
                value = (int)Math.Round(d);
                return true;
            }
            return int.TryParse(n.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
        }

        private static bool TryJsonFloat(JsonObject o, string key, out float value)
        {
            value = 0f;
            JsonNode n = o[key];
            if (n == null) return false;
            if (n is JsonValue v && v.TryGetValue<double>(out double d))
            {
                value = (float)d;
                return true;
            }
            return float.TryParse(n.ToString().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }

        private static bool TryJsonBool(JsonObject o, string key, out bool value)
        {
            value = false;
            JsonNode n = o[key];
            if (n == null) return false;
            if (n is JsonValue v && v.TryGetValue<bool>(out bool b))
            {
                value = b;
                return true;
            }
            return bool.TryParse(n.ToString(), out value);
        }

        private static void SpawnTrajectoryShell_Prefix(ProjectileSpawnerHelper.ShellSpawnData data, TrajectoryStruct trajectory)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || data?.AmmoData == null)
                return;

            if (!rt.AmmoOverrides.TryGetValue(data.AmmoData.Id, out ResolvedTrajectoryOverride ov))
                return;

            CustomTrajectoryDto ct = ov.Trajectory;
            if (Math.Abs(ct.SpeedMultiplier - 1f) > 1e-4f)
                data.InitialSpeed *= Math.Max(0.05f, ct.SpeedMultiplier);
            if (ct.ForceTopAttack)
                data.SavedForceTop = true;

            if (ct.UseCustomHeightFormula && ov.HeightExpr != null && trajectory != null)
            {
                Il2CppStructArray<float> heights = trajectory.PointHeights;
                if (heights != null && heights.Length >= 3)
                {
                    int n = heights.Length;
                    float delta = Math.Max(0.01f, trajectory.DistanceDelta);
                    double totalDist = (n - 1) * delta;

                    double denom = ct.MaxRefDistance - ct.MinRefDistance;
                    double k = Math.Abs(denom) < 1e-3 ? 1.0 : Math.Clamp((totalDist - ct.MinRefDistance) / denom, 0.0, 1.0);
                    double apogee = ct.MinApogee + (ct.MaxApogee - ct.MinApogee) * k;

                    float h0 = heights[0];
                    float h1 = heights[n - 1];
                    CompiledExpression expr = ov.HeightExpr;

                    for (int i = 1; i < n - 1; i++)
                    {
                        double t = i / (double)(n - 1);
                        double baseline = h0 + (h1 - h0) * t;
                        double customH = expr.Evaluate(name =>
                        {
                            if (string.Equals(name, "t", StringComparison.OrdinalIgnoreCase)) return t;
                            if (string.Equals(name, "d", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "dist", StringComparison.OrdinalIgnoreCase)) return totalDist;
                            if (string.Equals(name, "apogee", StringComparison.OrdinalIgnoreCase)) return apogee;
                            return 0.0;
                        });
                        heights[i] = (float)(baseline + customH);
                    }

                    trajectory._lastAngleTan = (heights[n - 1] - heights[n - 2]) / delta;
                }
            }
        }

        private static void SpawnMissile_Prefix(ProjectileSpawnerHelper.ShellSpawnData data)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || data?.AmmoData == null)
                return;

            if (!rt.AmmoOverrides.TryGetValue(data.AmmoData.Id, out ResolvedTrajectoryOverride ov))
                return;

            if (Math.Abs(ov.Trajectory.SpeedMultiplier - 1f) > 1e-4f)
                data.InitialSpeed *= Math.Max(0.05f, ov.Trajectory.SpeedMultiplier);
            if (ov.Trajectory.ForceTopAttack)
                data.SavedForceTop = true;
        }

        // =====================================================================
        // HARMONY ХУКИ: ПОЛЬЗОВАТЕЛЬСКИЕ МАТЕМАТИЧЕСКИЕ ФОРМУЛЫ ИГРЫ
        // =====================================================================

        private static bool DamageFormulaKinetic_Prefix(float baseDamage, float penetration, float armor, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("DamageFormulaKinetic", out CompiledExpression expr))
                return true;

            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "baseDamage", StringComparison.OrdinalIgnoreCase)) return baseDamage;
                if (string.Equals(v, "pen", StringComparison.OrdinalIgnoreCase)) return penetration;
                if (string.Equals(v, "armor", StringComparison.OrdinalIgnoreCase)) return armor;
                if (string.Equals(v, "effectiveness", StringComparison.OrdinalIgnoreCase)) return rt.Effectiveness;
                if (string.Equals(v, "minCoeff", StringComparison.OrdinalIgnoreCase)) return rt.MinCoeff;
                return 0.0;
            }));
            return false;
        }

        private static bool DamageFormulaHEAT_Prefix(float baseDamage, float penetration, float armor, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("DamageFormulaHEAT", out CompiledExpression expr))
                return true;

            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "baseDamage", StringComparison.OrdinalIgnoreCase)) return baseDamage;
                if (string.Equals(v, "pen", StringComparison.OrdinalIgnoreCase)) return penetration;
                if (string.Equals(v, "armor", StringComparison.OrdinalIgnoreCase)) return armor;
                if (string.Equals(v, "p", StringComparison.OrdinalIgnoreCase)) return rt.HeatP;
                if (string.Equals(v, "k", StringComparison.OrdinalIgnoreCase)) return rt.HeatK;
                return 0.0;
            }));
            return false;
        }

        private static bool CalculateHitDamageWithThreshold_Prefix(float baseDamage, float damageThreshold, bool HEAT, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("CalculateHitDamageWithThreshold", out CompiledExpression expr))
                return true;

            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "damage", StringComparison.OrdinalIgnoreCase) || string.Equals(v, "baseDamage", StringComparison.OrdinalIgnoreCase)) return baseDamage;
                if (string.Equals(v, "threshold", StringComparison.OrdinalIgnoreCase)) return damageThreshold;
                if (string.Equals(v, "isHeat", StringComparison.OrdinalIgnoreCase)) return HEAT ? 1.0 : 0.0;
                return 0.0;
            }));
            return false;
        }

        private static bool GetPenetration_Prefix(
            ArmorType armorType,
            float PenetrationAtEffectiveRange,
            float PenetrationAtMinimalRange,
            float EffectiveRange,
            float MinimalRange,
            float ActualRange,
            ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("GetPenetration", out CompiledExpression expr))
                return true;

            double isKin = armorType == ArmorType.Kinetic ? 1.0 : 0.0;
            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "isKinetic", StringComparison.OrdinalIgnoreCase)) return isKin;
                if (string.Equals(v, "penMin", StringComparison.OrdinalIgnoreCase)) return PenetrationAtMinimalRange;
                if (string.Equals(v, "penMax", StringComparison.OrdinalIgnoreCase)) return PenetrationAtEffectiveRange;
                if (string.Equals(v, "minRange", StringComparison.OrdinalIgnoreCase)) return MinimalRange;
                if (string.Equals(v, "maxRange", StringComparison.OrdinalIgnoreCase)) return EffectiveRange;
                if (string.Equals(v, "distance", StringComparison.OrdinalIgnoreCase)) return ActualRange;
                return 0.0;
            }));
            return false;
        }

        private static bool CalculateStressDamage_Prefix(float maxStress, float healthDamage, float stressDamage, float targetMaxHeal, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("CalculateStressDamage", out CompiledExpression expr))
                return true;

            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "maxStress", StringComparison.OrdinalIgnoreCase)) return maxStress;
                if (string.Equals(v, "healthDamage", StringComparison.OrdinalIgnoreCase)) return healthDamage;
                if (string.Equals(v, "stressDamage", StringComparison.OrdinalIgnoreCase)) return stressDamage;
                if (string.Equals(v, "targetMaxHp", StringComparison.OrdinalIgnoreCase)) return targetMaxHeal;
                return 0.0;
            }));
            return false;
        }

        private static bool CalculateCountermeasuresEffect_Prefix(float countermeasuresAccuracyMultiplier, float missileFlareResistivity, int countermeasuresCount, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("CalculateCountermeasuresEffect", out CompiledExpression expr))
                return true;

            __result = Math.Clamp((float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "decoyEffect", StringComparison.OrdinalIgnoreCase)) return countermeasuresAccuracyMultiplier;
                if (string.Equals(v, "flareResist", StringComparison.OrdinalIgnoreCase)) return missileFlareResistivity;
                if (string.Equals(v, "count", StringComparison.OrdinalIgnoreCase)) return countermeasuresCount;
                return 0.0;
            }), 0f, 10f);
            return false;
        }

        private static bool CalculateMissileHitChance8_Prefix(
            float missileAccuracy,
            float missileFlareResistivity,
            float targetECM,
            float targetDecoyEffect,
            int targetActiveDecoys,
            float stressMultiplier,
            float VeterancyMultiplier,
            float CritMultiplier,
            ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("CalculateMissileHitChance", out CompiledExpression expr))
                return true;

            __result = Math.Clamp((float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "accuracy", StringComparison.OrdinalIgnoreCase)) return missileAccuracy;
                if (string.Equals(v, "flareResist", StringComparison.OrdinalIgnoreCase)) return missileFlareResistivity;
                if (string.Equals(v, "ecm", StringComparison.OrdinalIgnoreCase)) return targetECM;
                if (string.Equals(v, "decoyEffect", StringComparison.OrdinalIgnoreCase)) return targetDecoyEffect;
                if (string.Equals(v, "decoys", StringComparison.OrdinalIgnoreCase)) return targetActiveDecoys;
                if (string.Equals(v, "stress", StringComparison.OrdinalIgnoreCase)) return stressMultiplier;
                if (string.Equals(v, "veterancy", StringComparison.OrdinalIgnoreCase)) return VeterancyMultiplier;
                if (string.Equals(v, "crit", StringComparison.OrdinalIgnoreCase)) return CritMultiplier;
                return 0.0;
            }), 0f, 1f);
            return false;
        }

        private static bool CalculateMissileHitChance5_Prefix(
            Ammunitions ammoInfo,
            float targetECM,
            float targetDecoyEffect,
            int targetActiveDecoys,
            float stressMultiplier,
            ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (ammoInfo == null || !rt.Enabled || !rt.Formulas.TryGetValue("CalculateMissileHitChance", out CompiledExpression expr))
                return true;

            float acc = ammoInfo.DispersionHorizontalRadius;
            float flareResist = ammoInfo.DispersionVerticalRadius;
            __result = Math.Clamp((float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "accuracy", StringComparison.OrdinalIgnoreCase)) return acc;
                if (string.Equals(v, "flareResist", StringComparison.OrdinalIgnoreCase)) return flareResist;
                if (string.Equals(v, "ecm", StringComparison.OrdinalIgnoreCase)) return targetECM;
                if (string.Equals(v, "decoyEffect", StringComparison.OrdinalIgnoreCase)) return targetDecoyEffect;
                if (string.Equals(v, "decoys", StringComparison.OrdinalIgnoreCase)) return targetActiveDecoys;
                if (string.Equals(v, "stress", StringComparison.OrdinalIgnoreCase)) return stressMultiplier;
                if (string.Equals(v, "veterancy", StringComparison.OrdinalIgnoreCase)) return 1.0;
                if (string.Equals(v, "crit", StringComparison.OrdinalIgnoreCase)) return 1.0;
                return 0.0;
            }), 0f, 1f);
            return false;
        }

        private static void GetTargetAccuracy_Postfix(Ammunitions ammo, float distance, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("GetTargetAccuracy", out CompiledExpression expr))
                return;

            float vanilla = __result;
            float dispH = ammo != null ? ammo.DispersionHorizontalRadius : 0f;
            float dispV = ammo != null ? ammo.DispersionVerticalRadius : 0f;
            float dispMin = ammo != null ? ammo.DispersionMinimal : 0f;
            float refRange = ammo != null ? ammo.GetDispersionReferenceRange() : 1000f;

            __result = Math.Clamp((float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "vanilla", StringComparison.OrdinalIgnoreCase)) return vanilla;
                if (string.Equals(v, "distance", StringComparison.OrdinalIgnoreCase)) return distance;
                if (string.Equals(v, "dispH", StringComparison.OrdinalIgnoreCase)) return dispH;
                if (string.Equals(v, "dispV", StringComparison.OrdinalIgnoreCase)) return dispV;
                if (string.Equals(v, "dispMin", StringComparison.OrdinalIgnoreCase)) return dispMin;
                if (string.Equals(v, "refRange", StringComparison.OrdinalIgnoreCase)) return refRange;
                return 0.0;
            }), 0f, 1f);
        }

        private static void CalculateVisionRangeForTarget_Postfix(ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("CalculateVisionRangeForTarget", out CompiledExpression expr))
                return;

            float vanilla = __result;
            __result = MathF.Max(0f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "vanilla", StringComparison.OrdinalIgnoreCase)) return vanilla;
                if (string.Equals(v, "minDist", StringComparison.OrdinalIgnoreCase)) return rt.FowMinDist;
                return 0.0;
            }));
        }

        private static bool GetRotationRadius_Prefix(float turnRate, float forwardSpeed, ref float __result)
        {
            RuntimePatchState rt = _runtime;
            if (!rt.Enabled || !rt.Formulas.TryGetValue("GetRotationRadius", out CompiledExpression expr))
                return true;

            __result = MathF.Max(1f, (float)expr.Evaluate(v =>
            {
                if (string.Equals(v, "turnRate", StringComparison.OrdinalIgnoreCase)) return turnRate;
                if (string.Equals(v, "speed", StringComparison.OrdinalIgnoreCase)) return forwardSpeed;
                return 0.0;
            }));
            return false;
        }

        // =====================================================================
        // ПРИМЕНЕНИЕ СТАНДАРТНЫХ КОНФИГОВ
        // =====================================================================

        private static void GameConfig_InitConfigs_Postfix(GameConfig __instance)
        {
            try
            {
                TrajectoryConfigDto cfg = LoadConfigAndSnapshot();
                if (cfg == null)
                    return;

                RebuildRuntimeState(cfg);
                if (!cfg.Enabled || __instance == null)
                    return;

                ApplyAllConfigs(cfg, __instance);
                _log.Msg("[TrajectoryEditorMod] Все конфиги (саплай, авиация, формулы) применены при InitConfigs.");
            }
            catch (Exception ex)
            {
                _log.Error($"[TrajectoryEditorMod] Ошибка применения в InitConfigs: {ex}");
            }
        }

        private static void BattleSystemConstantsLoad_Prefix(GameController __instance)
        {
            _lastController = __instance;
            _weaponByEntity.Clear();
            _diagLogged.Clear();
            _tmRemoveBlockCount.Clear();
            if (_reloading)
                return;

            try
            {
                TrajectoryConfigDto cfg = LoadConfigAndSnapshot();
                if (cfg == null)
                    return;

                _diagLogged.Clear();
                RebuildRuntimeState(cfg);
                ApplyAmmoTrajectoryAssignments();
                if (!cfg.Enabled)
                    return;

                GameConfig gameConfig = GameConfig.Instance;
                if (gameConfig == null)
                    return;

                ApplyAllConfigs(cfg, gameConfig);
                _log.Msg("[TrajectoryEditorMod] Параметры BattleSystemSettings и формулы применены перед загрузкой боя.");
            }
            catch (Exception ex)
            {
                _log.Error($"[TrajectoryEditorMod] Ошибка применения конфига: {ex}");
            }
        }

        private static void EnsureConfigFile()
        {
            try
            {
                string dir = Path.GetDirectoryName(_configPath);
                if (!string.IsNullOrEmpty(dir))
                    Directory.CreateDirectory(dir);

                if (!File.Exists(_configPath))
                {
                    var defaults = new TrajectoryConfigDto();
                    File.WriteAllText(_configPath, JsonSerializer.Serialize(defaults, JsonOpts));
                }
            }
            catch (Exception ex)
            {
                _log.Error($"[TrajectoryEditorMod] Не удалось инициализировать конфиг: {ex}");
            }
        }

        private static TrajectoryConfigDto LoadConfigAndSnapshot()
        {
            if (!File.Exists(_configPath))
                return null;

            var fi = new FileInfo(_configPath);
            string text = File.ReadAllText(_configPath);
            TrajectoryConfigDto cfg = DeserializeConfig(text);
            if (cfg != null)
            {
                _lastWriteUtc = fi.LastWriteTimeUtc;
                _lastConfigLength = fi.Length;
                _lastConfigText = text;
            }
            return cfg;
        }

        private static TrajectoryConfigDto DeserializeConfig(string json)
        {
            TrajectoryConfigDto cfg = JsonSerializer.Deserialize<TrajectoryConfigDto>(json, JsonOpts);
            if (cfg != null)
            {
                cfg.Planes ??= new PlanesDto();
                cfg.Supply ??= new SupplyDto();
                cfg.CombatFormulas ??= new CombatFormulasDto();
                cfg.GameConfig ??= new GameConfigDto();
                cfg.FogOfWar ??= new FogOfWarDto();
                cfg.Buffs ??= new BuffsDto();
                cfg.Buildings ??= new BuildingsDto();
                cfg.Infantry ??= new InfantryDto();
                cfg.FormulaOverrides ??= new Dictionary<string, CustomFormulaDto>(StringComparer.Ordinal);
                cfg.CustomTrajectories ??= new List<CustomTrajectoryDto>();
                cfg.WeaponTrajectoryAssignments ??= new List<WeaponTrajectoryAssignmentDto>();
                cfg.PrecisionStrikeAmmoIds ??= new List<int>();
            }
            return cfg;
        }

        private static void ApplyAllConfigs(TrajectoryConfigDto cfg, GameConfig gc)
        {
            if (gc == null)
                return;

            BattleSystemSettings bss = gc.BattleSystemSettings;
            if (bss != null)
            {
                ApplyBattleSettingsTrajectories(cfg, bss);
                ApplyCombatFormulas(cfg.CombatFormulas, bss);
            }

            if (gc.PlanesConfig != null)
                ApplyPlanes(cfg.Planes, gc.PlanesConfig);

            if (gc.SupplyConfig != null)
                ApplySupply(cfg.Supply, gc.SupplyConfig);

            ApplyGameConfigScalars(cfg.GameConfig, gc);

            if (gc.FogOfWarConfig != null)
                ApplyFogOfWar(cfg.FogOfWar, gc.FogOfWarConfig);

            if (gc.BuffConfig != null)
                ApplyBuffs(cfg.Buffs, gc.BuffConfig);

            if (gc.BuildingsConfig != null)
                ApplyBuildings(cfg.Buildings, gc.BuildingsConfig);

            if (gc.InfantryConfig != null)
                ApplyInfantry(cfg.Infantry, gc.InfantryConfig);
        }

        private static void ApplyBattleSettingsTrajectories(TrajectoryConfigDto cfg, BattleSystemSettings bss)
        {
            bss.G = cfg.G;
            bss.MIN_POINT_DISPERSION = cfg.MIN_POINT_DISPERSION;
            bss.MAX_POINT_DISPERSION_MULTIPLIER = cfg.MAX_POINT_DISPERSION_MULTIPLIER;
            bss.ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS = cfg.ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS;
            bss.BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE = cfg.BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE;
            bss.MAX_WEAPON_AIMING_IMPRECISION = cfg.MAX_WEAPON_AIMING_IMPRECISION;
            bss.MAX_WEAPON_AIMING_CHECK_TRESHOLD = cfg.MAX_WEAPON_AIMING_CHECK_TRESHOLD;

            bss.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE = cfg.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE;
            bss.MAX_ARTILLERY_SHOT_APOGEE_DISTANCE = cfg.MAX_ARTILLERY_SHOT_APOGEE_DISTANCE;
            bss.MAX_ARTILLERY_SHOT_APOGEE = cfg.MAX_ARTILLERY_SHOT_APOGEE;
            bss.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE = cfg.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE;
            bss.MIN_ARTILLERY_SHOT_APOGEE = cfg.MIN_ARTILLERY_SHOT_APOGEE;
            bss.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE = cfg.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE;
            bss.MAX_MORTAR_SHOT_APOGEE = cfg.MAX_MORTAR_SHOT_APOGEE;
            bss.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE = cfg.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE;
            bss.MIN_MORTAR_SHOT_APOGEE = cfg.MIN_MORTAR_SHOT_APOGEE;

            AnimationCurve dispCurve = BuildCurve(cfg.ARTILLERY_DISPERSION_CDF);
            if (dispCurve != null)
                bss.ARTILLERY_DISPERSION_CDF = dispCurve;

            bss.START_LEAD_MISSILE_SPEED_PROPORTION = cfg.START_LEAD_MISSILE_SPEED_PROPORTION;
            bss.FULL_LEAD_MISSILE_SPEED_PROPORTION = cfg.FULL_LEAD_MISSILE_SPEED_PROPORTION;
            bss.MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION = cfg.MISSILE_GRAVITY_ACCELERATION_BEFORE_MOTOR_ACTIVATION;
            bss.MISSILE_DECELERATION_PROPORTION = cfg.MISSILE_DECELERATION_PROPORTION;
            bss.MISSILE_DEATH_SPEED_PROPORTION = cfg.MISSILE_DEATH_SPEED_PROPORTION;
            bss.LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION = cfg.LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION;
            bss.MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION = cfg.MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION;
            bss.MISSILE_NO_TARGET_SUPPORT_TIME = cfg.MISSILE_NO_TARGET_SUPPORT_TIME;
            bss.MISSILE_NO_TARGET_SUPPORT_TIME_TG = cfg.MISSILE_NO_TARGET_SUPPORT_TIME_TG;
            bss.SEAD_MISSILES_GO_TO_LAST_POSITION = cfg.SEAD_MISSILES_GO_TO_LAST_POSITION;
            bss.MINIMAL_MISSILE_MISS_DISTANCE = cfg.MINIMAL_MISSILE_MISS_DISTANCE;
            bss.MAX_MISSILE_MISS_DISTANCE_PROPORTION = cfg.MAX_MISSILE_MISS_DISTANCE_PROPORTION;
            bss.MAX_MISSILE_MISS_DISTANCE_CAP = cfg.MAX_MISSILE_MISS_DISTANCE_CAP;
            bss.MISSILE_MISS_ADDITIONAL_CLEARENCE = cfg.MISSILE_MISS_ADDITIONAL_CLEARENCE;
            bss.RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN = cfg.RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN;
            bss.RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX = cfg.RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX;
            bss.RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER = cfg.RADIOFUSE_RADNOM_TARGET_DISTANCE_TRESHOLD_MULTIPLIER;
            bss.MISSILE_MERGE_POWER = cfg.MISSILE_MERGE_POWER;
            bss.MISSILE_SWITCH_RULE = (TargetPrioritisation)cfg.MISSILE_SWITCH_RULE;

            bss.CRUISE_MISSILE_TARGET_HEIGHT = cfg.CRUISE_MISSILE_TARGET_HEIGHT;
            bss.CRUISE_MISSILE_DIVE_ANGLE = cfg.CRUISE_MISSILE_DIVE_ANGLE;
            bss.PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE = cfg.PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE;
            bss.CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT = cfg.CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT;
            bss.CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION = cfg.CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION;

            if (cfg.CRUISE_MISSILE_PID != null && cfg.CRUISE_MISSILE_PID.Length >= 3)
            {
                var pidArr = new Il2CppStructArray<float>(3);
                pidArr[0] = cfg.CRUISE_MISSILE_PID[0];
                pidArr[1] = cfg.CRUISE_MISSILE_PID[1];
                pidArr[2] = cfg.CRUISE_MISSILE_PID[2];
                bss.CRUISE_MISSILE_PID = pidArr;
            }

            AnimationCurve cruiseCurve = BuildCurve(cfg.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS);
            if (cruiseCurve != null)
                bss.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS = cruiseCurve;

            bss.BALLISTIC_MISSILES_APOAPSIS = cfg.BALLISTIC_MISSILES_APOAPSIS;
            bss.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION = cfg.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION;
            bss.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION = cfg.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION;

            bss.BOMBS_GRAVITY_MULTIPLYER = cfg.BOMBS_GRAVITY_MULTIPLYER;
            bss.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER = cfg.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER;
            bss.HIGH_DRAG_BOMBS_DECELERATION_PROPORTION = cfg.HIGH_DRAG_BOMBS_DECELERATION_PROPORTION;
            bss.BOMB_HORIZONTAL_MARGIN = cfg.BOMB_HORIZONTAL_MARGIN;
            bss.BOMB_UPPER_MARGIN = cfg.BOMB_UPPER_MARGIN;
            bss.DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN = cfg.DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN;

            bss.LASER_MAX_GLIDING_ANGLE = cfg.LASER_MAX_GLIDING_ANGLE;
            bss.LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE = cfg.LASER_UPWARD_SPEED_DEGRADATION_REFERENCE_ANGLE;
            bss.MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME = cfg.MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME;
            bss.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN = cfg.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MIN;
            bss.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX = cfg.MISSILE_DEAD_TRAJECTORY_REROLL_TIME_MAX;
            bss.SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS = cfg.SAM_MISSILE_EXPLOSION_CHANGE_ON_TARGET_LOSS;
        }

        private static void ApplyCombatFormulas(CombatFormulasDto f, BattleSystemSettings bss)
        {
            bss.ARMOR_PENETRATION_EFFECTIVENESS = f.ARMOR_PENETRATION_EFFECTIVENESS;
            bss.MINIMAL_DAMAGE_COEFFICIENT = f.MINIMAL_DAMAGE_COEFFICIENT;
            bss.HE_ARMOR_EFFECTIVENESS = f.HE_ARMOR_EFFECTIVENESS;
            bss.HEAT_CURVE_COEFFICIENT = f.HEAT_CURVE_COEFFICIENT;
            bss.CQCTick = f.CQCTick;
            bss.CQCChance = f.CQCChance;
            bss.PLANES_DAMAGE_SCORE_MULTIPLIER = f.PLANES_DAMAGE_SCORE_MULTIPLIER;
            bss.RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES = f.RANGE_MULTIPLIER_AGAINST_SEAD_PROJECTILES;
            bss.RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES = f.RANGE_MULTIPLIER_AGAINST_NON_SEAD_PROJECTILES;

            bss.SEAD_SCORE_MULTIPLIER = f.SEAD_SCORE_MULTIPLIER;
            bss.MINIMAL_CHANCE_TO_KILL = f.MINIMAL_CHANCE_TO_KILL;
            bss.GUIDED_SELECTION_DAMAGE_TRESHHOLD = f.GUIDED_SELECTION_DAMAGE_TRESHHOLD;
            bss.APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD = f.APS_GUIDED_SELECTION_DAMAGE_TRESHHOLD;
            bss.GUIDED_IGNORE_UNGUIDED_ON_PLANES = f.GUIDED_IGNORE_UNGUIDED_ON_PLANES;
            bss.GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES = f.GUIDED_IGNORE_UNGUIDED_ON_PROJECTILES;
            bss.ACTIVE_APS_IGNORES_ONE_MISSILE = f.ACTIVE_APS_IGNORES_ONE_MISSILE;
            bss.HP_LIMIT_WEAPON_SCORE = f.HP_LIMIT_WEAPON_SCORE;
            bss.PRIORITIZE_ONE_SHOT_TARGETS = f.PRIORITIZE_ONE_SHOT_TARGETS;
            bss.PREVENT_GUIDED_OVERKILL = f.PREVENT_GUIDED_OVERKILL;
            bss.MISSILE_OVERKILL_CLEAR_DELAY = f.MISSILE_OVERKILL_CLEAR_DELAY;
            bss.FORCE_MISSILE_MISS_DAMAGE = f.FORCE_MISSILE_MISS_DAMAGE;
            bss.MISSILE_MISS_OVERKILL_CLEAR_DELAY = f.MISSILE_MISS_OVERKILL_CLEAR_DELAY;
            bss.MAX_FLARES_COUNT_MISSILE_INITIAL = f.MAX_FLARES_COUNT_MISSILE_INITIAL;
            bss.MAX_FLARES_COUNT_MISSILE_REROLL = f.MAX_FLARES_COUNT_MISSILE_REROLL;
            bss.AUTOFLARES_PLANES_DELAY = f.AUTOFLARES_PLANES_DELAY;
            bss.AUTOFLARES_HELICOPTERS_DELAY = f.AUTOFLARES_HELICOPTERS_DELAY;
            bss.AUTOSMOKE_TRIGGER_BY_GUNS = f.AUTOSMOKE_TRIGGER_BY_GUNS;
            bss.AUTOSMOKE_TRIGGER_BY_MISSILES = f.AUTOSMOKE_TRIGGER_BY_MISSILES;
            bss.AUTOSMOKE_DELAY_MIN = f.AUTOSMOKE_DELAY_MIN;
            bss.AUTOSMOKE_DELAY_MAX = f.AUTOSMOKE_DELAY_MAX;
            bss.AUTOSMOKE_AI_TRIGGER_BY_GUNS = f.AUTOSMOKE_AI_TRIGGER_BY_GUNS;
            bss.AUTOSMOKE_AI_TRIGGER_BY_MISSILES = f.AUTOSMOKE_AI_TRIGGER_BY_MISSILES;
            bss.AUTOSMOKE_AI_DELAY_MIN = f.AUTOSMOKE_AI_DELAY_MIN;
            bss.AUTOSMOKE_AI_DELAY_MAX = f.AUTOSMOKE_AI_DELAY_MAX;
            bss.AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY = f.AUTOSMOKE_AI_DIFFICULTY_CHANCE_EASY;
            bss.AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM = f.AUTOSMOKE_AI_DIFFICULTY_CHANCE_MEDIUM;
            bss.AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD = f.AUTOSMOKE_AI_DIFFICULTY_CHANCE_HARD;
            bss.MAX_TIME_WITHOUT_TARGET = f.MAX_TIME_WITHOUT_TARGET;
        }

        private static void ApplyPlanes(PlanesDto p, PlanesConfig pc)
        {
            pc.BombingStartTimeOffset = p.BombingStartTimeOffset;
            pc.BombingStartTimeOffsetHighDrag = p.BombingStartTimeOffsetHighDrag;
            pc.BombDropOffset = p.BombDropOffset;
            pc.BombDropOffsetHighDrag = p.BombDropOffsetHighDrag;
            pc.BombDropOffsetAmmoAoeMult = p.BombDropOffsetAmmoAoeMult;
            pc.EnableStratBomberCircling = p.EnableStratBomberCircling;

            pc.StrafeMinLength = p.StrafeMinLength;
            pc.StrafeMaxLength = p.StrafeMaxLength;
            pc.StrafeSearchRadius = p.StrafeSearchRadius;
            pc.StrafeStartTimeOffset = p.StrafeStartTimeOffset;
            pc.StrafeWeaponPointOffset = p.StrafeWeaponPointOffset;

            pc.PrecisionMinAllowedAngle = p.PrecisionMinAllowedAngle;
            pc.PrecisionFlyAwayExtraDistance = p.PrecisionFlyAwayExtraDistance;

            pc.HighAltitude = p.HighAltitude;
            pc.LowAltitude = p.LowAltitude;
            pc.FuelRedZoneBaseValue = p.FuelRedZoneBaseValue;
            pc.FuelOrangeZoneSizeRatio = p.FuelOrangeZoneSizeRatio;
            pc.FuelOutChance = p.FuelOutChance;
            pc.DeathChance = p.DeathChance;
            pc.NextPointStepMultiplier = p.NextPointStepMultiplier;
            pc.DecreaseSpeedAngle = p.DecreaseSpeedAngle;

            pc.PlaneVsPlaneStopDistance = p.PlaneVsPlaneStopDistance;
            pc.PlaneVsPlaneEscapeDistance = p.PlaneVsPlaneEscapeDistance;
            pc.PlaneVsHeliDiveAngle = p.PlaneVsHeliDiveAngle;
            pc.PlaneVsHeliNoseUpExtraHeight = p.PlaneVsHeliNoseUpExtraHeight;

            pc.DEATH_MASS = p.DEATH_MASS;
            pc.DEATH_DRAG = p.DEATH_DRAG;
            pc.DEATH_ANGULAR_DRAG = p.DEATH_ANGULAR_DRAG;
            pc.DEATH_ENGINE_POWER_MULT = p.DEATH_ENGINE_POWER_MULT;
            pc.DEATH_ROTATE_POWER_MULT = p.DEATH_ROTATE_POWER_MULT;
            pc.DEATH_START_EPOWER_MULT = p.DEATH_START_EPOWER_MULT;
            pc.DEATH_START_RPOWER_MULT = p.DEATH_START_RPOWER_MULT;
            pc.DEATH_BLAST_POWER_MULT = p.DEATH_BLAST_POWER_MULT;
        }

        private static void ApplySupply(SupplyDto s, SupplyConfig sc)
        {
            sc.SupplyValueBought = s.SupplyValueBought;
            sc.SupplyExchangeRate = s.SupplyExchangeRate;
            sc.ResupplyRadius = s.ResupplyRadius;
            sc.AmmoCostMultiplier = s.AmmoCostMultiplier;
            sc.RepairRate = s.RepairRate;
            sc.RepairCost = s.RepairCost;
            sc.HealingCost = s.HealingCost;
            sc.HealingRate = s.HealingRate;
            sc.AbilityResupplyRate = s.AbilityResupplyRate;
            sc.AbilityMultiplierHeal = s.AbilityMultiplierHeal;
            sc.AbilityMultiplierRepair = s.AbilityMultiplierRepair;
            sc.AbilityMultiplierRearm = s.AbilityMultiplierRearm;
            sc.ViewDistance = s.ViewDistance;
            sc.ShowEnemySupplyRadius = s.ShowEnemySupplyRadius;
        }

        private static void ApplyGameConfigScalars(GameConfigDto g, GameConfig gc)
        {
            gc.DefaultPlayerMoney = g.DefaultPlayerMoney;
            gc.DefaultIncomePerMin = g.DefaultIncomePerMin;
            gc.UpkeepMultiplier = g.UpkeepMultiplier;
            gc.PlanesUpkeepMultiplier = g.PlanesUpkeepMultiplier;
            gc.DeadUnitsValueMultiplier = g.DeadUnitsValueMultiplier;
            gc.DeckCategoryValueMargin = g.DeckCategoryValueMargin;

            gc.DespawnDelaySec = g.DespawnDelaySec;
            gc.RefundMultiplier = g.RefundMultiplier;
            gc.RefundLostAmmoTimeMultiplier = g.RefundLostAmmoTimeMultiplier;
            gc.RepurchaseDelayFloor = g.RepurchaseDelayFloor;
            gc.RepurchaseDelayMultiplier = g.RepurchaseDelayMultiplier;
            gc.PlanesRefundFloor = g.PlanesRefundFloor;
            gc.PlanesRefundHPMultiplier = g.PlanesRefundHPMultiplier;
            gc.PlanesRefundAmmoCoeff_K = g.PlanesRefundAmmoCoeff_K;
            gc.PlanesRefundAmmoCoeff_P = g.PlanesRefundAmmoCoeff_P;
            gc.PlanesDeathIsMultiplierOfRefund = g.PlanesDeathIsMultiplierOfRefund;
            gc.PlanesDeathRefundMultiplier = g.PlanesDeathRefundMultiplier;
            gc.MinimumRefundPercent = g.MinimumRefundPercent;
            gc.MaximumRefundPercent = g.MaximumRefundPercent;
            gc.HealthCostMultiplier = g.HealthCostMultiplier;
            gc.ResurrectionEnabled = g.ResurrectionEnabled;
            gc.ResurrectDelayFloor = g.ResurrectDelayFloor;
            gc.ResurrectDelayMultiplier = g.ResurrectDelayMultiplier;
            gc.PlanesDeathPenalty = g.PlanesDeathPenalty;

            gc.PhysicsElasticity = g.PhysicsElasticity;
            gc.CoverSnapDistance = g.CoverSnapDistance;
            gc.CoverSnapSingleUnitModifier = g.CoverSnapSingleUnitModifier;
            gc.SprintSpeed = g.SprintSpeed;
            gc.GlobalForestSpeedMultiplier = g.GlobalForestSpeedMultiplier;
            gc.InfantryForestSpeedMultiplier = g.InfantryForestSpeedMultiplier;
            gc.HelicopterLowMultiplier = g.HelicopterLowMultiplier;
            gc.HelicopterCrashLowAltitude = g.HelicopterCrashLowAltitude;
            gc.HouseUnloadDelay = g.HouseUnloadDelay;
            gc.TransportUnloadDelay = g.TransportUnloadDelay;
            gc.HouseUnloadSprintMultiplier = g.HouseUnloadSprintMultiplier;
            gc.OnTransportDeathCargoForcedStressPercentage = g.OnTransportDeathCargoForcedStressPercentage;
            gc.OnTransportUnloadCargoForcedStressPercentage = g.OnTransportUnloadCargoForcedStressPercentage;
            gc.OnTransportDeathCargoKillFloor = g.OnTransportDeathCargoKillFloor;
            gc.OnTransportDeathCargoKillMultiplier = g.OnTransportDeathCargoKillMultiplier;
            gc.OnTransportDeathCargoKillHLFloor = g.OnTransportDeathCargoKillHLFloor;
            gc.OnTransportDeathCargoKillHLMultiplier = g.OnTransportDeathCargoKillHLMultiplier;
            gc.OnTransportDeathCargoKillHHFloor = g.OnTransportDeathCargoKillHHFloor;
            gc.OnTransportDeathCargoKillHHMultiplier = g.OnTransportDeathCargoKillHHMultiplier;
            gc.OnTransportDeathCargoKillAirFloor = g.OnTransportDeathCargoKillAirFloor;
            gc.OnTransportDeathCargoKillAirMultiplier = g.OnTransportDeathCargoKillAirMultiplier;
            gc.OnBuildingDestroyPrecentage = g.OnBuildingDestroyPrecentage;
            gc.TransportLoadDistance = g.TransportLoadDistance;
            gc.TransportLoadDistanceWithAnimation = g.TransportLoadDistanceWithAnimation;
            gc.WaitingTimeForLoadingInQueue = g.WaitingTimeForLoadingInQueue;
            gc.TransportLoadingHelpPointsOffset = g.TransportLoadingHelpPointsOffset;
            gc.MaxTimeForLoadOneUnit = g.MaxTimeForLoadOneUnit;
        }

        private static void ApplyFogOfWar(FogOfWarDto fw, FogOfWarConfig fc)
        {
            fc.MinimumDetectionDistance = fw.MinimumDetectionDistance;
            fc.MaxShootableForestDistance = fw.MaxShootableForestDistance;
            fc.LaserForestMaxRange = fw.LaserForestMaxRange;
            fc.LaserOwnForestRange = fw.LaserOwnForestRange;
            fc.FlashReduction = fw.FlashReduction;
            fc.MaxFlashValue = fw.MaxFlashValue;
            fc.MaxAntiVisible = fw.MaxAntiVisible;
            fc.SpottedPenalty = fw.SpottedPenalty;
            fc.SpottedPenaltyBuildings = fw.SpottedPenaltyBuildings;
            fc.SneakMinAntivisible = fw.SneakMinAntivisible;
        }

        private static void ApplyBuffs(BuffsDto bf, BuffConfig bc)
        {
            bc.ShockedLevelMultiplier = bf.ShockedLevelMultiplier;
            bc.PanickedLevelMultiplier = bf.PanickedLevelMultiplier;
            bc.ShockedLevelMultiplierInfantry = bf.ShockedLevelMultiplierInfantry;
            bc.PanickedLevelMultiplierInfantry = bf.PanickedLevelMultiplierInfantry;
            bc.StressRecoveryMultiplier = bf.StressRecoveryMultiplier;
            bc.StressDamageModThreshold = bf.StressDamageModThreshold;
            bc.CriticalBaseProbability = bf.CriticalBaseProbability;
            bc.RedCritsActivationThreshold = bf.RedCritsActivationThreshold;
            bc.MinorAimTimeMultiplier = bf.MinorAimTimeMultiplier;
            bc.MajorAimTimeMultiplier = bf.MajorAimTimeMultiplier;
            bc.MinorOpticsMultiplier = bf.MinorOpticsMultiplier;
            bc.MajorOpticsMultiplier = bf.MajorOpticsMultiplier;
            bc.MinorMobilityMultiplier = bf.MinorMobilityMultiplier;
            bc.MinorMobilityMultiplierRotation = bf.MinorMobilityMultiplierRotation;
            bc.MinorDispersionMultiplier = bf.MinorDispersionMultiplier;
            bc.MajorDispersionMultiplier = bf.MajorDispersionMultiplier;
            bc.MinorLoadingMultiplier = bf.MinorLoadingMultiplier;
            bc.MajorLoadingMultiplier = bf.MajorLoadingMultiplier;
        }

        private static void ApplyBuildings(BuildingsDto b, BuildingsConfig bc)
        {
            bc.BuildingDamageThreshold = b.BuildingDamageThreshold;
            bc.DamageModifierFloor = b.DamageModifierFloor;
            bc.DamageModifierPerSoldier = b.DamageModifierPerSoldier;
            bc.HitColliderReduction = b.HitColliderReduction;
        }

        private static void ApplyInfantry(InfantryDto inf, InfantryConfig ic)
        {
            ic.BaseSquadSize = inf.BaseSquadSize;
            ic.InfantryDeathTime = inf.InfantryDeathTime;
            ic.HorizontalTurretRotationSpeed = inf.HorizontalTurretRotationSpeed;
            ic.StartMovingMaxDelay = inf.StartMovingMaxDelay;
            ic.RunSpeed = inf.RunSpeed;
            ic.SprintSpeed = inf.SprintSpeed;
            ic.KneelRunSpeed = inf.KneelRunSpeed;
            ic.ProneRunSpeed = inf.ProneRunSpeed;
            ic.ProneSprintSpeed = inf.ProneSprintSpeed;
            ic.RotationSpeed = inf.RotationSpeed;
            ic.ShootAimRotationSpeed = inf.ShootAimRotationSpeed;
            ic.DistanceForSprint = inf.DistanceForSprint;
            ic.DistanceForSoldierStop = inf.DistanceForSoldierStop;
        }

        private static AnimationCurve BuildCurve(List<CurveKeyDto> keys)
        {
            if (keys == null || keys.Count == 0)
                return null;

            var ilKeys = new Il2CppStructArray<Keyframe>(keys.Count);
            for (int i = 0; i < keys.Count; i++)
            {
                CurveKeyDto k = keys[i];
                ilKeys[i] = new Keyframe(k.Time, k.Value, k.InTangent, k.OutTangent);
            }
            return new AnimationCurve(ilKeys);
        }
    }
}
