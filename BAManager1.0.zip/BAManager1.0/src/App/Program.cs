using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Windows.Forms;

namespace TrajectoryEditor
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
            CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

            if (args != null && args.Any(a => string.Equals(a, "--self-test", StringComparison.OrdinalIgnoreCase)))
            {
                return RunSelfTest();
            }

            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
            return 0;
        }

        private static int RunSelfTest()
        {
            try
            {
                string gameRoot = MainForm.FindGameRoot();
                string cfgPath = Path.Combine(gameRoot, "UserData", "TrajectoryEditor.json");
                string ammoPath = Path.Combine(gameRoot, "UserData", "MLDatabaseMod", "actual", "Ammunitions.json");

                Console.WriteLine($"GameRoot: {gameRoot}");

                // 1. Round-trip UserData\TrajectoryEditor.json via temp copy (all sections)
                TrajectoryConfig cfg = TrajectoryConfig.LoadOrCreate(cfgPath);
                string tmpCfg = Path.Combine(Path.GetTempPath(), $"te_cfg_{Guid.NewGuid():N}.json");
                try
                {
                    cfg.G = 72.5f;
                    cfg.CRUISE_MISSILE_PID[0] = 0.25f;
                    cfg.ARTILLERY_DISPERSION_CDF[0].OutTangent = 1.95f;
                    cfg.Planes.BombDropOffset = 12.5f;
                    cfg.Planes.StrafeMinLength = 550f;
                    cfg.Planes.PrecisionMinAllowedAngle = 35f;
                    cfg.Planes.PrecisionFlyAwayExtraDistance = 2400;
                    cfg.Supply.SupplyValueBought = 25;
                    cfg.Supply.SupplyExchangeRate = 1000;
                    cfg.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS = 1.75f;
                    cfg.GameConfig.DefaultIncomePerMin = 420f;
                    cfg.FogOfWar.MaxShootableForestDistance = 65f;
                    cfg.Buffs.CriticalBaseProbability = 15f;
                    cfg.Buildings.DamageModifierFloor = 0.35f;
                    cfg.Infantry.RunSpeed = 7.5f;
                    cfg.FormulaOverrides["DamageFormulaKinetic"] = new CustomFormulaDto
                    {
                        Enabled = true,
                        Expression = "baseDamage * 2"
                    };
                    int testTrajId = (cfg.CustomTrajectories.Count > 0 ? cfg.CustomTrajectories.Max(x => x.Id) : 999) + 1;
                    var tpl = TrajectoryCatalog.CreateTrajectoryTemplates()[0].Clone(testTrajId, "TestCustomArc");
                    tpl.AllowPrecisionStrike = true;
                    cfg.CustomTrajectories.Add(tpl);
                    cfg.PrecisionStrikeAmmoIds.Add(15);
                    cfg.WeaponTrajectoryAssignments.Add(new WeaponTrajectoryAssignmentDto
                    {
                        AmmunitionId = 1,
                        AmmunitionName = "TestAmmo",
                        WeaponHint = "TestWeapon",
                        CustomTrajectoryId = testTrajId,
                        OverrideBaseTrajectoryType = true
                    });
                    cfg.Save(tmpCfg);

                    TrajectoryConfig reloaded = TrajectoryConfig.LoadOrCreate(tmpCfg);
                    if (Math.Abs(reloaded.G - 72.5f) > 1e-4f ||
                        Math.Abs(reloaded.CRUISE_MISSILE_PID[0] - 0.25f) > 1e-4f ||
                        Math.Abs(reloaded.ARTILLERY_DISPERSION_CDF[0].OutTangent - 1.95f) > 1e-4f ||
                        Math.Abs(reloaded.Planes.BombDropOffset - 12.5f) > 1e-4f ||
                        Math.Abs(reloaded.Planes.StrafeMinLength - 550f) > 1e-4f ||
                        Math.Abs(reloaded.Planes.PrecisionMinAllowedAngle - 35f) > 1e-4f ||
                        reloaded.Planes.PrecisionFlyAwayExtraDistance != 2400 ||
                        reloaded.Supply.SupplyValueBought != 25 ||
                        reloaded.Supply.SupplyExchangeRate != 1000 ||
                        Math.Abs(reloaded.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS - 1.75f) > 1e-4f ||
                        Math.Abs(reloaded.GameConfig.DefaultIncomePerMin - 420f) > 1e-4f ||
                        Math.Abs(reloaded.FogOfWar.MaxShootableForestDistance - 65f) > 1e-4f ||
                        Math.Abs(reloaded.Buffs.CriticalBaseProbability - 15f) > 1e-4f ||
                        Math.Abs(reloaded.Buildings.DamageModifierFloor - 0.35f) > 1e-4f ||
                        Math.Abs(reloaded.Infantry.RunSpeed - 7.5f) > 1e-4f ||
                        !reloaded.FormulaOverrides.TryGetValue("DamageFormulaKinetic", out CustomFormulaDto fDto) ||
                        !fDto.Enabled ||
                        fDto.Expression != "baseDamage * 2" ||
                        !reloaded.CustomTrajectories.Any(x => x.Id == testTrajId && x.AllowPrecisionStrike) ||
                        !reloaded.PrecisionStrikeAmmoIds.Contains(15) ||
                        !reloaded.WeaponTrajectoryAssignments.Any(a => a.CustomTrajectoryId == testTrajId && a.AmmunitionId == 1))
                    {
                        Console.Error.WriteLine("FAIL: Global config round-trip mismatch.");
                        return 2;
                    }
                    Console.WriteLine(
                        $"Global config OK: Trajectories={TrajectoryCatalog.GlobalSettings.Count}+PID(3)+2curves, " +
                        $"Planes={TrajectoryCatalog.PlanesSettings.Count}, " +
                        $"SupplyEconomy={TrajectoryCatalog.SupplyAndEconomySettings.Count}, " +
                        $"GameFormulas={TrajectoryCatalog.GameFormulaSettings.Count}, " +
                        $"CustomRoundTrip=OK.");
                }
                finally
                {
                    if (File.Exists(tmpCfg)) File.Delete(tmpCfg);
                }

                // 2. Verify FormulaCatalog entries, params, live expressions, and trajectory templates
                foreach (FormulaEntry fe in FormulaCatalog.Formulas)
                {
                    if (string.IsNullOrWhiteSpace(fe.Equation))
                    {
                        Console.Error.WriteLine($"FAIL: Empty equation in formula '{fe.Title}'.");
                        return 6;
                    }
                    foreach (FormulaParamRef p in fe.Params)
                    {
                        _ = p.CurrentTextGetter(cfg);
                        _ = p.IsModified(cfg);
                    }
                    _ = fe.LiveExampleFunc?.Invoke(cfg);

                    if (fe.EditableSpec != null)
                    {
                        if (!TrajectoryEditorShared.FormulaExpressionEngine.TryCompile(fe.EditableSpec.DefaultExpression, out var compiled, out string err))
                        {
                            Console.Error.WriteLine($"FAIL: Editable formula '{fe.EditableSpec.OverrideKey}' failed compile: {err}");
                            return 7;
                        }
                        var vars = fe.EditableSpec.ConfigVarsInjector != null
                            ? fe.EditableSpec.ConfigVarsInjector(cfg)
                            : new System.Collections.Generic.Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                        foreach (string v in fe.EditableSpec.AllowedVariables)
                        {
                            if (!vars.ContainsKey(v)) vars[v] = 1.0;
                        }
                        _ = compiled.Evaluate(vars);
                    }
                }

                var templates = TrajectoryCatalog.CreateTrajectoryTemplates();
                foreach (CustomTrajectoryDto tpl in templates)
                {
                    if (tpl.UseCustomHeightFormula)
                    {
                        if (!TrajectoryEditorShared.FormulaExpressionEngine.TryCompile(tpl.HeightFormula, out var hExpr, out string hErr))
                        {
                            Console.Error.WriteLine($"FAIL: Template '{tpl.Name}' HeightFormula failed compile: {hErr}");
                            return 8;
                        }
                        for (int k = 0; k <= 4; k++)
                            _ = CustomTrajectoryPreviewCanvas.EvalHeight(hExpr, k * 0.25, 1000.0, 250.0);
                    }
                }
                Console.WriteLine($"FormulaReference OK: {FormulaCatalog.Formulas.Count} formulas ({FormulaCatalog.EditableFormulas.Count} live-editable) across {FormulaCatalog.Categories.Length - 1} categories; Templates={templates.Count}.");

                // 3. Parse Ammunitions.json and verify in-memory edits preserve all keys
                if (!File.Exists(ammoPath))
                {
                    Console.Error.WriteLine($"FAIL: Missing {ammoPath}");
                    return 3;
                }

                string rawAmmo = File.ReadAllText(ammoPath);
                JsonArray arr = JsonNode.Parse(rawAmmo)?.AsArray();
                if (arr == null || arr.Count == 0)
                {
                    Console.Error.WriteLine("FAIL: Empty or invalid Ammunitions.json.");
                    return 4;
                }

                JsonObject firstObj = arr[0].AsObject();
                int originalKeyCount = firstObj.Count;
                double oldRange = firstObj["GroundRange"]!.GetValue<double>();
                firstObj["GroundRange"] = oldRange * 1.1;
                string serialized = arr.ToJsonString();
                JsonArray reparsed = JsonNode.Parse(serialized)!.AsArray();
                if (reparsed[0]!.AsObject().Count != originalKeyCount)
                {
                    Console.Error.WriteLine("FAIL: Ammunition object key count changed after edit.");
                    return 5;
                }
                Console.WriteLine($"Ammunitions OK: {arr.Count} entries, {originalKeyCount} keys/entry preserved, {TrajectoryCatalog.AmmoFields.Count} editable trajectory fields.");

                // 3. Instantiate and dispose MainForm without starting UI message loop
                ApplicationConfiguration.Initialize();
                using var form = new MainForm(gameRoot);
                _ = form.Handle;
                Console.WriteLine("MainForm OK: constructed and disposed cleanly.");

                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"FAIL: {ex}");
                return 1;
            }
        }
    }
}
