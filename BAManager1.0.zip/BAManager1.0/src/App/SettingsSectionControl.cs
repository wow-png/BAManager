using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace TrajectoryEditor
{
    public sealed class SettingsSectionControl : UserControl
    {
        private readonly string[] _categories;
        private readonly IReadOnlyList<GlobalSettingMeta> _settings;
        private readonly Action<TrajectoryConfig> _resetSectionAction;
        private readonly Func<TrajectoryConfig, string> _summaryFunc;

        private TrajectoryConfig _config = new TrajectoryConfig();
        private bool _suppressEvents;

        private ListBox _lstCategories;
        private TextBox _txtSearch;
        private DataGridView _dgv;
        private Label _lblSummary;
        private Label _lblStatus;

        public event Action ConfigChanged;
        public event Action SaveRequested;
        public event Action ReloadRequested;

        public SettingsSectionControl(
            string[] categories,
            IReadOnlyList<GlobalSettingMeta> settings,
            Action<TrajectoryConfig> resetSectionAction,
            Func<TrajectoryConfig, string> summaryFunc = null)
        {
            _categories = categories;
            _settings = settings;
            _resetSectionAction = resetSectionAction;
            _summaryFunc = summaryFunc;

            Dock = DockStyle.Fill;
            BuildUi();
        }

        private void BuildUi()
        {
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1
            };
            UiLayoutHelper.ApplyInitialSplit(split, minPanel1: 200, minPanel2: 400, fixedPanel1: 260);

            var left = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(6),
                RowCount = 4,
                ColumnCount = 1
            };
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            left.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            left.Controls.Add(new Label { Text = "Поиск параметра:", AutoSize = true, Margin = new Padding(0, 0, 0, 3) }, 0, 0);
            _txtSearch = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Поиск по имени или описанию..." };
            _txtSearch.TextChanged += (_, _) => PopulateGrid();
            left.Controls.Add(_txtSearch, 0, 1);

            left.Controls.Add(new Label { Text = "Категории:", AutoSize = true, Margin = new Padding(0, 8, 0, 3) }, 0, 2);
            _lstCategories = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false };
            foreach (string c in _categories)
                _lstCategories.Items.Add(c);
            if (_lstCategories.Items.Count > 0)
                _lstCategories.SelectedIndex = 0;
            _lstCategories.SelectedIndexChanged += (_, _) => PopulateGrid();
            left.Controls.Add(_lstCategories, 0, 3);
            split.Panel1.Controls.Add(left);

            var right = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = _summaryFunc != null ? 3 : 2,
                ColumnCount = 1
            };

            int gridRow = 0;
            if (_summaryFunc != null)
            {
                var summaryBar = new Panel
                {
                    Dock = DockStyle.Fill,
                    AutoSize = true,
                    Padding = new Padding(8, 6, 8, 6),
                    BackColor = Color.FromArgb(232, 242, 255)
                };
                _lblSummary = new Label
                {
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(18, 66, 130)
                };
                summaryBar.Controls.Add(_lblSummary);
                right.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                right.Controls.Add(summaryBar, 0, 0);
                gridRow = 1;
            }

            right.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            right.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            _dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
            UiLayoutHelper.StyleDataGrid(_dgv);
            _dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Key", HeaderText = "Параметр", ReadOnly = true, Width = 310 });
            _dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Значение", Width = 130 });
            _dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Vanilla", HeaderText = "Ваниль", ReadOnly = true, Width = 90 });
            _dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Desc", HeaderText = "Описание", ReadOnly = true, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });

            _dgv.DataError += (_, e) => { e.ThrowException = false; };
            _dgv.CurrentCellDirtyStateChanged += (_, _) =>
            {
                if (_dgv.IsCurrentCellDirty && (_dgv.CurrentCell is DataGridViewCheckBoxCell || _dgv.CurrentCell is DataGridViewComboBoxCell))
                    _dgv.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _dgv.CellValueChanged += OnCellValueChanged;

            right.Controls.Add(_dgv, 0, gridRow);

            var bottomFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(6),
                BackColor = Color.FromArgb(242, 244, 248)
            };

            var btnSave = new Button
            {
                Text = "Сохранить всё (UserData\\TrajectoryEditor.json)",
                AutoSize = true,
                BackColor = Color.FromArgb(215, 238, 215),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
            btnSave.Click += (_, _) => SaveRequested?.Invoke();

            var btnReload = new Button { Text = "Перезагрузить", AutoSize = true };
            btnReload.Click += (_, _) => ReloadRequested?.Invoke();

            var btnResetCat = new Button { Text = "Сбросить категорию", AutoSize = true };
            btnResetCat.Click += (_, _) => ResetCategory();

            var btnResetTab = new Button { Text = "Сбросить вкладку к ванили", AutoSize = true };
            btnResetTab.Click += (_, _) => ResetTab();

            _lblStatus = new Label { AutoSize = true, Margin = new Padding(12, 6, 4, 4), ForeColor = Color.DimGray };

            bottomFlow.Controls.AddRange(new Control[] { btnSave, btnReload, btnResetCat, btnResetTab, _lblStatus });
            right.Controls.Add(bottomFlow, 0, gridRow + 1);

            split.Panel2.Controls.Add(right);
            Controls.Add(split);
        }

        public void BindConfig(TrajectoryConfig config)
        {
            _config = config ?? new TrajectoryConfig();
            PopulateGrid();
            RefreshSummary();
        }

        public void CommitPendingEdits()
        {
            _dgv?.EndEdit();
        }

        public void SetStatus(string text, Color color)
        {
            _lblStatus.Text = text;
            _lblStatus.ForeColor = color;
        }

        public int RowCount => _dgv.Rows.Count;

        private void RefreshSummary()
        {
            if (_summaryFunc != null && _lblSummary != null)
                _lblSummary.Text = _summaryFunc(_config);
        }

        private void PopulateGrid()
        {
            _suppressEvents = true;
            try
            {
                _dgv.Rows.Clear();
                string selectedCat = _lstCategories.SelectedItem as string ?? TrajectoryCatalog.CatAll;
                string query = (_txtSearch.Text ?? string.Empty).Trim();

                foreach (GlobalSettingMeta meta in _settings)
                {
                    if (!string.Equals(selectedCat, TrajectoryCatalog.CatAll, StringComparison.Ordinal) &&
                        !string.Equals(meta.Category, selectedCat, StringComparison.Ordinal))
                        continue;

                    if (!string.IsNullOrEmpty(query) &&
                        meta.Key.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0 &&
                        meta.DescriptionRu.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0)
                        continue;

                    int rowIdx = _dgv.Rows.Add();
                    DataGridViewRow r = _dgv.Rows[rowIdx];
                    r.Tag = meta;
                    r.Cells["Key"].Value = meta.Key;
                    r.Cells["Desc"].Value = meta.DescriptionRu;

                    object curVal = meta.Getter(_config);
                    if (meta.Kind == SettingValueKind.Bool)
                    {
                        r.Cells["Value"] = new DataGridViewCheckBoxCell { Value = Convert.ToBoolean(curVal, CultureInfo.InvariantCulture) };
                        r.Cells["Vanilla"].Value = Convert.ToBoolean(meta.VanillaValue, CultureInfo.InvariantCulture) ? "true" : "false";
                    }
                    else
                    {
                        r.Cells["Value"].Value = FormatVal(curVal);
                        r.Cells["Vanilla"].Value = FormatVal(meta.VanillaValue);
                    }

                    UpdateRowHighlight(r, meta);
                }
            }
            finally
            {
                _suppressEvents = false;
            }
        }

        private void OnCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_suppressEvents || e.RowIndex < 0 || e.ColumnIndex != _dgv.Columns["Value"].Index)
                return;

            DataGridViewRow row = _dgv.Rows[e.RowIndex];
            if (row.Tag is not GlobalSettingMeta meta)
                return;

            object raw = row.Cells["Value"].Value;
            string s = Convert.ToString(raw, CultureInfo.InvariantCulture)?.Trim().Replace(',', '.') ?? string.Empty;
            bool ok = true;

            try
            {
                switch (meta.Kind)
                {
                    case SettingValueKind.Bool:
                        meta.Setter(_config, Convert.ToBoolean(raw, CultureInfo.InvariantCulture));
                        break;
                    case SettingValueKind.Int:
                        if (int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int iv))
                        {
                            meta.Setter(_config, iv);
                            SetTextSilent(row, iv.ToString(CultureInfo.InvariantCulture));
                        }
                        else ok = false;
                        break;
                    case SettingValueKind.UInt:
                        if (uint.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out uint uv))
                        {
                            meta.Setter(_config, uv);
                            SetTextSilent(row, uv.ToString(CultureInfo.InvariantCulture));
                        }
                        else ok = false;
                        break;
                    case SettingValueKind.UShort:
                        if (ushort.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out ushort usv))
                        {
                            meta.Setter(_config, usv);
                            SetTextSilent(row, usv.ToString(CultureInfo.InvariantCulture));
                        }
                        else ok = false;
                        break;
                    case SettingValueKind.Float:
                        if (float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out float fv))
                        {
                            meta.Setter(_config, fv);
                            SetTextSilent(row, fv.ToString("G9", CultureInfo.InvariantCulture));
                        }
                        else ok = false;
                        break;
                }
            }
            catch
            {
                ok = false;
            }

            if (!ok)
            {
                SetTextSilent(row, FormatVal(meta.Getter(_config)));
                return;
            }

            UpdateRowHighlight(row, meta);
            RefreshSummary();
            ConfigChanged?.Invoke();
        }

        private void SetTextSilent(DataGridViewRow row, string txt)
        {
            _suppressEvents = true;
            row.Cells["Value"].Value = txt;
            _suppressEvents = false;
        }

        private void UpdateRowHighlight(DataGridViewRow row, GlobalSettingMeta meta)
        {
            bool changed = !AreEqual(meta.Getter(_config), meta.VanillaValue, meta.Kind);
            row.DefaultCellStyle.BackColor = changed ? Color.FromArgb(255, 244, 214) : Color.White;
        }

        private void ResetCategory()
        {
            string selectedCat = _lstCategories.SelectedItem as string ?? TrajectoryCatalog.CatAll;
            if (string.Equals(selectedCat, TrajectoryCatalog.CatAll, StringComparison.Ordinal))
            {
                ResetTab();
                return;
            }

            foreach (GlobalSettingMeta meta in _settings)
            {
                if (string.Equals(meta.Category, selectedCat, StringComparison.Ordinal))
                    meta.Setter(_config, meta.VanillaValue);
            }

            PopulateGrid();
            RefreshSummary();
            ConfigChanged?.Invoke();
        }

        private void ResetTab()
        {
            _resetSectionAction(_config);
            PopulateGrid();
            RefreshSummary();
            ConfigChanged?.Invoke();
        }

        private static string FormatVal(object val) => val switch
        {
            float f => f.ToString("G9", CultureInfo.InvariantCulture),
            int i => i.ToString(CultureInfo.InvariantCulture),
            uint u => u.ToString(CultureInfo.InvariantCulture),
            ushort us => us.ToString(CultureInfo.InvariantCulture),
            byte b => b.ToString(CultureInfo.InvariantCulture),
            _ => Convert.ToString(val, CultureInfo.InvariantCulture) ?? ""
        };

        private static bool AreEqual(object a, object b, SettingValueKind kind) => kind switch
        {
            SettingValueKind.Bool => Convert.ToBoolean(a, CultureInfo.InvariantCulture) == Convert.ToBoolean(b, CultureInfo.InvariantCulture),
            SettingValueKind.Int => Convert.ToInt32(a, CultureInfo.InvariantCulture) == Convert.ToInt32(b, CultureInfo.InvariantCulture),
            SettingValueKind.UInt => Convert.ToUInt32(a, CultureInfo.InvariantCulture) == Convert.ToUInt32(b, CultureInfo.InvariantCulture),
            SettingValueKind.UShort => Convert.ToUInt16(a, CultureInfo.InvariantCulture) == Convert.ToUInt16(b, CultureInfo.InvariantCulture),
            SettingValueKind.SwitchRuleEnum => Convert.ToByte(a, CultureInfo.InvariantCulture) == Convert.ToByte(b, CultureInfo.InvariantCulture),
            _ => Math.Abs(Convert.ToSingle(a, CultureInfo.InvariantCulture) - Convert.ToSingle(b, CultureInfo.InvariantCulture)) < 1e-5f
        };
    }
}
