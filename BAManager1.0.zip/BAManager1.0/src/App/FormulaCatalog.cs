using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TrajectoryEditor
{
    public sealed class FormulaParamRef
    {
        public string Key { get; }
        public int EditTabIndex { get; }
        public string VanillaText { get; }
        public Func<TrajectoryConfig, string> CurrentTextGetter { get; }
        public Func<TrajectoryConfig, bool> IsModified { get; }

        public FormulaParamRef(
            string key,
            int editTabIndex,
            string vanillaText,
            Func<TrajectoryConfig, string> currentTextGetter,
            Func<TrajectoryConfig, bool> isModified)
        {
            Key = key;
            EditTabIndex = editTabIndex;
            VanillaText = vanillaText;
            CurrentTextGetter = currentTextGetter;
            IsModified = isModified;
        }
    }

    public sealed class EditableFormulaSpec
    {
        public string OverrideKey { get; }
        public string[] AllowedVariables { get; }
        public string DefaultExpression { get; }
        public string DefaultTestInputs { get; }
        public Func<TrajectoryConfig, Dictionary<string, double>> ConfigVarsInjector { get; }

        public EditableFormulaSpec(
            string overrideKey,
            string[] allowedVariables,
            string defaultExpression,
            string defaultTestInputs,
            Func<TrajectoryConfig, Dictionary<string, double>> configVarsInjector = null)
        {
            OverrideKey = overrideKey;
            AllowedVariables = allowedVariables;
            DefaultExpression = defaultExpression;
            DefaultTestInputs = defaultTestInputs;
            ConfigVarsInjector = configVarsInjector;
        }
    }

    public sealed class FormulaEntry
    {
        public string Category { get; }
        public string Title { get; }
        public string EngineRef { get; }
        public string Equation { get; }
        public string VariablesRu { get; }
        public string NotesRu { get; }
        public int PrimaryTabIndex { get; }
        public IReadOnlyList<FormulaParamRef> Params { get; }
        public Func<TrajectoryConfig, string> LiveExampleFunc { get; }
        public EditableFormulaSpec EditableSpec { get; }

        public FormulaEntry(
            string category,
            string title,
            string engineRef,
            string equation,
            string variablesRu,
            string notesRu,
            int primaryTabIndex,
            IReadOnlyList<FormulaParamRef> @params,
            Func<TrajectoryConfig, string> liveExampleFunc,
            EditableFormulaSpec editableSpec = null)
        {
            Category = category;
            Title = title;
            EngineRef = engineRef;
            Equation = equation;
            VariablesRu = variablesRu;
            NotesRu = notesRu;
            PrimaryTabIndex = primaryTabIndex;
            Params = @params;
            LiveExampleFunc = liveExampleFunc;
            EditableSpec = editableSpec;
        }
    }

    public static class FormulaCatalog
    {
        public const string CatAll = "Все формулы";
        public const string CatDamage = "Урон и бронепробитие";
        public const string CatAccuracy = "Точность, ракеты и ЛТЦ/РЭП";
        public const string CatBallistics = "Траектории и баллистика";
        public const string CatFow = "Видимость, стелс и лес (FoW)";
        public const string CatStress = "Стресс, паника и криты";
        public const string CatEconomy = "Саплай, экономика и респавн";
        public const string CatPlanes = "Авиация (Бомбинг / Штурм / Пресижен)";
        public const string CatInfantry = "Пехота, скорости и транспорт";

        public static readonly string[] Categories =
        {
            CatAll,
            CatDamage,
            CatAccuracy,
            CatBallistics,
            CatFow,
            CatStress,
            CatEconomy,
            CatPlanes,
            CatInfantry
        };

        private static readonly Dictionary<string, (int TabIdx, GlobalSettingMeta Meta)> ParamLookup = BuildParamLookup();

        private static Dictionary<string, (int TabIdx, GlobalSettingMeta Meta)> BuildParamLookup()
        {
            var dict = new Dictionary<string, (int, GlobalSettingMeta)>(StringComparer.Ordinal);
            void Register(int tabIdx, IReadOnlyList<GlobalSettingMeta> list)
            {
                foreach (GlobalSettingMeta m in list)
                    dict[m.Key] = (tabIdx, m);
            }

            Register(0, TrajectoryCatalog.GlobalSettings);
            Register(1, TrajectoryCatalog.PlanesSettings);
            Register(2, TrajectoryCatalog.SupplyAndEconomySettings);
            Register(3, TrajectoryCatalog.GameFormulaSettings);
            return dict;
        }

        private static string FormatMetaValue(object val, SettingValueKind kind)
        {
            if (val == null) return "0";
            return kind switch
            {
                SettingValueKind.Bool => Convert.ToBoolean(val, CultureInfo.InvariantCulture) ? "true" : "false",
                SettingValueKind.SwitchRuleEnum => TrajectoryCatalog.FormatSwitchRule(Convert.ToByte(val, CultureInfo.InvariantCulture)),
                SettingValueKind.Int => Convert.ToInt32(val, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture),
                SettingValueKind.UInt => Convert.ToUInt32(val, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture),
                SettingValueKind.UShort => Convert.ToUInt16(val, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture),
                _ => Convert.ToSingle(val, CultureInfo.InvariantCulture).ToString("G7", CultureInfo.InvariantCulture)
            };
        }

        private static bool IsMetaModified(object cur, object def, SettingValueKind kind)
        {
            return kind switch
            {
                SettingValueKind.Bool => Convert.ToBoolean(cur, CultureInfo.InvariantCulture) != Convert.ToBoolean(def, CultureInfo.InvariantCulture),
                SettingValueKind.SwitchRuleEnum => Convert.ToByte(cur, CultureInfo.InvariantCulture) != Convert.ToByte(def, CultureInfo.InvariantCulture),
                SettingValueKind.Int => Convert.ToInt32(cur, CultureInfo.InvariantCulture) != Convert.ToInt32(def, CultureInfo.InvariantCulture),
                SettingValueKind.UInt => Convert.ToUInt32(cur, CultureInfo.InvariantCulture) != Convert.ToUInt32(def, CultureInfo.InvariantCulture),
                SettingValueKind.UShort => Convert.ToUInt16(cur, CultureInfo.InvariantCulture) != Convert.ToUInt16(def, CultureInfo.InvariantCulture),
                _ => Math.Abs(Convert.ToSingle(cur, CultureInfo.InvariantCulture) - Convert.ToSingle(def, CultureInfo.InvariantCulture)) > 1e-5f
            };
        }

        private static FormulaParamRef P(string key)
        {
            if (!ParamLookup.TryGetValue(key, out var entry))
                throw new InvalidOperationException($"Unknown formula param key: {key}");

            GlobalSettingMeta m = entry.Meta;
            int tabIdx = entry.TabIdx;
            return new FormulaParamRef(
                m.Key,
                tabIdx,
                FormatMetaValue(m.VanillaValue, m.Kind),
                c => FormatMetaValue(m.Getter(c), m.Kind),
                c => IsMetaModified(m.Getter(c), m.VanillaValue, m.Kind));
        }

        private static FormulaParamRef PidRef() => new FormulaParamRef(
            "CRUISE_MISSILE_PID",
            0,
            "[0.2, 0, 13]",
            c => $"[{c.CRUISE_MISSILE_PID[0]:G6}, {c.CRUISE_MISSILE_PID[1]:G6}, {c.CRUISE_MISSILE_PID[2]:G6}]",
            c => Math.Abs(c.CRUISE_MISSILE_PID[0] - 0.2f) > 1e-5f ||
                 Math.Abs(c.CRUISE_MISSILE_PID[1] - 0f) > 1e-5f ||
                 Math.Abs(c.CRUISE_MISSILE_PID[2] - 13f) > 1e-5f);

        private static IReadOnlyList<FormulaParamRef> Refs(params string[] keys) => keys.Select(P).ToArray();

        private static string Fmt(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);

        public static readonly IReadOnlyList<FormulaEntry> Formulas = new[]
        {
            // =========================================================================
            // 1. УРОН И БРОНЕПРОБИТИЕ
            // =========================================================================
            new FormulaEntry(
                CatDamage,
                "1. Падение пробития с дистанцией (Kinetic vs HEAT)",
                "BattleSystemHelpers.GetPenetration",
                "HEAT / не-кинетика:  Pen(d) = Pen_min\n" +
                "Kinetic (БОПС / АП): Pen(d) = Clamp(Pen_min − ((Pen_min − Pen_max) / (MaxRange − MinRange)) × d, 0, Pen_min)",
                "isKinetic (1=БОПС, 0=HEAT), penMin, penMax, minRange, maxRange, distance.",
                "Кумулятивные снаряды и ПТУР не теряют пробитие от расстояния. Кинетические теряют его линейно.",
                6,
                Array.Empty<FormulaParamRef>(),
                _ =>
                {
                    float pMin = 700f, pMax = 500f, rMin = 0f, rMax = 2000f, d = 1000f;
                    float penD = Math.Clamp(pMin - ((pMin - pMax) / (rMax - rMin)) * d, 0f, pMin);
                    return $"БОПС с Pen={pMin}→{pMax} мм (0–{rMax} м) на дистанции {d} м пробивает {Fmt(penD)} мм.";
                },
                new EditableFormulaSpec(
                    "GetPenetration",
                    new[] { "isKinetic", "penMin", "penMax", "minRange", "maxRange", "distance" },
                    "isKinetic < 0.5 ? penMin : clamp(penMin - ((penMin - penMax) / max(0.001, maxRange - minRange)) * distance, 0, penMin)",
                    "isKinetic=1; penMin=700; penMax=500; minRange=0; maxRange=2000; distance=1000")),

            new FormulaEntry(
                CatDamage,
                "2. Кинетический урон (БОПС / автопушки)",
                "BattleSystemHelpers.DamageFormulaKinetic",
                "Если Pen ≥ Armor:\n" +
                "  Damage = BaseDamage\n" +
                "Если Pen < Armor:\n" +
                "  Raw = BaseDamage × (1 + (Pen − Armor) / (Pen × ARMOR_PENETRATION_EFFECTIVENESS))\n" +
                "  Damage = max(0, max(Raw, BaseDamage × MINIMAL_DAMAGE_COEFFICIENT))",
                "baseDamage, pen, armor, effectiveness (из ARMOR_PENETRATION_EFFECTIVENESS), minCoeff (из MINIMAL_DAMAGE_COEFFICIENT).",
                "При недопробитии урон падает линейно вплоть до минимальной доли minCoeff. Можно полностью переписать формулу в редакторе ниже.",
                3,
                Refs("ARMOR_PENETRATION_EFFECTIVENESS", "MINIMAL_DAMAGE_COEFFICIENT"),
                c =>
                {
                    float baseDmg = 100f, pen = 400f, armor = 600f;
                    float scale = c.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS;
                    float minCoeff = c.CombatFormulas.MINIMAL_DAMAGE_COEFFICIENT;
                    if (scale <= 1e-5f) return "ARMOR_PENETRATION_EFFECTIVENESS = 0 → деление на 0, формула отключена (0 урона при Pen < Armor).";
                    float raw = baseDmg * (1f + (pen - armor) / (pen * scale));
                    float floor = baseDmg * minCoeff;
                    float dmg = Math.Max(0f, Math.Max(raw, floor));
                    return $"Base={baseDmg}, Pen={pen} мм vs Armor={armor} мм → Raw={Fmt(raw)}, Floor={Fmt(floor)}, Итог={Fmt(dmg)} урона.";
                },
                new EditableFormulaSpec(
                    "DamageFormulaKinetic",
                    new[] { "baseDamage", "pen", "armor", "effectiveness", "minCoeff" },
                    "pen >= armor ? baseDamage : max(0, max(baseDamage * (1 + (pen - armor) / max(0.001, pen * effectiveness)), baseDamage * minCoeff))",
                    "baseDamage=100; pen=400; armor=600",
                    c => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
                    {
                        ["effectiveness"] = c.CombatFormulas.ARMOR_PENETRATION_EFFECTIVENESS,
                        ["minCoeff"] = c.CombatFormulas.MINIMAL_DAMAGE_COEFFICIENT
                    })),

            new FormulaEntry(
                CatDamage,
                "2б. Порог рикошета / непробития",
                "BattleSystemHelpers.CalculateHitDamageWithThreshold",
                "Если isHeat > 0: возвращается damage как есть\n" +
                "Если damage > threshold: damage\n" +
                "Иначе: 0 (рикошет / броня не пробита)",
                "damage — расчётный урон из кинетики/HEAT; threshold — DamageThreshold снаряда; isHeat (1=HEAT, 0=Кинетика).",
                "Определяет отсечку малого урона кинетических снарядов в рикошет.",
                6,
                Array.Empty<FormulaParamRef>(),
                _ => "По умолчанию: при damage=8 и threshold=10 (isHeat=0) снаряд рикошетит (0 урона).",
                new EditableFormulaSpec(
                    "CalculateHitDamageWithThreshold",
                    new[] { "damage", "threshold", "isHeat" },
                    "isHeat > 0.5 ? damage : (damage > threshold ? damage : 0)",
                    "damage=8; threshold=10; isHeat=0")),

            new FormulaEntry(
                CatDamage,
                "3. Кумулятивный (HEAT) урон и броня пехоты",
                "BattleSystemHelpers.DamageFormulaHEAT",
                "Damage = BaseDamage × (Pen^p / (Pen^p + k × Armor^p))\n" +
                "где p = HEAT_CURVE_COEFFICIENT,  k = HE_ARMOR_EFFECTIVENESS",
                "baseDamage, pen, armor, p (из HEAT_CURVE_COEFFICIENT), k (из HE_ARMOR_EFFECTIVENESS).",
                "Плавная степенная сигмоида без жёсткого рикошета. По этой же кривой считается урон по броне пехоты.",
                3,
                Refs("HEAT_CURVE_COEFFICIENT", "HE_ARMOR_EFFECTIVENESS"),
                c =>
                {
                    double p = c.CombatFormulas.HEAT_CURVE_COEFFICIENT;
                    double k = c.CombatFormulas.HE_ARMOR_EFFECTIVENESS;
                    double penPow = Math.Pow(600.0, p);
                    double armPow = Math.Pow(600.0, p);
                    double denom = penPow + k * armPow;
                    double tankDmg = denom > 1e-6 ? 100.0 * (penPow / denom) : 0.0;
                    double infPenPow = Math.Pow(15.0, p);
                    double infArmPow = Math.Pow(8.0, p);
                    double infDenom = infPenPow + k * infArmPow;
                    double infDmg = infDenom > 1e-6 ? 4.0 * (infPenPow / infDenom) : 0.0;
                    return $"HEAT Pen=600 vs Armor=600 (Base=100) → {Fmt(tankDmg)} урона | Пехота Pen=15 vs Armor=8 (Base=4) → {Fmt(infDmg)}.";
                },
                new EditableFormulaSpec(
                    "DamageFormulaHEAT",
                    new[] { "baseDamage", "pen", "armor", "p", "k" },
                    "baseDamage * pow(max(0, pen), p) / max(0.0001, pow(max(0, pen), p) + k * pow(max(0, armor), p))",
                    "baseDamage=100; pen=600; armor=600",
                    c => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
                    {
                        ["p"] = c.CombatFormulas.HEAT_CURVE_COEFFICIENT,
                        ["k"] = c.CombatFormulas.HE_ARMOR_EFFECTIVENESS
                    })),

            new FormulaEntry(
                CatDamage,
                "4. Определение проекции брони (Front / Sides / Rear / Top)",
                "BattleSystemHelpers.GetArmorSideFromShotVector",
                "localImpact = InverseTransformDirection(normalize(ImpactVector))\n" +
                "Если TopArmorAttack == true ИЛИ localImpact.y < -0.707 (угол > 45°) → Top\n" +
                "Иначе если dot(localImpact, Forward) < -0.707 → Front\n" +
                "Иначе если dot(localImpact, Forward) > +0.707 → Rear\n" +
                "Иначе → Sides",
                "0.707 = cos(45°). Попадания в крышу здания проверяются через BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE.",
                "При угле входа круче 45° сверху или при флаге TopArmorAttack (Javelin/NLAW) урон уходит в броню крыши.",
                0,
                Refs("BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE"),
                c => $"Порог угла атаки крыши зданий: {Fmt(c.BUILDINGS_TOP_ARMOR_AIMING_TRESHOLD_ANGLE)}°."),

            new FormulaEntry(
                CatDamage,
                "5. Ближний бой пехоты (CQC)",
                "BattleSystemHelpers.CalculateCQCHitDamage",
                "Интервал проверки тика CQC = CQCTick (сек)\n" +
                "Вероятность нанесения урона за тик = CQCChance",
                "CQCTick — период удара в ближнем бою в одном здании/на малой дистанции; CQCChance — базовый шанс срабатывания.",
                "Множитель частоты боёвки вплотную: уменьшение CQCTick ускоряет размен пехоты в домах.",
                3,
                Refs("CQCTick", "CQCChance"),
                c =>
                {
                    float tick = c.CombatFormulas.CQCTick;
                    float rate = tick > 1e-4f ? c.CombatFormulas.CQCChance / tick : 0f;
                    return $"Средняя частота срабатываний CQC: {Fmt(rate)} в сек (раз в {Fmt(tick)} с с шансом {Fmt(c.CombatFormulas.CQCChance * 100f)}%).";
                }),

            new FormulaEntry(
                CatDamage,
                "6. Урон по зданиям и гарнизону",
                "ShellHitSystem.DamageBuilding + BuildingsConfig",
                "Если Урон ≥ BuildingDamageThreshold → здание получает структурный урон\n" +
                "Модификатор урона гарнизону = max(DamageModifierFloor, BaseMod + Soldiers × DamageModifierPerSoldier)\n" +
                "При обрушении здания гибнет OnBuildingDestroyPrecentage % гарнизона",
                "BuildingDamageThreshold — порог пробития конструкции здания; OnBuildingDestroyPrecentage — % потерь при разрушении дома.",
                "Уменьшение DamageModifierFloor делает укрытия прочнее для пехоты; увеличение HitColliderReduction сужает хитбокс зданий.",
                3,
                Refs("BuildingDamageThreshold", "DamageModifierFloor", "DamageModifierPerSoldier", "HitColliderReduction", "OnBuildingDestroyPrecentage"),
                c =>
                {
                    float mod6 = Math.Max(c.Buildings.DamageModifierFloor, c.Buildings.DamageModifierFloor + 6f * c.Buildings.DamageModifierPerSoldier);
                    return $"Порог урона зданию: {c.Buildings.BuildingDamageThreshold}, мин. коэфф. по гарнизону: {Fmt(c.Buildings.DamageModifierFloor)} (+{Fmt(c.Buildings.DamageModifierPerSoldier)}/боец → ~{Fmt(mod6)} для 6 чел.), при сносе дома потери {c.GameConfig.OnBuildingDestroyPrecentage}%.";
                }),

            // =========================================================================
            // 2. ТОЧНОСТЬ, РАКЕТЫ И ЛТЦ/РЭП
            // =========================================================================
            new FormulaEntry(
                CatAccuracy,
                "7. Шанс попадания неуправляемого оружия и разброс",
                "BattleSystemHelpers.GetTargetAccuracy",
                "ratio = Clamp01(Distance / DispersionReferenceRange)\n" +
                "scale = Clamp01(DispersionMinimal + (1 − DispersionMinimal) × ratio)\n" +
                "DispH = scale × DispersionHorizontalRadius,  DispV = scale × DispersionVerticalRadius\n" +
                "HitChance = Clamp01((min(DispH, TargetWidth) × min(DispV, TargetHeight)) / (DispH × DispV))",
                "vanilla (расчётный шанс игры 0..1), distance, dispH, dispV, dispMin, refRange.",
                "Постфикс позволяет отмасштабировать или пересчитать шанс попадания (например clamp01(vanilla * 1.15) или собственную кривую по distance).",
                0,
                Refs("MIN_POINT_DISPERSION", "MAX_POINT_DISPERSION_MULTIPLIER", "ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS"),
                c => $"Мин. разброс по точке: {Fmt(c.MIN_POINT_DISPERSION)} м (макс. множитель ×{Fmt(c.MAX_POINT_DISPERSION_MULTIPLIER)}), бонус габарита самолётов +{Fmt(c.ADDITIONAL_PLANE_SIZE_FOR_UNGUIDED_SHELLS)} м.",
                new EditableFormulaSpec(
                    "GetTargetAccuracy",
                    new[] { "vanilla", "distance", "dispH", "dispV", "dispMin", "refRange" },
                    "vanilla",
                    "vanilla=0.65; distance=1000; dispH=6; dispV=4; dispMin=0.2; refRange=2000")),

            new FormulaEntry(
                CatAccuracy,
                "8. Шанс попадания ракеты с РЭП и ЛТЦ (Flares / ECM)",
                "BattleSystemHelpers.CalculateMissileHitChance",
                "CountermeasuresEffect = ((1 − flareResist) × decoyEffect) ^ decoys\n" +
                "HitChance = accuracy × ecm × CountermeasuresEffect × stress × veterancy × crit",
                "accuracy, flareResist, ecm (= 1 − ECM%), decoyEffect, decoys, stress, veterancy, crit.",
                "Каждый отстрел ЛТЦ возводит защитный фактор в степень decoys. Можно изменить формулу напрямую (например ограничить влияние ЛТЦ/РЭП).",
                3,
                Refs("MAX_FLARES_COUNT_MISSILE_INITIAL", "MAX_FLARES_COUNT_MISSILE_REROLL", "AUTOFLARES_PLANES_DELAY", "AUTOFLARES_HELICOPTERS_DELAY", "ACTIVE_APS_IGNORES_ONE_MISSILE"),
                c =>
                {
                    double acc = 0.85, ecm = 0.70, resist = 0.25, decoy = 0.70;
                    int decoys = 2;
                    double cmEff = Math.Pow((1.0 - resist) * decoy, decoys);
                    double chance = acc * ecm * cmEff;
                    return $"Acc=85%, ECM=30% (×0.7), Resist=0.25, DecoyEffect=0.7 × {decoys} ЛТЦ → итоговый шанс {Fmt(chance * 100.0)}% (задержка авто-ЛТЦ: самолёт {Fmt(c.CombatFormulas.AUTOFLARES_PLANES_DELAY)}с, вертолёт {Fmt(c.CombatFormulas.AUTOFLARES_HELICOPTERS_DELAY)}с).";
                },
                new EditableFormulaSpec(
                    "CalculateMissileHitChance",
                    new[] { "accuracy", "flareResist", "ecm", "decoyEffect", "decoys", "stress", "veterancy", "crit" },
                    "accuracy * ecm * pow((1 - flareResist) * decoyEffect, decoys) * stress * veterancy * crit",
                    "accuracy=0.85; flareResist=0.25; ecm=0.7; decoyEffect=0.7; decoys=2; stress=1; veterancy=1; crit=1")),

            new FormulaEntry(
                CatAccuracy,
                "8б. Эффективность ЛТЦ (Countermeasures)",
                "BattleSystemHelpers.CalculateCountermeasuresEffect",
                "CountermeasuresEffect = ((1 − flareResist) × decoyEffect) ^ count",
                "decoyEffect — множитель ловушки цели; flareResist — устойчивость ракеты к помехам; count — число активных ловушек.",
                "Используется при расчёте срыва ракеты на ловушки и в ИИ выбора целей.",
                3,
                Array.Empty<FormulaParamRef>(),
                _ => "При decoyEffect=0.7, flareResist=0.25 и count=2 → эффект ((0.75)×0.7)² = 0.276 (27.6% от базовой точности).",
                new EditableFormulaSpec(
                    "CalculateCountermeasuresEffect",
                    new[] { "decoyEffect", "flareResist", "count" },
                    "pow((1 - flareResist) * decoyEffect, count)",
                    "decoyEffect=0.7; flareResist=0.25; count=2")),

            new FormulaEntry(
                CatAccuracy,
                "9. Отклонение при промахе ракеты и радиовзрыватель",
                "MissileGuidanceSystem",
                "MissDist = Clamp(Dist × MAX_MISSILE_MISS_DISTANCE_PROPORTION, MINIMAL_MISSILE_MISS_DISTANCE, MAX_MISSILE_MISS_DISTANCE_CAP)\n" +
                "           + MISSILE_MISS_ADDITIONAL_CLEARENCE\n" +
                "RadioFuseTrigger = RadioFuseDistance × Random[RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN .. MAX]",
                "Dist — дистанция промаха/оставшийся путь; MissDist — радиус увода сорванной ракеты мимо цели.",
                "Когда ракета теряет захват, включается режим DeadMissile (666): она летит не менее MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME и меняет вектор каждые [REROLL_TIME_MIN..MAX].",
                0,
                Refs("MINIMAL_MISSILE_MISS_DISTANCE", "MAX_MISSILE_MISS_DISTANCE_PROPORTION", "MAX_MISSILE_MISS_DISTANCE_CAP", "MISSILE_MISS_ADDITIONAL_CLEARENCE", "RADIUFUSE_MISS_DISTANCE_PROPORTION_MIN", "RADIUFUSE_MISS_DISTANCE_PROPORTION_MAX", "MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME"),
                c =>
                {
                    float d = 1500f;
                    float miss = Math.Clamp(d * c.MAX_MISSILE_MISS_DISTANCE_PROPORTION, c.MINIMAL_MISSILE_MISS_DISTANCE, c.MAX_MISSILE_MISS_DISTANCE_CAP) + c.MISSILE_MISS_ADDITIONAL_CLEARENCE;
                    return $"При срыве на дистанции {d} м точка промаха уйдёт на {Fmt(miss)} м мимо цели (DeadMissile мин. время: {Fmt(c.MISSILE_DEAD_TRAJECTORY_MINIMAL_TIME)} с).";
                }),

            new FormulaEntry(
                CatAccuracy,
                "10. Упреждение, лофтинг, выгорание ракеты и Overkill",
                "RocketEngineSystem + MissileGuidanceSystem + ShootSystem",
                "Упреждение: плавно от START_LEAD_MISSILE_SPEED_PROPORTION до FULL_LEAD_MISSILE_SPEED_PROPORTION × MaxSpeed\n" +
                "После BurnTime: замедление MISSILE_DECELERATION_PROPORTION; гибель при Speed < MaxSpeed × MISSILE_DEATH_SPEED_PROPORTION\n" +
                "Лофт: прямой участок LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION; LoS-проверка с MISSILE_LOFTING_LOS_CHECK_START_TRAJECTORY_PROPORTION",
                "Управляет энергетикой ракеты, переключением на ПРЛ (MISSILE_SWITCH_RULE) и запретом лишнего залпа (PREVENT_GUIDED_OVERKILL).",
                "Если PREVENT_GUIDED_OVERKILL включён, союзные ПТРК/ЗРК ждут освобождения цели вместо залпа с запасом урона сверх HP.",
                0,
                Refs("START_LEAD_MISSILE_SPEED_PROPORTION", "FULL_LEAD_MISSILE_SPEED_PROPORTION", "MISSILE_DECELERATION_PROPORTION", "MISSILE_DEATH_SPEED_PROPORTION", "LOFT_GOING_STRAIGHT_DISTANCE_PROPORTION", "MISSILE_SWITCH_RULE", "PREVENT_GUIDED_OVERKILL"),
                c => $"Упреждение включается на {Fmt(c.START_LEAD_MISSILE_SPEED_PROPORTION * 100f)}%–{Fmt(c.FULL_LEAD_MISSILE_SPEED_PROPORTION * 100f)}% MaxSpeed; гибель ракеты ниже {Fmt(c.MISSILE_DEATH_SPEED_PROPORTION * 100f)}% MaxSpeed; Overkill={(c.CombatFormulas.PREVENT_GUIDED_OVERKILL ? "запрещён" : "разрешён")}."),

            // =========================================================================
            // 3. ТРАЕКТОРИИ И БАЛЛИСТИКА
            // =========================================================================
            new FormulaEntry(
                CatBallistics,
                "11. Баллистика прямого выстрела и время полёта",
                "BallisticsCalculationsHelper.CalculateBallisticsAngle (RVA 0x81C5F0)",
                "g_eff = G × GravityMult\n" +
                "D = v⁴ − g_eff × (g_eff × d² + 2 × v² × Δy)\n" +
                "tan(θ) = (v² − √D) / (g_eff × d),   t_полёта = d / (v × cos(θ))",
                "v — MuzzleVelocity (м/с); d — горизонтальная дистанция (м); Δy — превышение цели (м); G — глобальное ускорение свободного падения.",
                "Используется DirectShot (10) и для упреждения по движущимся целям.",
                0,
                Refs("G"),
                c =>
                {
                    double g = Math.Max(0.01, c.G);
                    double v = 1000.0, d = 2000.0;
                    double disc = Math.Pow(v, 4.0) - g * (g * d * d);
                    if (disc < 0) return $"При G={Fmt(g)} и v={v} м/с дальность {d} м недостижима (дискриминант < 0).";
                    double tanT = (v * v - Math.Sqrt(disc)) / (g * d);
                    double angleDeg = Math.Atan(tanT) * (180.0 / Math.PI);
                    double tFlight = d / (v * Math.Cos(Math.Atan(tanT)));
                    return $"При G={Fmt(g)}, v={v} м/с на d={d} м: угол возвышения {Fmt(angleDeg)}°, время полёта {Fmt(tFlight)} с.";
                }),

            new FormulaEntry(
                CatBallistics,
                "12. Дуги артиллерии (20), РСЗО (40) и миномётов (30)",
                "ArtilleryTrajectorySystem + BattleSystemSettings",
                "Артиллерия / РСЗО (20, 40): интерполяция апогея от [MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE → MIN_ARTILLERY_SHOT_APOGEE]\n" +
                "  до [MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE → MAX_ARTILLERY_SHOT_APOGEE] (пик на MAX_ARTILLERY_SHOT_APOGEE_DISTANCE)\n" +
                "Миномёты (30): от [MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE → MIN_MORTAR_SHOT_APOGEE] до [MAX_MORTAR_*]",
                "Высота апогея управляет крутизной навесной дуги (прострел за домами и время подлёта под ПРО).",
                "Ошибку рассеивания снарядов дополнительно задаёт кривая ARTILLERY_DISPERSION_CDF (редактируется на вкладке Траектории).",
                0,
                Refs("MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE", "MAX_ARTILLERY_SHOT_APOGEE", "MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE", "MIN_ARTILLERY_SHOT_APOGEE", "MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE", "MAX_MORTAR_SHOT_APOGEE", "MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE", "MIN_MORTAR_SHOT_APOGEE"),
                c => $"Арт-апогей: {Fmt(c.MIN_ARTILLERY_SHOT_APOGEE)} м ({Fmt(c.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE)} м) → {Fmt(c.MAX_ARTILLERY_SHOT_APOGEE)} м ({Fmt(c.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE)} м); миномёт: {Fmt(c.MIN_MORTAR_SHOT_APOGEE)}→{Fmt(c.MAX_MORTAR_SHOT_APOGEE)} м."),

            new FormulaEntry(
                CatBallistics,
                "13. Крылатые ракеты (200) — PID огибания рельефа",
                "CruiseMissileSystem",
                "Ошибка высоты e(t) = TargetTerrainHeight + CRUISE_MISSILE_TARGET_HEIGHT − CurrentY\n" +
                "Управляющее воздействие: u(t) = P × e(t) + I × ∫e(τ)dτ + D × de/dt\n" +
                "Финальное пикирование под углом CRUISE_MISSILE_DIVE_ANGLE°",
                "CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT сканирует рельеф вперёд в CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION шагах по кривой высот.",
                "Увеличение P делает подъём перед холмом резче; увеличение D гасит раскачку (дельфинирование).",
                0,
                new[] { P("CRUISE_MISSILE_TARGET_HEIGHT"), P("CRUISE_MISSILE_DIVE_ANGLE"), P("PLANE_CRUISE_MISSILE_LAUNCH_DIVE_ANGLE"), P("CRUISE_MISSILE_HEIGHT_FORESEEING_COEFFICIENT"), P("CRUISE_MISSILE_HEIGHTS_COEFICIENTS_RESOLUTION"), PidRef() },
                c => $"Высота полёта {Fmt(c.CRUISE_MISSILE_TARGET_HEIGHT)} м, PID=[{Fmt(c.CRUISE_MISSILE_PID[0])}, {Fmt(c.CRUISE_MISSILE_PID[1])}, {Fmt(c.CRUISE_MISSILE_PID[2])}], пикирование {Fmt(c.CRUISE_MISSILE_DIVE_ANGLE)}°."),

            new FormulaEntry(
                CatBallistics,
                "14. Баллистические ракеты (300) и окно перехвата ПРО",
                "BallisticMissileSystem + InterceptSystem",
                "Пиковая высота траектории = BALLISTIC_MISSILES_APOAPSIS\n" +
                "Окно перехвата ПВО/ПРО = [INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION .. INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION]",
                "Определяет максимальную высоту подъёма в верхние слои и долю траектории, на которой ЗРК разрешён пуск перехватчика.",
                "Слишком узкое окно или низкий потолок меняют окно реакции Patriot / С-300.",
                0,
                Refs("BALLISTIC_MISSILES_APOAPSIS", "INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION", "INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION"),
                c => $"Апогей: {Fmt(c.BALLISTIC_MISSILES_APOAPSIS)} м; окно перехвата: от {Fmt(c.INTERCEPTION_MINIMAL_TRAJECTORY_PROPORTION * 100f)}% до {Fmt(c.INTERCEPTION_MAXIMAL_TRAJECTORY_PROPROTION * 100f)}% траектории."),

            new FormulaEntry(
                CatBallistics,
                "15. Бомбы (400 / 410) и лазерное планирование (610)",
                "BombSystem + LaserGuidedTrajectory",
                "LowDrag (400): g_bomb = G × BOMBS_GRAVITY_MULTIPLYER\n" +
                "HighDrag (410): g_bomb = G × HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER,  торможение HIGH_DRAG_BOMBS_DECELERATION_PROPORTION\n" +
                "LaserFreeFall (610): макс. угол доворота/планирования LASER_MAX_GLIDING_ANGLE°",
                "Позволяет раздельно настраивать баллистику свободных КАБ и штурмовых тормозных бомб.",
                "Флаг DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN отключает лазерную коррекцию при ковровом бомбометании.",
                0,
                Refs("BOMBS_GRAVITY_MULTIPLYER", "HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER", "HIGH_DRAG_BOMBS_DECELERATION_PROPORTION", "LASER_MAX_GLIDING_ANGLE", "DISABLE_LASER_GUIDANCE_ON_BOMBING_RUN"),
                c => $"g_low={Fmt(c.G * c.BOMBS_GRAVITY_MULTIPLYER)} м/с², g_high={Fmt(c.G * c.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER)} м/с², макс. планирование {Fmt(c.LASER_MAX_GLIDING_ANGLE)}°."),

            // =========================================================================
            // 4. ВИДИМОСТЬ, СТЕЛС И ЛЕС (FoW)
            // =========================================================================
            new FormulaEntry(
                CatFow,
                "16. Дальность обнаружения цели (Оптика / Стелс)",
                "FogOfWarUnit.CalculateVisionRangeForTarget (RVA 0x69FE20)",
                "EffectiveStealth = Clamp(BaseStealth × TerrainStealthMult − WeaponFlash − SpottedPenalty, SneakMinAntivisible, MaxAntiVisible)\n" +
                "VisionRange = max(MinimumDetectionDistance, CheckerOptics / EffectiveStealth)",
                "vanilla (расчётная дальность игры), minDist (из MinimumDetectionDistance).",
                "Постфикс позволяет отмасштабировать или ограничить итоговую дальность обнаружения (например clamp(vanilla * 1.2, minDist, 6000)).",
                3,
                Refs("MinimumDetectionDistance", "MaxAntiVisible", "SneakMinAntivisible", "SpottedPenalty", "SpottedPenaltyBuildings"),
                c =>
                {
                    float optics = 2000f, baseStealth = 1.75f;
                    float eff = Math.Clamp(baseStealth, c.FogOfWar.SneakMinAntivisible, c.FogOfWar.MaxAntiVisible);
                    float dist = Math.Max(c.FogOfWar.MinimumDetectionDistance, eff > 1e-4f ? optics / eff : c.FogOfWar.MinimumDetectionDistance);
                    float effFired = Math.Clamp(baseStealth - c.FogOfWar.SpottedPenalty, c.FogOfWar.SneakMinAntivisible, c.FogOfWar.MaxAntiVisible);
                    float distFired = Math.Max(c.FogOfWar.MinimumDetectionDistance, effFired > 1e-4f ? optics / effFired : c.FogOfWar.MinimumDetectionDistance);
                    return $"Оптика {optics}, Стелс {baseStealth}: спокойная цель видна с {Fmt(dist)} м; со штрафом засвета ({Fmt(c.FogOfWar.SpottedPenalty)}) — с {Fmt(distFired)} м.";
                },
                new EditableFormulaSpec(
                    "CalculateVisionRangeForTarget",
                    new[] { "vanilla", "minDist" },
                    "max(minDist, vanilla)",
                    "vanilla=1142; minDist=45",
                    c => new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
                    {
                        ["minDist"] = c.FogOfWar.MinimumDetectionDistance
                    })),

            new FormulaEntry(
                CatFow,
                "17. Демаскировка выстрелом, просвет леса и лазер",
                "FogOfWarConfig + FogOfWarFilter",
                "WeaponFlash уменьшается на FlashReduction в секунду (макс. MaxFlashValue)\n" +
                "Прострел / видимость через глубину леса ≤ MaxShootableForestDistance (м)\n" +
                "Лазерное целеуказание через чужой лес ≤ LaserForestMaxRange,  через свой лес ≤ LaserOwnForestRange",
                "FlashReduction — скорость остывания вспышки выстрела; MaxShootableForestDistance — глубина лесного барьера (ваниль 45 м).",
                "Увеличение MaxShootableForestDistance позволяет стрелять и светить глубже сквозь лесные массивы.",
                3,
                Refs("MaxShootableForestDistance", "LaserForestMaxRange", "LaserOwnForestRange", "FlashReduction", "MaxFlashValue"),
                c => $"Порог леса: {Fmt(c.FogOfWar.MaxShootableForestDistance)} м, лазер: {Fmt(c.FogOfWar.LaserForestMaxRange)}/{Fmt(c.FogOfWar.LaserOwnForestRange)} м, вспышка затухает по {Fmt(c.FogOfWar.FlashReduction)}/с (потолок {Fmt(c.FogOfWar.MaxFlashValue)})."),

            // =========================================================================
            // 5. СТРЕСС, ПАНИКА И КРИТЫ
            // =========================================================================
            new FormulaEntry(
                CatStress,
                "18. Урон по стрессу от попадания",
                "BattleSystemHelpers.CalculateStressDamage (RVA 0x7D3E30)",
                "TotalStressDamage = (healthDamage / targetMaxHp) × maxStress + stressDamage",
                "maxStress, healthDamage, stressDamage, targetMaxHp.",
                "Учитывается как прямой вклад от снятых HP (доля снятого здоровья × MaxStress), так и базовый подавляющий импульс боеприпаса.",
                3,
                Refs("StressDamageModThreshold", "OnTransportDeathCargoForcedStressPercentage", "OnTransportUnloadCargoForcedStressPercentage"),
                c =>
                {
                    float maxStress = 100f, dmg = 50f, maxHp = 500f, flat = 20f;
                    float total = (dmg / maxHp) * maxStress + flat;
                    return $"При {dmg}/{maxHp} HP урона и FlatStress={flat} (MaxStress={maxStress}) цель получит {Fmt(total)} стресса (порог модификатора: {Fmt(c.Buffs.StressDamageModThreshold)}).";
                },
                new EditableFormulaSpec(
                    "CalculateStressDamage",
                    new[] { "maxStress", "healthDamage", "stressDamage", "targetMaxHp" },
                    "(healthDamage / max(0.001, targetMaxHp)) * maxStress + stressDamage",
                    "maxStress=100; healthDamage=50; stressDamage=20; targetMaxHp=500")),

            new FormulaEntry(
                CatStress,
                "19. Пороги Шок / Паника и восстановление морали",
                "StressSystem.SetStressLevel + StressRecovery",
                "Техника:  Шок ≥ MaxStress × ShockedLevelMultiplier,   Паника ≥ MaxStress × PanickedLevelMultiplier\n" +
                "Пехота:   Шок ≥ MaxStress × ShockedLevelMultiplierInfantry,  Паника ≥ MaxStress × PanickedLevelMultiplierInfantry\n" +
                "Восстановление: BaseRecovery × StressRecoveryMultiplier",
                "Определяет, на каком проценте шкалы стресса юнит получает статус Шок или Паника и как быстро приходит в себя.",
                "Изменяется раздельно для техники и пехоты.",
                3,
                Refs("ShockedLevelMultiplier", "PanickedLevelMultiplier", "ShockedLevelMultiplierInfantry", "PanickedLevelMultiplierInfantry", "StressRecoveryMultiplier"),
                c => $"Техника: Шок {Fmt(c.Buffs.ShockedLevelMultiplier * 100f)}% / Паника {Fmt(c.Buffs.PanickedLevelMultiplier * 100f)}% | Пехота: {Fmt(c.Buffs.ShockedLevelMultiplierInfantry * 100f)}% / {Fmt(c.Buffs.PanickedLevelMultiplierInfantry * 100f)}% | Восст. ×{Fmt(c.Buffs.StressRecoveryMultiplier)}."),

            new FormulaEntry(
                CatStress,
                "20. Критические повреждения (Minor / Major криты)",
                "BuffConfig",
                "Шанс крита = CriticalBaseProbability;  красные криты срабатывают при ≥ RedCritsActivationThreshold\n" +
                "Итоговый штраф = Stat × MinorMultiplier  (или Stat × MajorMultiplier при тяжёлом крите)",
                "Затрагивает время прицеливания, оптику, скорость/поворот, разброс и скорость перезарядки.",
                "Позволяет тонко балансировать, насколько сильно поломки узлов выводят технику из строя.",
                3,
                Refs("CriticalBaseProbability", "RedCritsActivationThreshold", "MinorAimTimeMultiplier", "MajorAimTimeMultiplier", "MinorOpticsMultiplier", "MajorOpticsMultiplier", "MinorMobilityMultiplier", "MinorMobilityMultiplierRotation", "MinorDispersionMultiplier", "MajorDispersionMultiplier", "MinorLoadingMultiplier", "MajorLoadingMultiplier"),
                c => $"Баз. шанс крита {Fmt(c.Buffs.CriticalBaseProbability * 100f)}%, порог красных: {c.Buffs.RedCritsActivationThreshold}; Оптика Minor/Major: ×{Fmt(c.Buffs.MinorOpticsMultiplier)} / ×{Fmt(c.Buffs.MajorOpticsMultiplier)}; Перезарядка: ×{Fmt(c.Buffs.MinorLoadingMultiplier)} / ×{Fmt(c.Buffs.MajorLoadingMultiplier)}."),

            // =========================================================================
            // 6. САПЛАЙ, ЭКОНОМИКА И РЕСПАВН
            // =========================================================================
            new FormulaEntry(
                CatEconomy,
                "21. Цена саплая за тонну и курс обмена",
                "SupplyConfig + SupplySystem",
                "ЦенаЗаТонну = SupplyValueBought × (1000 / SupplyExchangeRate)\n" +
                "КилограммЗаОчко = SupplyExchangeRate / SupplyValueBought",
                "SupplyValueBought — цена пакета снабжения (очков); SupplyExchangeRate — масса пакета (кг, в ванили 1000 кг = 1 т).",
                "Определяет, сколько очков стоит 1 тонна припасов на складах и в машинах снабжения.",
                2,
                Refs("SupplyValueBought", "SupplyExchangeRate"),
                c =>
                {
                    int bought = c.Supply.SupplyValueBought;
                    int rate = c.Supply.SupplyExchangeRate;
                    if (bought <= 0 || rate <= 0) return "Некорректные значения SupplyValueBought / SupplyExchangeRate (≤ 0).";
                    double perTon = bought * (1000.0 / rate);
                    double kgPerPt = (double)rate / bought;
                    return $"Сейчас: {Fmt(perTon)} очков за тонну ({bought} очков за {rate} кг; 1 очко = {Fmt(kgPerPt)} кг).";
                }),

            new FormulaEntry(
                CatEconomy,
                "22. Расход саплая на БК, ремонт, лечение и способности",
                "SupplySystem + SupplyConfig",
                "ЦенаБК = BaseAmmoSupply × AmmoCostMultiplier\n" +
                "Ремонт: RepairRate HP/тик по цене RepairCost саплая;  Лечение: HealingRate HP/тик по цене HealingCost\n" +
                "Способности (дым/ракеты и т.п.): AbilityResupplyRate × (AbilityMultiplierHeal / Repair / Rearm)",
                "Все операции происходят в пределах ResupplyRadius от активного склада.",
                "Увеличение AmmoCostMultiplier делает стрельбу дорогой по логистике (в ванили ×4).",
                2,
                Refs("ResupplyRadius", "AmmoCostMultiplier", "RepairRate", "RepairCost", "HealingRate", "HealingCost", "AbilityResupplyRate"),
                c => $"Радиус {Fmt(c.Supply.ResupplyRadius)} м, БК ×{Fmt(c.Supply.AmmoCostMultiplier)}, Ремонт {Fmt(c.Supply.RepairRate)}/тик (цена {Fmt(c.Supply.RepairCost)}), Лечение {Fmt(c.Supply.HealingRate)}/тик (цена {Fmt(c.Supply.HealingCost)})."),

            new FormulaEntry(
                CatEconomy,
                "23. Стартовый капитал, доход в минуту и Upkeep",
                "GameConfig",
                "Чистый доход/мин = DefaultIncomePerMin − (GroundUnitsValue × UpkeepMultiplier) − (PlanesValue × PlanesUpkeepMultiplier)",
                "DefaultPlayerMoney — стартовые очки; UpkeepMultiplier — налог за выставленную на карту армию; DeadUnitsValueMultiplier — влияние потерь.",
                "Определяет темп экономики матча и штраф за спам большим количеством техники.",
                2,
                Refs("DefaultPlayerMoney", "DefaultIncomePerMin", "UpkeepMultiplier", "PlanesUpkeepMultiplier", "DeadUnitsValueMultiplier"),
                c => $"Старт: {Fmt(c.GameConfig.DefaultPlayerMoney)}, Доход: {Fmt(c.GameConfig.DefaultIncomePerMin)}/мин, Upkeep назем./верт.: ×{Fmt(c.GameConfig.UpkeepMultiplier)}, Upkeep авиа: ×{Fmt(c.GameConfig.PlanesUpkeepMultiplier)}."),

            new FormulaEntry(
                CatEconomy,
                "24. Возврат юнитов (Refund) и таймер респавна",
                "RefundSystem.RefundUnit + GetPurchaseDelay",
                "Возврат очков = Clamp(BaseRefund × RefundMultiplier − LostHP_Cost × HealthCostMultiplier, MinimumRefundPercent%, MaximumRefundPercent%)\n" +
                "Кулдаун возврата = max(RepurchaseDelayFloor, (UnitCost − Refund) × RepurchaseDelayMultiplier + AmmoTime)\n" +
                "Кулдаун после гибели = max(ResurrectDelayFloor, UnitCost × ResurrectDelayMultiplier)\n" +
                "Самолёты: PlanesRefundFloor + Cost×(1−HP%)×PlanesRefundHPMultiplier + Ammo(K, P); гибель × PlanesDeathRefundMultiplier + PlanesDeathPenalty",
                "Управляет окном отката эвакуированных и уничтоженных отрядов/самолётов в слотах деки.",
                "Для самолётов можно отдельно отключить гибельный множитель через PlanesDeathIsMultiplierOfRefund.",
                2,
                Refs("RefundMultiplier", "MinimumRefundPercent", "MaximumRefundPercent", "RepurchaseDelayFloor", "RepurchaseDelayMultiplier", "ResurrectDelayFloor", "ResurrectDelayMultiplier", "PlanesRefundFloor", "PlanesDeathRefundMultiplier", "PlanesDeathPenalty"),
                c =>
                {
                    float unitCost = 200f;
                    float deadCd = Math.Max(c.GameConfig.ResurrectDelayFloor, unitCost * c.GameConfig.ResurrectDelayMultiplier);
                    float fullRefundCd = c.GameConfig.RepurchaseDelayFloor;
                    return $"Для юнита ценой {unitCost}: возврат фулл HP → мин. кулдаун {Fmt(fullRefundCd)} с; после гибели → {Fmt(deadCd)} с (пол от авиа-рефанда: {Fmt(c.GameConfig.PlanesRefundFloor)} с, множитель гибели авиа ×{Fmt(c.GameConfig.PlanesDeathRefundMultiplier)}).";
                }),

            // =========================================================================
            // 7. АВИАЦИЯ (БОМБИНГ / ШТУРМ / ПРЕСИЖЕН)
            // =========================================================================
            new FormulaEntry(
                CatPlanes,
                "25. Бомбинг ран (Bombing Run) — сброс и дистанция захода",
                "AirstrikeCommandSystem + AircraftWeaponSystem",
                "Дистанция начала сброса = Speed × BombingStartTimeOffset  (HighDrag: BombingStartTimeOffsetHighDrag)\n" +
                "Смещение точки сброса = BombDropOffset + BombRadius × BombDropOffsetAmmoAoeMult",
                "BombDropOffset (<0 означает сброс чуть раньше, >0 — с перелётом); HighDrag использует параметры *HighDrag.",
                "EnableStratBomberCircling разрешает стратегическим бомбардировщикам кружение для повторного захода.",
                1,
                Refs("BombingStartTimeOffset", "BombingStartTimeOffsetHighDrag", "BombDropOffset", "BombDropOffsetHighDrag", "BombDropOffsetAmmoAoeMult", "EnableStratBomberCircling"),
                c => $"Упреждение сброса {Fmt(c.Planes.BombingStartTimeOffset)} с (HighDrag {Fmt(c.Planes.BombingStartTimeOffsetHighDrag)} с), смещение {Fmt(c.Planes.BombDropOffset)} м (+{Fmt(c.Planes.BombDropOffsetAmmoAoeMult)}×AoE)."),

            new FormulaEntry(
                CatPlanes,
                "26. Штурмовой заход (Strafe) и Пресижен страйк",
                "AircraftWeaponSystem.StrafeRun + PrecisionStrikeCommand",
                "Strafe коридор: [StrafeMinLength .. StrafeMaxLength] м,  поиск целей в радиусе StrafeSearchRadius м\n" +
                "  начало стрельбы за StrafeStartTimeOffset с,  смещение огня StrafeWeaponPointOffset м\n" +
                "Precision Strike: мин. допустимый угол PrecisionMinAllowedAngle°, отход после сброса +PrecisionFlyAwayExtraDistance м",
                "Контролирует геометрию штурмовки пушками/НАР (Strafe) и высокоточных ударов КАБ/ракетами (Precision).",
                "Снижение StrafeMinLength упрощает короткие штурмовки; уменьшение PrecisionMinAllowedAngle позволяет кидать КАБ круче по курсу.",
                1,
                Refs("StrafeMinLength", "StrafeMaxLength", "StrafeSearchRadius", "StrafeStartTimeOffset", "StrafeWeaponPointOffset", "PrecisionMinAllowedAngle", "PrecisionFlyAwayExtraDistance"),
                c => $"Штурм коридор {Fmt(c.Planes.StrafeMinLength)}–{Fmt(c.Planes.StrafeMaxLength)} м (поиск {Fmt(c.Planes.StrafeSearchRadius)} м); Пресижен угол ≥ {Fmt(c.Planes.PrecisionMinAllowedAngle)}°, отлёт +{c.Planes.PrecisionFlyAwayExtraDistance} м."),

            new FormulaEntry(
                CatPlanes,
                "27. Радиус разворота, эшелоны высот и топливо самолётов",
                "AircraftHelper.GetRotationRadius (RVA 0x3A6C70) + PlanesConfig",
                "R_разворота = speed × (1 + sin(turnRate × 0.0174532925)) / sin(turnRate × 0.0174532925)\n" +
                "Эшелоны: LowAltitude ↔ HighAltitude;  красная зона топлива ≤ FuelRedZoneBaseValue",
                "turnRate (угол виража в градусах/с), speed (скорость полёта м/с).",
                "Редактирование формулы напрямую меняет радиусы разворота всех самолётов на заходе/уходе.",
                1,
                Refs("HighAltitude", "LowAltitude", "FuelRedZoneBaseValue", "FuelOrangeZoneSizeRatio", "FuelOutChance", "DeathChance", "NextPointStepMultiplier", "DecreaseSpeedAngle"),
                c =>
                {
                    double spd = 300.0, turnDeg = 35.0;
                    double s = Math.Sin(turnDeg * Math.PI / 180.0);
                    double rad = s > 1e-5 ? spd * (1.0 + s) / s : 0.0;
                    return $"При скорости {spd} м/с и TurnRate={turnDeg}° радиус разворота R≈{Fmt(rad)} м; высоты: Low={Fmt(c.Planes.LowAltitude)} м / High={Fmt(c.Planes.HighAltitude)} м; топливо Red≤{c.Planes.FuelRedZoneBaseValue}.";
                },
                new EditableFormulaSpec(
                    "GetRotationRadius",
                    new[] { "turnRate", "speed" },
                    "speed * (1 + sin(turnRate * 0.0174532925)) / max(0.0001, sin(turnRate * 0.0174532925))",
                    "turnRate=35; speed=300")),

            // =========================================================================
            // 8. ПЕХОТА, СКОРОСТИ И ТРАНСПОРТ
            // =========================================================================
            new FormulaEntry(
                CatInfantry,
                "28. Смертность десанта при гибели транспорта (БМП / Вертолёт / Самолёт)",
                "UnitUnloadingSystem.UpdateDeadContainerSquad (RVA 0x3245F0)",
                "В глубокой воде (Terrain == 5): Шанс гибели каждого бойца = 100%\n" +
                "На суше / воздухе: Шанс(%) = Clamp(Floor + Overkill × Multiplier, 0%, 100%) — бросок Random(0..100) на каждого бойца\n" +
                "Стресс выжившим = OnTransportDeathCargoForcedStressPercentage%",
                "Назем. транспорт: KillFloor / KillMultiplier; Вертолёт Low/High: HLFloor/Mult и HHFloor/Mult; Самолёт: AirFloor/Mult.",
                "Урон отряду равен DeadSoldiersCount × SingleSoldierHealth. При аварийной высадке применяется OnTransportUnloadCargoForcedStressPercentage.",
                3,
                Refs("OnTransportDeathCargoKillFloor", "OnTransportDeathCargoKillMultiplier", "OnTransportDeathCargoKillHLFloor", "OnTransportDeathCargoKillHLMultiplier", "OnTransportDeathCargoKillHHFloor", "OnTransportDeathCargoKillHHMultiplier", "OnTransportDeathCargoKillAirFloor", "OnTransportDeathCargoKillAirMultiplier", "OnTransportDeathCargoForcedStressPercentage"),
                c =>
                {
                    float ovk = 100f;
                    float pGround = Math.Clamp(c.GameConfig.OnTransportDeathCargoKillFloor + ovk * c.GameConfig.OnTransportDeathCargoKillMultiplier, 0f, 100f);
                    float pHeliLow = Math.Clamp(c.GameConfig.OnTransportDeathCargoKillHLFloor + ovk * c.GameConfig.OnTransportDeathCargoKillHLMultiplier, 0f, 100f);
                    return $"При Overkill=+{ovk} шанс гибели каждого десантника: в БМП/БТР {Fmt(pGround)}%, в низколетящем вертолёте {Fmt(pHeliLow)}% (стресс выжившим {c.GameConfig.OnTransportDeathCargoForcedStressPercentage}%).";
                }),

            new FormulaEntry(
                CatInfantry,
                "29. Скорости пехоты, штраф леса и посадка/высадка",
                "InfantryConfig + GameConfig",
                "Скорость в лесу (техника) = Speed × GlobalForestSpeedMultiplier\n" +
                "Скорость в лесу (пехота) = Speed × InfantryForestSpeedMultiplier\n" +
                "Высадка в здание = Sprint × HouseUnloadSprintMultiplier (задержка HouseUnloadDelay с)",
                "RunSpeed, SprintSpeed, KneelRunSpeed, ProneRunSpeed, ProneSprintSpeed, дистанция перехода на спринт и дистанции посадки в транспорт.",
                "Позволяет гибко настроить темп маневрирования пехоты и скорость погрузки отрядов.",
                3,
                Refs("Infantry.RunSpeed", "Infantry.SprintSpeed", "GameConfig.SprintSpeed", "KneelRunSpeed", "ProneRunSpeed", "ProneSprintSpeed", "GlobalForestSpeedMultiplier", "InfantryForestSpeedMultiplier", "HouseUnloadDelay", "HouseUnloadSprintMultiplier", "TransportLoadDistance"),
                c => $"Пехота бег/спринт: {Fmt(c.Infantry.RunSpeed)} / {Fmt(c.Infantry.SprintSpeed)} м/с; в лесу: пехота ×{Fmt(c.GameConfig.InfantryForestSpeedMultiplier)} ({Fmt(c.Infantry.RunSpeed * c.GameConfig.InfantryForestSpeedMultiplier)} м/с), техника ×{Fmt(c.GameConfig.GlobalForestSpeedMultiplier)}.")
        };

        public static readonly IReadOnlyList<FormulaEntry> EditableFormulas = Formulas.Where(f => f.EditableSpec != null).ToArray();
    }
}
