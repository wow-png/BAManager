using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Windows.Forms;
using TrajectoryEditorShared;

namespace TrajectoryEditor
{
    public sealed class AmmoWeaponCatalogItem
    {
        public int AmmoId { get; set; }
        public string AmmoName { get; set; } = string.Empty;
        public string HudName { get; set; } = string.Empty;
        public int VanillaTrajectoryType { get; set; }
        public List<int> WeaponIds { get; set; } = new List<int>();
        public string WeaponsText { get; set; } = "—";
    }

    public sealed class CustomTrajectoryPreviewCanvas : Control
    {
        private CustomTrajectoryDto _traj;

        public CustomTrajectoryPreviewCanvas()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.FromArgb(20, 24, 31);
        }

        public void SetTrajectory(CustomTrajectoryDto traj)
        {
            _traj = traj;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle r = ClientRectangle;
            if (r.Width < 120 || r.Height < 90)
                return;

            using var bg = new SolidBrush(Color.FromArgb(20, 24, 31));
            using var box = new SolidBrush(Color.FromArgb(28, 33, 42));
            using var border = new Pen(Color.FromArgb(55, 64, 80));
            using var gridPen = new Pen(Color.FromArgb(40, 48, 60)) { DashStyle = DashStyle.Dot };
            using var titleFont = new Font("Segoe UI", 9f, FontStyle.Bold);
            using var smallFont = new Font("Segoe UI", 7.8f, FontStyle.Regular);
            using var textBrush = new SolidBrush(Color.FromArgb(220, 228, 238));
            using var mutedBrush = new SolidBrush(Color.FromArgb(145, 158, 175));

            g.FillRectangle(bg, r);
            Rectangle area = new Rectangle(8, 26, r.Width - 16, r.Height - 34);
            g.FillRectangle(box, area);
            g.DrawRectangle(border, area);

            if (_traj == null)
            {
                g.DrawString("2D-профиль новой траектории", titleFont, textBrush, 10f, 6f);
                g.DrawString("Создайте или выберите траекторию слева.", smallFont, mutedBrush, area.Left + 14f, area.Top + 20f);
                return;
            }

            g.DrawString($"2D-профиль: {_traj.Name} ({TrajectoryCatalog.FormatTrajectoryShort(_traj.BaseTrajectoryType)})", titleFont, textBrush, 10f, 5f);

            int padL = 42, padR = 14, padT = 18, padB = 22;
            int plotW = Math.Max(40, area.Width - padL - padR);
            int plotH = Math.Max(40, area.Height - padT - padB);
            int x0 = area.Left + padL;
            int y0 = area.Bottom - padB;

            if (_traj.UseCustomHeightFormula || _traj.BaseTrajectoryType is 20 or 30 or 40 or 300)
            {
                DrawArcPreview(g, area, x0, y0, plotW, plotH, gridPen, smallFont, mutedBrush);
            }
            else if (_traj.BaseTrajectoryType is 10 or 400 or 410 or 610)
            {
                DrawBallisticPreview(g, area, x0, y0, plotW, plotH, gridPen, smallFont, mutedBrush);
            }
            else
            {
                DrawMissilePreview(g, area, x0, y0, plotW, plotH, gridPen, smallFont, mutedBrush);
            }
        }

        private void DrawArcPreview(Graphics g, Rectangle area, int x0, int y0, int plotW, int plotH, Pen gridPen, Font font, Brush mutedBrush)
        {
            double[] dists = { Math.Max(200.0, _traj.MinRefDistance), (_traj.MinRefDistance + _traj.MaxRefDistance) * 0.5, Math.Max(400.0, _traj.MaxRefDistance) };
            bool compiledOk = FormulaExpressionEngine.TryCompile(_traj.HeightFormula ?? "apogee * 4 * t * (1 - t)", out CompiledExpression expr, out _);

            double maxY = 50.0;
            const int samples = 64;
            var allSeries = new List<(double[] ys, double dist, Color color, DashStyle dash)>();
            Color[] cols = { Color.FromArgb(120, 220, 255), Color.FromArgb(255, 195, 70), Color.FromArgb(110, 240, 145) };

            for (int di = 0; di < dists.Length; di++)
            {
                double d = dists[di];
                double apogee = InterpolateApogee(_traj, d);
                double[] ys = new double[samples + 1];
                for (int i = 0; i <= samples; i++)
                {
                    double t = i / (double)samples;
                    double h = compiledOk ? EvalHeight(expr, t, d, apogee) : apogee * 4.0 * t * (1.0 - t);
                    ys[i] = Math.Max(0.0, h);
                    if (ys[i] > maxY) maxY = ys[i];
                }
                allSeries.Add((ys, d, cols[di], DashStyle.Solid));
            }

            // Ванильная парабола сравнения для MaxRefDistance
            double refD = dists[2];
            double refApo = InterpolateApogee(_traj, refD);
            double[] vanYs = new double[samples + 1];
            for (int i = 0; i <= samples; i++)
            {
                double t = i / (double)samples;
                vanYs[i] = refApo * 4.0 * t * (1.0 - t);
                if (vanYs[i] > maxY) maxY = vanYs[i];
            }

            maxY *= 1.15;
            DrawAxes(g, x0, y0, plotW, plotH, maxY, area.Left, gridPen, font, mutedBrush);

            // Ванильный пунктир
            PlotPoints(g, x0, y0, plotW, plotH, maxY, refD, refD, vanYs, Color.FromArgb(135, 145, 160), 1.4f, DashStyle.Dash);

            foreach (var (ys, dist, color, dash) in allSeries)
                PlotPoints(g, x0, y0, plotW, plotH, maxY, dist, refD, ys, color, 2.1f, dash);

            g.DrawString("Пунктир: стандартная парабола  |  Сплошные: формула на мин / сред / макс дистанции", font, mutedBrush, x0, area.Bottom - 17f);
        }

        private void DrawBallisticPreview(Graphics g, Rectangle area, int x0, int y0, int plotW, int plotH, Pen gridPen, Font font, Brush mutedBrush)
        {
            double dist = 2000.0;
            double vVan = 850.0, gVan = 70.0;
            double vCur = vVan * Math.Max(0.05f, _traj.SpeedMultiplier);
            double gCur = gVan * Math.Max(0.01f, _traj.GravityMultiplier);

            double[] vanYs = ComputeBallisticCurve(dist, vVan, gVan, 50);
            double[] curYs = ComputeBallisticCurve(dist, vCur, gCur, 50);
            double maxY = Math.Max(25.0, Math.Max(vanYs.Max(), curYs.Max()) * 1.25);

            DrawAxes(g, x0, y0, plotW, plotH, maxY, area.Left, gridPen, font, mutedBrush);
            PlotPoints(g, x0, y0, plotW, plotH, maxY, dist, dist, vanYs, Color.FromArgb(145, 155, 170), 1.5f, DashStyle.Dash);
            PlotPoints(g, x0, y0, plotW, plotH, maxY, dist, dist, curYs, Color.FromArgb(255, 185, 65), 2.3f, DashStyle.Solid);

            g.DrawString($"Пунктир: ваниль 1.0x  |  Оранжевый: Speed×{_traj.SpeedMultiplier:0.##}, Gravity×{_traj.GravityMultiplier:0.##}", font, mutedBrush, x0, area.Bottom - 17f);
        }

        private void DrawMissilePreview(Graphics g, Rectangle area, int x0, int y0, int plotW, int plotH, Pen gridPen, Font font, Brush mutedBrush)
        {
            double dist = 2500.0;
            double loftH = _traj.LoftHeightOverride > 0 ? _traj.LoftHeightOverride : 120.0;
            double maxY = Math.Max(80.0, loftH * 1.35);

            const int steps = 50;
            double[] ys = new double[steps + 1];
            double[] vanYs = new double[steps + 1];
            for (int i = 0; i <= steps; i++)
            {
                double t = i / (double)steps;
                ys[i] = t < 0.25 ? loftH * (t / 0.25) : (t < 0.72 ? loftH : loftH * ((1.0 - t) / 0.28));
                vanYs[i] = 120.0 * 4.0 * t * (1.0 - t);
            }

            DrawAxes(g, x0, y0, plotW, plotH, maxY, area.Left, gridPen, font, mutedBrush);
            PlotPoints(g, x0, y0, plotW, plotH, maxY, dist, dist, vanYs, Color.FromArgb(145, 155, 170), 1.4f, DashStyle.Dash);
            PlotPoints(g, x0, y0, plotW, plotH, maxY, dist, dist, ys, Color.FromArgb(115, 230, 155), 2.3f, DashStyle.Solid);

            g.DrawString($"Профиль ракеты: Speed×{_traj.SpeedMultiplier:0.##}, Acc×{_traj.AccelerationMultiplier:0.##}, Rot×{_traj.RotationSpeedMultiplier:0.##}" + (_traj.ForceTopAttack ? ", TopAttack" : ""), font, mutedBrush, x0, area.Bottom - 17f);
        }

        private static double[] ComputeBallisticCurve(double dist, double v, double grav, int steps)
        {
            double[] ys = new double[steps + 1];
            double tFlight = dist / Math.Max(1.0, v);
            for (int i = 0; i <= steps; i++)
            {
                double u = i / (double)steps;
                double t = u * tFlight;
                double v0y = 0.5 * grav * tFlight;
                ys[i] = Math.Max(0.0, v0y * t - 0.5 * grav * t * t);
            }
            return ys;
        }

        private static void DrawAxes(Graphics g, int x0, int y0, int plotW, int plotH, double maxY, int areaLeft, Pen gridPen, Font font, Brush mutedBrush)
        {
            for (int i = 1; i <= 3; i++)
            {
                float py = y0 - plotH * (i / 4f);
                g.DrawLine(gridPen, x0, py, x0 + plotW, py);
                g.DrawString($"{(int)Math.Round(maxY * (i / 4.0))}м", font, mutedBrush, areaLeft + 3f, py - 7f);
            }
            g.DrawLine(Pens.Gray, x0, y0, x0 + plotW, y0);
            g.DrawLine(Pens.Gray, x0, y0 - plotH, x0, y0);
        }

        private static void PlotPoints(Graphics g, int x0, int y0, int plotW, int plotH, double maxY, double seriesDist, double maxDist, double[] ys, Color color, float thickness, DashStyle dash)
        {
            PointF[] pts = new PointF[ys.Length];
            double xFrac = maxDist > 1.0 ? Math.Clamp(seriesDist / maxDist, 0.05, 1.0) : 1.0;
            for (int i = 0; i < ys.Length; i++)
            {
                double u = i / (double)(ys.Length - 1);
                float px = x0 + (float)(u * xFrac * plotW);
                float py = y0 - (float)Math.Clamp(ys[i] / maxY, 0.0, 1.0) * plotH;
                pts[i] = new PointF(px, py);
            }
            using var pen = new Pen(color, thickness) { DashStyle = dash };
            g.DrawLines(pen, pts);
        }

        internal static double InterpolateApogee(CustomTrajectoryDto tr, double dist)
        {
            double denom = tr.MaxRefDistance - tr.MinRefDistance;
            if (Math.Abs(denom) < 1e-3)
                return tr.MaxApogee;
            double k = Math.Clamp((dist - tr.MinRefDistance) / denom, 0.0, 1.0);
            return tr.MinApogee + (tr.MaxApogee - tr.MinApogee) * k;
        }

        internal static double EvalHeight(CompiledExpression expr, double t, double dist, double apogee)
        {
            return expr.Evaluate(name =>
            {
                if (string.Equals(name, "t", StringComparison.OrdinalIgnoreCase)) return t;
                if (string.Equals(name, "d", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "dist", StringComparison.OrdinalIgnoreCase)) return dist;
                if (string.Equals(name, "apogee", StringComparison.OrdinalIgnoreCase)) return apogee;
                return 0.0;
            });
        }
    }

    public sealed class CustomTrajectoryControl : UserControl
    {
        public event Action ConfigChanged;
        public event Action SaveRequested;
        public event Action ReloadRequested;
        public event Action<WeaponTrajectoryAssignmentDto, CustomTrajectoryDto> SyncToAmmoJsonRequested;

        private static readonly NamedIntOption[] SupportedBaseTypes =
        {
            new NamedIntOption(10, "10 — DirectShot (прямая наводка)"),
            new NamedIntOption(20, "20 — Artillery (гаубичная дуга)"),
            new NamedIntOption(30, "30 — Mortar (миномётная дуга)"),
            new NamedIntOption(40, "40 — MLRS (РСЗО дуга)"),
            new NamedIntOption(100, "100 — PursuitMissile (ракета)"),
            new NamedIntOption(110, "110 — LeadPursuitMissile (ракета с упреждением)"),
            new NamedIntOption(120, "120 — LeadMissile (ракета полное упреждение)"),
            new NamedIntOption(200, "200 — CruiseMissile (крылатая ракета)"),
            new NamedIntOption(300, "300 — BallisticMissile (баллистическая)"),
            new NamedIntOption(400, "400 — LowDragBomb (обычная бомба)"),
            new NamedIntOption(410, "410 — HighDragBomb (штурмовая бомба)"),
            new NamedIntOption(610, "610 — LaserGuidedFreeFaling (лазерная КАБ)")
        };

        private sealed class TrajectoryListItem
        {
            public bool IsVanilla { get; }
            public CustomTrajectoryDto Data { get; }
            public string DisplayText { get; }

            public TrajectoryListItem(bool isVanilla, CustomTrajectoryDto data, string displayText)
            {
                IsVanilla = isVanilla;
                Data = data;
                DisplayText = displayText;
            }

            public override string ToString() => DisplayText;
        }

        private TrajectoryConfig _config = new TrajectoryConfig();
        private string _gameRoot = string.Empty;
        private bool _suppressEvents;

        private readonly List<AmmoWeaponCatalogItem> _ammoCatalog = new List<AmmoWeaponCatalogItem>();
        private readonly Dictionary<int, List<AmmoWeaponCatalogItem>> _ammoByWeaponId = new Dictionary<int, List<AmmoWeaponCatalogItem>>();
        private readonly List<AmmoWeaponCatalogItem> _filteredAmmo = new List<AmmoWeaponCatalogItem>();

        private CheckBox _chkHideVanilla;
        private ListBox _lstTrajectories;
        private TextBox _txtName;
        private TextBox _txtDesc;
        private ComboBox _cmbBaseType;
        private CheckBox _chkUseHeightFormula;
        private TextBox _txtHeightFormula;
        private Label _lblFormulaStatus;
        private TextBox _txtMinRefDist;
        private TextBox _txtMinApogee;
        private TextBox _txtMaxRefDist;
        private TextBox _txtMaxApogee;
        private TextBox _txtGravMult;
        private TextBox _txtSpeedMult;
        private TextBox _txtAccMult;
        private TextBox _txtBurnMult;
        private TextBox _txtRotMult;
        private TextBox _txtLoftHeight;
        private TextBox _txtLoftAngle;
        private CheckBox _chkForceTopAttack;
        private CheckBox _chkAllowPrecisionStrike;
        private Button _btnDupTraj;
        private Button _btnDelTraj;
        private Button _btnDelAllTraj;
        private CustomTrajectoryPreviewCanvas _preview;

        private TextBox _txtAmmoSearch;
        private CheckBox _chkOnlyAssigned;
        private DataGridView _dgvAssign;
        private DataGridViewComboBoxColumn _colAssigned;
        private Label _lblAssignCount;
        private Label _lblStatus;

        public CustomTrajectoryControl()
        {
            BuildUi();
        }

        private void BuildUi()
        {
            var outer = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var mainSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1
            };
            UiLayoutHelper.ApplyInitialSplit(mainSplit, minPanel1: 250, minPanel2: 520, fixedPanel1: 300);

            // Левая колонка: список пользовательских и ванильных траекторий
            var leftLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1, Padding = new Padding(6) };
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            leftLayout.Controls.Add(new Label
            {
                Text = "Траектории",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 0, 0, 4)
            }, 0, 0);

            _chkHideVanilla = new CheckBox
            {
                Text = "Скрыть ванильные траектории",
                AutoSize = true,
                Checked = false,
                Margin = new Padding(0, 0, 0, 4)
            };
            _chkHideVanilla.CheckedChanged += (_, _) =>
            {
                if (_suppressEvents) return;
                RefreshTrajectoryList();
            };
            leftLayout.Controls.Add(_chkHideVanilla, 0, 1);

            _lstTrajectories = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false };
            _lstTrajectories.SelectedIndexChanged += (_, _) =>
            {
                if (_suppressEvents) return;
                LoadSelectedTrajectoryToUi();
            };
            _lstTrajectories.KeyDown += (_, e) =>
            {
                if (e.KeyCode == Keys.Delete)
                {
                    e.Handled = true;
                    DeleteSelectedTrajectory();
                }
            };

            var listCtxMenu = new ContextMenuStrip();
            listCtxMenu.Items.Add("Дублировать / создать копию", null, (_, _) => DuplicateSelectedTrajectory());
            listCtxMenu.Items.Add("Удалить выбранную", null, (_, _) => DeleteSelectedTrajectory());
            listCtxMenu.Items.Add(new ToolStripSeparator());
            listCtxMenu.Items.Add("Удалить все свои траектории", null, (_, _) => DeleteAllTrajectories());
            _lstTrajectories.ContextMenuStrip = listCtxMenu;

            leftLayout.Controls.Add(_lstTrajectories, 0, 2);

            var leftBtns = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                RowCount = 3,
                Padding = new Padding(0, 6, 0, 0)
            };
            leftBtns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            leftBtns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            leftBtns.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftBtns.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftBtns.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var btnNew = new Button
            {
                Text = "+ Новая",
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(4, 3, 4, 3),
                Margin = new Padding(3)
            };
            btnNew.Click += (_, _) => AddNewTrajectory(null);

            var templateMenu = new ContextMenuStrip();
            foreach (CustomTrajectoryDto tpl in TrajectoryCatalog.CreateTrajectoryTemplates())
            {
                CustomTrajectoryDto captured = tpl;
                var item = new ToolStripMenuItem(captured.Name);
                item.Click += (_, _) => AddNewTrajectory(captured);
                templateMenu.Items.Add(item);
            }

            var btnTemplate = new Button
            {
                Text = "+ Шаблон ▾",
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(4, 3, 4, 3),
                Margin = new Padding(3)
            };
            btnTemplate.Click += (_, _) => templateMenu.Show(btnTemplate, new Point(0, btnTemplate.Height));

            _btnDupTraj = new Button
            {
                Text = "Дублировать",
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(4, 3, 4, 3),
                Margin = new Padding(3)
            };
            _btnDupTraj.Click += (_, _) => DuplicateSelectedTrajectory();

            _btnDelTraj = new Button
            {
                Text = "Удалить выбранную",
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(4, 3, 4, 3),
                Margin = new Padding(3),
                BackColor = Color.FromArgb(250, 224, 224),
                Font = new Font(Font, FontStyle.Bold)
            };
            _btnDelTraj.Click += (_, _) => DeleteSelectedTrajectory();

            _btnDelAllTraj = new Button
            {
                Text = "Удалить все траектории",
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(4, 3, 4, 3),
                Margin = new Padding(3),
                BackColor = Color.FromArgb(248, 236, 236)
            };
            _btnDelAllTraj.Click += (_, _) => DeleteAllTrajectories();

            leftBtns.Controls.Add(btnNew, 0, 0);
            leftBtns.Controls.Add(btnTemplate, 1, 0);
            leftBtns.Controls.Add(_btnDupTraj, 0, 1);
            leftBtns.Controls.Add(_btnDelTraj, 1, 1);
            leftBtns.Controls.Add(_btnDelAllTraj, 0, 2);
            leftBtns.SetColumnSpan(_btnDelAllTraj, 2);
            leftLayout.Controls.Add(leftBtns, 0, 3);
            mainSplit.Panel1.Controls.Add(leftLayout);

            // Правый SplitContainer: центр (конструктор + превью) и правая часть (присвоение оружию)
            var centerRightSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical
            };
            UiLayoutHelper.ApplyInitialSplit(centerRightSplit, ratio: 0.46, minPanel1: 360, minPanel2: 360);

            // Центр: параметры + 2D-превью
            var centerSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal
            };
            UiLayoutHelper.ApplyInitialSplit(centerSplit, ratio: 0.62, minPanel1: 250, minPanel2: 140);

            var propsScroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(6) };
            var tbl = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Top, ColumnCount = 4 };
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));

            int row = 0;
            _txtName = AddFullRowTextBox(tbl, ref row, "Название:", out _);
            _txtDesc = AddFullRowTextBox(tbl, ref row, "Описание:", out _);

            tbl.Controls.Add(new Label { Text = "Базовый движок:", AutoSize = true, Margin = new Padding(0, 6, 6, 3) }, 0, row);
            _cmbBaseType = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
            foreach (NamedIntOption opt in SupportedBaseTypes)
                _cmbBaseType.Items.Add(opt);
            _cmbBaseType.SelectedIndexChanged += (_, _) => CommitPropsFromUi();
            tbl.Controls.Add(_cmbBaseType, 1, row);
            tbl.SetColumnSpan(_cmbBaseType, 3);
            row++;

            _chkUseHeightFormula = new CheckBox
            {
                Text = "Кастомная формула высоты дуги (для 20/30/40/300; переменные: t, d, dist, apogee)",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 8, 0, 3)
            };
            _chkUseHeightFormula.CheckedChanged += (_, _) => CommitPropsFromUi();
            tbl.Controls.Add(_chkUseHeightFormula, 0, row);
            tbl.SetColumnSpan(_chkUseHeightFormula, 4);
            row++;

            _txtHeightFormula = AddFullRowTextBox(tbl, ref row, "Формула h(t):", out _);
            _txtHeightFormula.Font = new Font("Consolas", 9.5f);

            _lblFormulaStatus = new Label { AutoSize = true, Margin = new Padding(0, 2, 0, 6) };
            tbl.Controls.Add(_lblFormulaStatus, 1, row);
            tbl.SetColumnSpan(_lblFormulaStatus, 3);
            row++;

            _txtMinRefDist = AddPairBox(tbl, row, 0, "Мин. дистанция (м):");
            _txtMinApogee = AddPairBox(tbl, row, 2, "Мин. апогей (м):");
            row++;
            _txtMaxRefDist = AddPairBox(tbl, row, 0, "Макс. дистанция (м):");
            _txtMaxApogee = AddPairBox(tbl, row, 2, "Макс. апогей (м):");
            row++;
            _txtGravMult = AddPairBox(tbl, row, 0, "Множ. гравитации:");
            _txtSpeedMult = AddPairBox(tbl, row, 2, "Множ. скорости:");
            row++;
            _txtAccMult = AddPairBox(tbl, row, 0, "Множ. ускорения:");
            _txtBurnMult = AddPairBox(tbl, row, 2, "Множ. BurnTime:");
            row++;
            _txtRotMult = AddPairBox(tbl, row, 0, "Множ. поворота:");
            _txtLoftHeight = AddPairBox(tbl, row, 2, "LoftHeight (-1=БД):");
            row++;
            _txtLoftAngle = AddPairBox(tbl, row, 0, "LoftAngle (-1=БД):");

            _chkForceTopAttack = new CheckBox { Text = "Force TopAttack", AutoSize = true, Margin = new Padding(6, 5, 0, 3) };
            _chkForceTopAttack.CheckedChanged += (_, _) => CommitPropsFromUi();
            tbl.Controls.Add(_chkForceTopAttack, 2, row);
            tbl.SetColumnSpan(_chkForceTopAttack, 2);
            row++;

            _chkAllowPrecisionStrike = new CheckBox
            {
                Text = "Разрешить Precision Strike (мод, работает для любого типа траектории)",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 75, 130),
                Margin = new Padding(0, 6, 0, 3)
            };
            _chkAllowPrecisionStrike.CheckedChanged += (_, _) => CommitPropsFromUi();
            tbl.Controls.Add(_chkAllowPrecisionStrike, 0, row);
            tbl.SetColumnSpan(_chkAllowPrecisionStrike, 4);

            propsScroll.Controls.Add(tbl);
            centerSplit.Panel1.Controls.Add(propsScroll);

            _preview = new CustomTrajectoryPreviewCanvas { Dock = DockStyle.Fill };
            centerSplit.Panel2.Controls.Add(_preview);
            centerRightSplit.Panel1.Controls.Add(centerSplit);

            // Правая колонка: присвоение вооружению / боеприпасам
            var rightLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1, Padding = new Padding(6) };
            rightLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            rightLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            rightLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            rightLayout.Controls.Add(new Label
            {
                Text = "Присвоить траекторию вооружению / боеприпасам",
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 0, 0, 4)
            }, 0, 0);

            var filterFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
            _txtAmmoSearch = new TextBox { Width = 220, PlaceholderText = "Оружие, снаряд или ID..." };
            _txtAmmoSearch.TextChanged += (_, _) => RefreshAssignGrid();

            _chkOnlyAssigned = new CheckBox { Text = "Только назначенные", AutoSize = true, Margin = new Padding(8, 5, 6, 3) };
            _chkOnlyAssigned.CheckedChanged += (_, _) => RefreshAssignGrid();

            _lblAssignCount = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(8, 5, 0, 3) };
            filterFlow.Controls.AddRange(new Control[] { _txtAmmoSearch, _chkOnlyAssigned, _lblAssignCount });
            rightLayout.Controls.Add(filterFlow, 0, 1);

            _dgvAssign = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = false,
                EditMode = DataGridViewEditMode.EditOnEnter,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            UiLayoutHelper.StyleDataGrid(_dgvAssign);

            _dgvAssign.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", HeaderText = "ID", ReadOnly = true, MinimumWidth = 44, FillWeight = 9 });
            _dgvAssign.Columns.Add(new DataGridViewTextBoxColumn { Name = "Ammo", HeaderText = "Боеприпас", ReadOnly = true, MinimumWidth = 135, FillWeight = 26 });
            _dgvAssign.Columns.Add(new DataGridViewTextBoxColumn { Name = "Weapon", HeaderText = "Оружие", ReadOnly = true, MinimumWidth = 115, FillWeight = 23 });
            _dgvAssign.Columns.Add(new DataGridViewTextBoxColumn { Name = "Vanilla", HeaderText = "Ваниль", ReadOnly = true, MinimumWidth = 95, FillWeight = 15 });
            _dgvAssign.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Precision", HeaderText = "Precision", MinimumWidth = 66, FillWeight = 9 });
            _colAssigned = new DataGridViewComboBoxColumn
            {
                Name = "Assigned",
                HeaderText = "Новая траектория",
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton,
                ValueType = typeof(int),
                MinimumWidth = 150,
                FillWeight = 24
            };
            _dgvAssign.Columns.Add(_colAssigned);
            _dgvAssign.DataError += (_, e) => { e.ThrowException = false; };
            _dgvAssign.CurrentCellDirtyStateChanged += (_, _) =>
            {
                if (_dgvAssign.IsCurrentCellDirty && (_dgvAssign.CurrentCell is DataGridViewCheckBoxCell || _dgvAssign.CurrentCell is DataGridViewComboBoxCell))
                    _dgvAssign.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _dgvAssign.CellValueChanged += OnAssignGridCellValueChanged;
            rightLayout.Controls.Add(_dgvAssign, 0, 2);

            var assignBtns = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Padding = new Padding(0, 6, 0, 0) };
            var btnAssignSelected = new Button { Text = "Присвоить выбранным БК", AutoSize = true, BackColor = Color.FromArgb(224, 240, 224), Font = new Font(Font, FontStyle.Bold) };
            btnAssignSelected.Click += (_, _) => AssignToSelectedAmmo();

            var btnAssignWeapon = new Button { Text = "Присвоить всему оружию", AutoSize = true, BackColor = Color.FromArgb(224, 236, 250) };
            btnAssignWeapon.Click += (_, _) => AssignToEntireWeapon();

            var btnUnassign = new Button { Text = "Снять присвоение", AutoSize = true };
            btnUnassign.Click += (_, _) => UnassignSelected();

            var btnSyncJson = new Button { Text = "Записать тип в Ammunitions.json", AutoSize = true };
            btnSyncJson.Click += (_, _) => SyncSelectedToAmmoJson();

            assignBtns.Controls.AddRange(new Control[] { btnAssignSelected, btnAssignWeapon, btnUnassign, btnSyncJson });
            rightLayout.Controls.Add(assignBtns, 0, 3);
            centerRightSplit.Panel2.Controls.Add(rightLayout);

            mainSplit.Panel2.Controls.Add(centerRightSplit);
            outer.Controls.Add(mainSplit, 0, 0);

            // Нижняя панель
            var bottomFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(6),
                BackColor = Color.FromArgb(242, 244, 248),
                WrapContents = true
            };

            var btnSave = new Button
            {
                Text = "Сохранить (UserData\\TrajectoryEditor.json)",
                AutoSize = true,
                BackColor = Color.FromArgb(215, 238, 215),
                Font = new Font(Font, FontStyle.Bold)
            };
            btnSave.Click += (_, _) => SaveRequested?.Invoke();

            var btnReload = new Button { Text = "Перезагрузить", AutoSize = true };
            btnReload.Click += (_, _) => ReloadRequested?.Invoke();

            _lblStatus = new Label { AutoSize = true, Margin = new Padding(12, 6, 4, 4), ForeColor = Color.DimGray };
            bottomFlow.Controls.AddRange(new Control[] { btnSave, btnReload, _lblStatus });
            outer.Controls.Add(bottomFlow, 0, 1);

            Controls.Add(outer);
        }

        private TextBox AddFullRowTextBox(TableLayoutPanel tbl, ref int row, string label, out Label lblCtrl)
        {
            lblCtrl = new Label { Text = label, AutoSize = true, Margin = new Padding(0, 6, 6, 3) };
            var tb = new TextBox { Dock = DockStyle.Fill, Margin = new Padding(0, 3, 0, 3) };
            HookTextCommit(tb);
            tbl.Controls.Add(lblCtrl, 0, row);
            tbl.Controls.Add(tb, 1, row);
            tbl.SetColumnSpan(tb, 3);
            row++;
            return tb;
        }

        private TextBox AddPairBox(TableLayoutPanel tbl, int row, int col, string label)
        {
            tbl.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(col > 0 ? 10 : 0, 6, 6, 3) }, col, row);
            var tb = new TextBox { Dock = DockStyle.Fill, Margin = new Padding(0, 3, 0, 3) };
            HookTextCommit(tb);
            tbl.Controls.Add(tb, col + 1, row);
            return tb;
        }

        private void HookTextCommit(TextBox tb)
        {
            tb.Leave += (_, _) => CommitPropsFromUi();
            tb.KeyDown += (_, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    CommitPropsFromUi();
                }
            };
        }

        public void SetGameRoot(string gameRoot)
        {
            _gameRoot = gameRoot ?? string.Empty;
            LoadAmmoWeaponCatalog();
            RefreshAssignGrid();
        }

        public void BindConfig(TrajectoryConfig config)
        {
            _config = config ?? new TrajectoryConfig();
            RefreshTrajectoryList();
            RefreshAssignGrid();
        }

        public void CommitPendingEdits()
        {
            _dgvAssign?.EndEdit();
            CommitPropsFromUi();
        }

        public void SetStatus(string text, Color color)
        {
            _lblStatus.Text = text;
            _lblStatus.ForeColor = color;
        }

        private void LoadAmmoWeaponCatalog()
        {
            _ammoCatalog.Clear();
            _ammoByWeaponId.Clear();
            if (string.IsNullOrEmpty(_gameRoot))
                return;

            string dbDir = Path.Combine(_gameRoot, "UserData", "MLDatabaseMod", "actual");
            string ammoPath = Path.Combine(dbDir, "Ammunitions.json");
            if (!File.Exists(ammoPath))
                return;

            try
            {
                var weaponNames = new Dictionary<int, string>();
                string weaponsPath = Path.Combine(dbDir, "Weapons.json");
                if (File.Exists(weaponsPath))
                {
                    JsonArray wArr = JsonNode.Parse(File.ReadAllText(weaponsPath))?.AsArray();
                    if (wArr != null)
                    {
                        foreach (JsonNode n in wArr)
                        {
                            if (n is JsonObject o && TryReadInt(o, "Id", out int wid))
                            {
                                string hud = o["HUDName"]?.ToString();
                                string name = o["Name"]?.ToString();
                                weaponNames[wid] = !string.IsNullOrWhiteSpace(hud) ? hud : (name ?? $"Weapon #{wid}");
                            }
                        }
                    }
                }

                var weaponsByAmmo = new Dictionary<int, List<(int id, string name)>>();
                string waPath = Path.Combine(dbDir, "WeaponAmmunitions.json");
                if (File.Exists(waPath))
                {
                    JsonArray waArr = JsonNode.Parse(File.ReadAllText(waPath))?.AsArray();
                    if (waArr != null)
                    {
                        foreach (JsonNode n in waArr)
                        {
                            if (n is JsonObject o &&
                                TryReadInt(o, "AmmunitionId", out int aid) &&
                                TryReadInt(o, "WeaponId", out int wid))
                            {
                                if (!weaponsByAmmo.TryGetValue(aid, out var list))
                                {
                                    list = new List<(int, string)>();
                                    weaponsByAmmo[aid] = list;
                                }
                                string wName = weaponNames.TryGetValue(wid, out string wn) ? wn : $"#{wid}";
                                if (list.All(x => x.id != wid))
                                    list.Add((wid, wName));
                            }
                        }
                    }
                }

                JsonArray aArr = JsonNode.Parse(File.ReadAllText(ammoPath))?.AsArray();
                if (aArr == null)
                    return;

                foreach (JsonNode n in aArr)
                {
                    if (n is not JsonObject o || !TryReadInt(o, "Id", out int aid))
                        continue;

                    TryReadInt(o, "TrajectoryType", out int tt);
                    var item = new AmmoWeaponCatalogItem
                    {
                        AmmoId = aid,
                        AmmoName = o["Name"]?.ToString() ?? "",
                        HudName = o["HUDName"]?.ToString() ?? "",
                        VanillaTrajectoryType = tt
                    };

                    if (weaponsByAmmo.TryGetValue(aid, out var wList) && wList.Count > 0)
                    {
                        item.WeaponIds = wList.Select(w => w.id).ToList();
                        item.WeaponsText = string.Join(", ", wList.Take(3).Select(w => w.name)) + (wList.Count > 3 ? $" (+{wList.Count - 3})" : "");
                        foreach (int wid in item.WeaponIds)
                        {
                            if (!_ammoByWeaponId.TryGetValue(wid, out var aList))
                            {
                                aList = new List<AmmoWeaponCatalogItem>();
                                _ammoByWeaponId[wid] = aList;
                            }
                            aList.Add(item);
                        }
                    }

                    _ammoCatalog.Add(item);
                }

                _ammoCatalog.Sort((a, b) => a.AmmoId.CompareTo(b.AmmoId));
            }
            catch
            {
                // Не блокируем редактор, если JSON повреждён или отсутствует
            }
        }

        private static bool TryReadInt(JsonObject o, string key, out int val)
        {
            val = 0;
            JsonNode n = o[key];
            if (n == null) return false;
            return int.TryParse(n.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
        }

        private TrajectoryListItem GetSelectedListItem() =>
            _lstTrajectories.SelectedItem as TrajectoryListItem;

        private CustomTrajectoryDto GetSelectedCustomTrajectory()
        {
            TrajectoryListItem item = GetSelectedListItem();
            return item != null && !item.IsVanilla ? item.Data : null;
        }

        private List<TrajectoryListItem> BuildVanillaTrajectoryItems()
        {
            var items = new List<TrajectoryListItem>(SupportedBaseTypes.Length);
            foreach (NamedIntOption opt in SupportedBaseTypes)
            {
                int typeId = opt.Value;
                var dto = new CustomTrajectoryDto
                {
                    Id = -typeId,
                    Name = opt.Label,
                    Description = GetVanillaDescription(typeId),
                    BaseTrajectoryType = typeId,
                    UseCustomHeightFormula = false,
                    HeightFormula = "apogee * 4 * t * (1 - t)",
                    GravityMultiplier = 1f,
                    SpeedMultiplier = 1f,
                    AccelerationMultiplier = 1f,
                    BurnTimeMultiplier = 1f,
                    RotationSpeedMultiplier = 1f,
                    LoftHeightOverride = -1,
                    LoftAngleOverride = -1,
                    ForceTopAttack = false,
                    AllowPrecisionStrike = typeId is 200 or 300 or 400 or 410
                };

                switch (typeId)
                {
                    case 20:
                    case 40:
                        dto.MinRefDistance = _config.MIN_ARTILLERY_HEIGHT_REFERENCE_DISTANCE;
                        dto.MinApogee = _config.MIN_ARTILLERY_SHOT_APOGEE;
                        dto.MaxRefDistance = _config.MAX_ARTILLERY_HEIGHT_REFERENCE_DISTANCE;
                        dto.MaxApogee = _config.MAX_ARTILLERY_SHOT_APOGEE;
                        break;
                    case 30:
                        dto.MinRefDistance = _config.MIN_MORTAR_HEIGHT_REFERENCE_DISTANCE;
                        dto.MinApogee = _config.MIN_MORTAR_SHOT_APOGEE;
                        dto.MaxRefDistance = _config.MAX_MORTAR_HEIGHT_REFERENCE_DISTANCE;
                        dto.MaxApogee = _config.MAX_MORTAR_SHOT_APOGEE;
                        break;
                    case 200:
                        dto.LoftHeightOverride = (int)Math.Round(_config.CRUISE_MISSILE_TARGET_HEIGHT);
                        break;
                    case 300:
                        dto.MinRefDistance = 500f;
                        dto.MinApogee = _config.BALLISTIC_MISSILES_APOAPSIS * 0.6f;
                        dto.MaxRefDistance = 6000f;
                        dto.MaxApogee = _config.BALLISTIC_MISSILES_APOAPSIS;
                        break;
                    case 400:
                        dto.GravityMultiplier = _config.BOMBS_GRAVITY_MULTIPLYER;
                        break;
                    case 410:
                        dto.GravityMultiplier = _config.HIGH_DRAG_BOMBS_GRAVITY_MULTIPLYER;
                        break;
                }

                items.Add(new TrajectoryListItem(true, dto, $"[Ваниль] {TrajectoryCatalog.FormatTrajectoryShort(typeId)}"));
            }
            return items;
        }

        private static string GetVanillaDescription(int typeId) => typeId switch
        {
            10 => "Встроенный движок: баллистика прямой наводкой с гравитацией G.",
            20 => "Встроенный движок: гаубичная навесная дуга (Artillery).",
            30 => "Встроенный движок: крутая миномётная дуга (Mortar).",
            40 => "Встроенный движок: дуга РСЗО с дисперсией по CDF-кривой (MLRS).",
            100 => "Встроенный движок: управляемая ракета чистого преследования (Pursuit).",
            110 => "Встроенный движок: управляемая ракета с частичным упреждением и горкой (LeadPursuit).",
            120 => "Встроенный движок: управляемая ракета с полным упреждением (LeadMissile).",
            200 => "Встроенный движок: крылатая ракета с огибанием рельефа (поддерживает Precision Strike).",
            300 => "Встроенный движок: баллистическая ракета с высоким апогеем (поддерживает Precision Strike).",
            400 => "Встроенный движок: обычная свободнопадающая или КАБ бомба (LowDragBomb).",
            410 => "Встроенный движок: штурмовая тормозная бомба (HighDragBomb).",
            610 => "Встроенный движок: рантайм-планирование по лазерной подсветке (LaserFreeFall).",
            _ => "Встроенный движок игры."
        };

        private void RefreshTrajectoryList(int selectId = -1)
        {
            TrajectoryListItem prev = GetSelectedListItem();
            int prevCustomId = prev != null && !prev.IsVanilla ? prev.Data.Id : -1;
            int prevVanillaBase = prev != null && prev.IsVanilla ? prev.Data.BaseTrajectoryType : -1;
            int targetCustomId = selectId >= 0 ? selectId : prevCustomId;

            _suppressEvents = true;
            try
            {
                _lstTrajectories.Items.Clear();
                int idxToSelect = -1;

                foreach (CustomTrajectoryDto t in _config.CustomTrajectories)
                {
                    var item = new TrajectoryListItem(false, t, t.ToString());
                    int idx = _lstTrajectories.Items.Add(item);
                    if (targetCustomId >= 0 && t.Id == targetCustomId)
                        idxToSelect = idx;
                }

                if (_chkHideVanilla == null || !_chkHideVanilla.Checked)
                {
                    foreach (TrajectoryListItem vItem in BuildVanillaTrajectoryItems())
                    {
                        int idx = _lstTrajectories.Items.Add(vItem);
                        if (selectId < 0 && idxToSelect < 0 && prevVanillaBase >= 0 && vItem.Data.BaseTrajectoryType == prevVanillaBase)
                            idxToSelect = idx;
                    }
                }

                if (idxToSelect < 0 && _lstTrajectories.Items.Count > 0)
                    idxToSelect = 0;

                _lstTrajectories.SelectedIndex = idxToSelect;
            }
            finally
            {
                _suppressEvents = false;
            }
            LoadSelectedTrajectoryToUi();
        }

        private void LoadSelectedTrajectoryToUi()
        {
            TrajectoryListItem sel = GetSelectedListItem();
            bool has = sel != null;
            bool isVanilla = sel?.IsVanilla == true;
            bool editable = has && !isVanilla;
            CustomTrajectoryDto t = sel?.Data;

            _suppressEvents = true;
            try
            {
                Control[] inputs =
                {
                    _txtName, _txtDesc, _cmbBaseType, _chkUseHeightFormula, _txtHeightFormula,
                    _txtMinRefDist, _txtMinApogee, _txtMaxRefDist, _txtMaxApogee,
                    _txtGravMult, _txtSpeedMult, _txtAccMult, _txtBurnMult, _txtRotMult,
                    _txtLoftHeight, _txtLoftAngle, _chkForceTopAttack, _chkAllowPrecisionStrike
                };
                foreach (Control c in inputs)
                    c.Enabled = editable;

                _btnDupTraj.Enabled = has;
                _btnDupTraj.Text = isVanilla ? "Создать копию" : "Дублировать";
                _btnDelTraj.Enabled = editable;
                _btnDelAllTraj.Enabled = _config.CustomTrajectories.Count > 0;

                if (!has || t == null)
                {
                    _txtName.Text = "";
                    _txtDesc.Text = "";
                    _txtHeightFormula.Text = "";
                    _lblFormulaStatus.Text = "Нажмите «+ Новая» или «+ Шаблон» слева.";
                    _lblFormulaStatus.ForeColor = Color.DimGray;
                    _preview.SetTrajectory(null);
                    return;
                }

                _txtName.Text = t.Name;
                _txtDesc.Text = t.Description;

                int baseIdx = 1;
                for (int i = 0; i < _cmbBaseType.Items.Count; i++)
                {
                    if (_cmbBaseType.Items[i] is NamedIntOption opt && opt.Value == t.BaseTrajectoryType)
                    {
                        baseIdx = i;
                        break;
                    }
                }
                _cmbBaseType.SelectedIndex = baseIdx;

                _chkUseHeightFormula.Checked = t.UseCustomHeightFormula;
                _txtHeightFormula.Text = t.HeightFormula;
                _txtMinRefDist.Text = t.MinRefDistance.ToString("G7", CultureInfo.InvariantCulture);
                _txtMinApogee.Text = t.MinApogee.ToString("G7", CultureInfo.InvariantCulture);
                _txtMaxRefDist.Text = t.MaxRefDistance.ToString("G7", CultureInfo.InvariantCulture);
                _txtMaxApogee.Text = t.MaxApogee.ToString("G7", CultureInfo.InvariantCulture);
                _txtGravMult.Text = t.GravityMultiplier.ToString("G7", CultureInfo.InvariantCulture);
                _txtSpeedMult.Text = t.SpeedMultiplier.ToString("G7", CultureInfo.InvariantCulture);
                _txtAccMult.Text = t.AccelerationMultiplier.ToString("G7", CultureInfo.InvariantCulture);
                _txtBurnMult.Text = t.BurnTimeMultiplier.ToString("G7", CultureInfo.InvariantCulture);
                _txtRotMult.Text = t.RotationSpeedMultiplier.ToString("G7", CultureInfo.InvariantCulture);
                _txtLoftHeight.Text = t.LoftHeightOverride.ToString(CultureInfo.InvariantCulture);
                _txtLoftAngle.Text = t.LoftAngleOverride.ToString(CultureInfo.InvariantCulture);
                _chkForceTopAttack.Checked = t.ForceTopAttack;
                _chkAllowPrecisionStrike.Checked = t.AllowPrecisionStrike;

                if (isVanilla)
                {
                    _lblFormulaStatus.Text = "Встроенная траектория игры (только чтение). Нажмите «Создать копию» слева для редактирования.";
                    _lblFormulaStatus.ForeColor = Color.SteelBlue;
                }
                else
                {
                    UpdateHeightFormulaStatus(t.HeightFormula);
                }
                _preview.SetTrajectory(t);
            }
            finally
            {
                _suppressEvents = false;
            }
        }

        private void UpdateHeightFormulaStatus(string exprText)
        {
            if (!_chkUseHeightFormula.Checked)
            {
                _lblFormulaStatus.Text = "Кастомная формула высоты выключена (используется множитель гравитации/скорости/горки).";
                _lblFormulaStatus.ForeColor = Color.DimGray;
                return;
            }

            if (!FormulaExpressionEngine.TryCompile(exprText, out CompiledExpression compiled, out string err))
            {
                _lblFormulaStatus.Text = $"Ошибка формулы: {err}";
                _lblFormulaStatus.ForeColor = Color.Firebrick;
                return;
            }

            foreach (string v in compiled.GetReferencedVariables())
            {
                if (!string.Equals(v, "t", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(v, "d", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(v, "dist", StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(v, "apogee", StringComparison.OrdinalIgnoreCase))
                {
                    _lblFormulaStatus.Text = $"Неизвестная переменная '{v}' (допустимы: t, d, dist, apogee).";
                    _lblFormulaStatus.ForeColor = Color.Firebrick;
                    return;
                }
            }

            _lblFormulaStatus.Text = "Формула высоты корректна ✓";
            _lblFormulaStatus.ForeColor = Color.ForestGreen;
        }

        private void CommitPropsFromUi()
        {
            if (_suppressEvents) return;
            CustomTrajectoryDto t = GetSelectedCustomTrajectory();
            if (t == null) return;

            t.Name = string.IsNullOrWhiteSpace(_txtName.Text) ? $"Траектория #{t.Id}" : _txtName.Text.Trim();
            t.Description = _txtDesc.Text ?? string.Empty;
            if (_cmbBaseType.SelectedItem is NamedIntOption opt)
                t.BaseTrajectoryType = opt.Value;

            t.UseCustomHeightFormula = _chkUseHeightFormula.Checked;
            t.HeightFormula = _txtHeightFormula.Text.Trim();
            UpdateHeightFormulaStatus(t.HeightFormula);

            if (TryParseF(_txtMinRefDist.Text, out float v1)) t.MinRefDistance = v1;
            if (TryParseF(_txtMinApogee.Text, out float v2)) t.MinApogee = v2;
            if (TryParseF(_txtMaxRefDist.Text, out float v3)) t.MaxRefDistance = v3;
            if (TryParseF(_txtMaxApogee.Text, out float v4)) t.MaxApogee = v4;
            if (TryParseF(_txtGravMult.Text, out float v5)) t.GravityMultiplier = Math.Max(0.01f, v5);
            if (TryParseF(_txtSpeedMult.Text, out float v6)) t.SpeedMultiplier = Math.Max(0.05f, v6);
            if (TryParseF(_txtAccMult.Text, out float v7)) t.AccelerationMultiplier = Math.Max(0.05f, v7);
            if (TryParseF(_txtBurnMult.Text, out float v8)) t.BurnTimeMultiplier = Math.Max(0.05f, v8);
            if (TryParseF(_txtRotMult.Text, out float v9)) t.RotationSpeedMultiplier = Math.Max(0.05f, v9);
            if (int.TryParse(_txtLoftHeight.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int lh)) t.LoftHeightOverride = lh;
            if (int.TryParse(_txtLoftAngle.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int la)) t.LoftAngleOverride = la;
            t.ForceTopAttack = _chkForceTopAttack.Checked;
            t.AllowPrecisionStrike = _chkAllowPrecisionStrike.Checked;

            int selIdx = _lstTrajectories.SelectedIndex;
            if (selIdx >= 0 && selIdx < _lstTrajectories.Items.Count)
            {
                _suppressEvents = true;
                _lstTrajectories.Items[selIdx] = new TrajectoryListItem(false, t, t.ToString());
                _suppressEvents = false;
            }

            _preview.SetTrajectory(t);
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private static bool TryParseF(string text, out float val) =>
            float.TryParse((text ?? string.Empty).Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out val);

        private int AllocateNextId()
        {
            int max = 1000;
            foreach (CustomTrajectoryDto t in _config.CustomTrajectories)
            {
                if (t.Id >= max) max = t.Id + 1;
            }
            return max;
        }

        private void AddNewTrajectory(CustomTrajectoryDto template)
        {
            int id = AllocateNextId();
            CustomTrajectoryDto added = template != null
                ? template.Clone(id, template.Name)
                : new CustomTrajectoryDto { Id = id, Name = $"Новая траектория #{id}" };

            _config.CustomTrajectories.Add(added);
            RefreshTrajectoryList(id);
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private CustomTrajectoryDto CloneItemToCustom(TrajectoryListItem sel)
        {
            int id = AllocateNextId();
            string newName = sel.IsVanilla
                ? $"{TrajectoryCatalog.FormatTrajectoryShort(sel.Data.BaseTrajectoryType)} (своя)"
                : sel.Data.Name + " (копия)";

            CustomTrajectoryDto copy = sel.Data.Clone(id, newName);
            if (sel.IsVanilla)
            {
                copy.UseCustomHeightFormula = sel.Data.BaseTrajectoryType is 20 or 30 or 40 or 300;
                copy.Description = $"Создана на основе ванильного движка {TrajectoryCatalog.FormatTrajectoryShort(sel.Data.BaseTrajectoryType)}.";
            }

            _config.CustomTrajectories.Add(copy);
            RefreshTrajectoryList(id);
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
            return copy;
        }

        private void DuplicateSelectedTrajectory()
        {
            TrajectoryListItem sel = GetSelectedListItem();
            if (sel == null) return;
            CloneItemToCustom(sel);
        }

        private void DeleteSelectedTrajectory()
        {
            CustomTrajectoryDto sel = GetSelectedCustomTrajectory();
            if (sel == null) return;
            _config.CustomTrajectories.Remove(sel);
            _config.WeaponTrajectoryAssignments.RemoveAll(a => a.CustomTrajectoryId == sel.Id);
            RefreshTrajectoryList();
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private void DeleteAllTrajectories()
        {
            if (_config.CustomTrajectories.Count == 0)
                return;

            if (MessageBox.Show(
                    $"Удалить все пользовательские траектории ({_config.CustomTrajectories.Count}) и очистить их назначения у вооружения?",
                    "Удалить все траектории",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            _config.CustomTrajectories.Clear();
            _config.WeaponTrajectoryAssignments.Clear();
            RefreshTrajectoryList();
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private void RefreshAssignGrid()
        {
            var trajById = _config.CustomTrajectories.ToDictionary(t => t.Id);
            var assignByAmmo = new Dictionary<int, WeaponTrajectoryAssignmentDto>();
            foreach (WeaponTrajectoryAssignmentDto a in _config.WeaponTrajectoryAssignments)
                assignByAmmo[a.AmmunitionId] = a;

            string query = (_txtAmmoSearch.Text ?? string.Empty).Trim();
            bool onlyAssigned = _chkOnlyAssigned.Checked;

            _suppressEvents = true;
            try
            {
                _filteredAmmo.Clear();
                _dgvAssign.Rows.Clear();

                var options = new List<NamedIntOption> { new NamedIntOption(0, "— (ваниль) —") };
                foreach (CustomTrajectoryDto ct in _config.CustomTrajectories)
                    options.Add(new NamedIntOption(ct.Id, $"#{ct.Id}: {ct.Name}"));

                _colAssigned.DataSource = null;
                _colAssigned.DataSource = options;
                _colAssigned.DisplayMember = nameof(NamedIntOption.Label);
                _colAssigned.ValueMember = nameof(NamedIntOption.Value);

                foreach (AmmoWeaponCatalogItem item in _ammoCatalog)
                {
                    assignByAmmo.TryGetValue(item.AmmoId, out WeaponTrajectoryAssignmentDto assignment);
                    bool isPrec = _config.PrecisionStrikeAmmoIds.Contains(item.AmmoId);
                    if (assignment != null && trajById.TryGetValue(assignment.CustomTrajectoryId, out CustomTrajectoryDto act) && act.AllowPrecisionStrike)
                        isPrec = true;

                    if (onlyAssigned && assignment == null && !isPrec)
                        continue;

                    if (!string.IsNullOrEmpty(query))
                    {
                        bool hit = item.AmmoId.ToString(CultureInfo.InvariantCulture).IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   item.AmmoName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   item.HudName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   item.WeaponsText.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;
                        if (!hit) continue;
                    }

                    _filteredAmmo.Add(item);
                    int assignedId = assignment != null && trajById.ContainsKey(assignment.CustomTrajectoryId)
                        ? assignment.CustomTrajectoryId
                        : 0;

                    string ammoDisplay = !string.IsNullOrWhiteSpace(item.HudName) ? $"{item.AmmoName} ({item.HudName})" : item.AmmoName;
                    int rowIdx = _dgvAssign.Rows.Add();
                    DataGridViewRow row = _dgvAssign.Rows[rowIdx];
                    row.Tag = item;
                    row.Cells["Id"].Value = item.AmmoId;
                    row.Cells["Ammo"].Value = ammoDisplay;
                    row.Cells["Weapon"].Value = item.WeaponsText;
                    row.Cells["Vanilla"].Value = TrajectoryCatalog.FormatTrajectoryShort(item.VanillaTrajectoryType);
                    row.Cells["Precision"].Value = isPrec;
                    row.Cells["Assigned"].Value = assignedId;
                    row.DefaultCellStyle.BackColor = (assignedId > 0 || isPrec) ? Color.FromArgb(228, 246, 228) : Color.White;
                }

                _lblAssignCount.Text = $"Показано: {_filteredAmmo.Count} | Назначено: {_config.WeaponTrajectoryAssignments.Count} | Precision: {_config.PrecisionStrikeAmmoIds.Count}";
            }
            finally
            {
                _suppressEvents = false;
            }
        }

        private void OnAssignGridCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_suppressEvents || e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            DataGridViewRow row = _dgvAssign.Rows[e.RowIndex];
            if (row.Tag is not AmmoWeaponCatalogItem item)
                return;

            string colName = _dgvAssign.Columns[e.ColumnIndex].Name;
            object raw = row.Cells[e.ColumnIndex].Value;

            if (string.Equals(colName, "Precision", StringComparison.Ordinal))
            {
                bool want = Convert.ToBoolean(raw, CultureInfo.InvariantCulture);
                if (want)
                {
                    if (!_config.PrecisionStrikeAmmoIds.Contains(item.AmmoId))
                        _config.PrecisionStrikeAmmoIds.Add(item.AmmoId);
                }
                else
                {
                    _config.PrecisionStrikeAmmoIds.Remove(item.AmmoId);
                    WeaponTrajectoryAssignmentDto asgn = _config.WeaponTrajectoryAssignments.FirstOrDefault(a => a.AmmunitionId == item.AmmoId);
                    CustomTrajectoryDto ct = asgn != null ? _config.CustomTrajectories.FirstOrDefault(t => t.Id == asgn.CustomTrajectoryId) : null;
                    if (ct != null && ct.AllowPrecisionStrike)
                    {
                        _suppressEvents = true;
                        try { row.Cells["Precision"].Value = true; }
                        finally { _suppressEvents = false; }
                        MessageBox.Show(
                            "Precision Strike включён на самой назначенной траектории — снимите галочку в настройках траектории слева или смените траекторию на ваниль.",
                            "Precision от траектории",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return;
                    }
                }
            }
            else if (string.Equals(colName, "Assigned", StringComparison.Ordinal))
            {
                int trajId = raw is int iv ? iv : 0;
                if (trajId <= 0)
                {
                    _config.WeaponTrajectoryAssignments.RemoveAll(a => a.AmmunitionId == item.AmmoId);
                }
                else
                {
                    CustomTrajectoryDto traj = _config.CustomTrajectories.FirstOrDefault(t => t.Id == trajId);
                    if (traj != null)
                        UpsertAssignment(item, traj);
                }
            }
            else
            {
                return;
            }

            _suppressEvents = true;
            try
            {
                bool hasTraj = _config.WeaponTrajectoryAssignments.Any(a => a.AmmunitionId == item.AmmoId);
                bool hasPrec = _config.PrecisionStrikeAmmoIds.Contains(item.AmmoId);
                if (hasTraj)
                {
                    var asgn = _config.WeaponTrajectoryAssignments.First(a => a.AmmunitionId == item.AmmoId);
                    var ct = _config.CustomTrajectories.FirstOrDefault(t => t.Id == asgn.CustomTrajectoryId);
                    if (ct != null && ct.AllowPrecisionStrike) hasPrec = true;
                }
                row.Cells["Precision"].Value = hasPrec;
                row.DefaultCellStyle.BackColor = (hasTraj || hasPrec) ? Color.FromArgb(228, 246, 228) : Color.White;
                _lblAssignCount.Text = $"Показано: {_filteredAmmo.Count} | Назначено: {_config.WeaponTrajectoryAssignments.Count} | Precision: {_config.PrecisionStrikeAmmoIds.Count}";
            }
            finally
            {
                _suppressEvents = false;
            }

            ConfigChanged?.Invoke();
        }

        private List<AmmoWeaponCatalogItem> GetSelectedAmmoItems()
        {
            var list = new List<AmmoWeaponCatalogItem>();
            foreach (DataGridViewRow r in _dgvAssign.SelectedRows)
            {
                if (r.Tag is AmmoWeaponCatalogItem item)
                    list.Add(item);
            }
            if (list.Count == 0 && _dgvAssign.CurrentRow?.Tag is AmmoWeaponCatalogItem cur)
                list.Add(cur);
            return list;
        }

        private void UpsertAssignment(AmmoWeaponCatalogItem item, CustomTrajectoryDto traj)
        {
            _config.WeaponTrajectoryAssignments.RemoveAll(a => a.AmmunitionId == item.AmmoId);
            _config.WeaponTrajectoryAssignments.Add(new WeaponTrajectoryAssignmentDto
            {
                AmmunitionId = item.AmmoId,
                AmmunitionName = item.AmmoName,
                WeaponHint = item.WeaponsText,
                CustomTrajectoryId = traj.Id,
                OverrideBaseTrajectoryType = true
            });
        }

        private CustomTrajectoryDto ResolveOrCloneTargetForAssign()
        {
            TrajectoryListItem sel = GetSelectedListItem();
            if (sel == null)
            {
                MessageBox.Show("Сначала создайте или выберите траекторию в списке слева.", "Траектория не выбрана", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }

            if (!sel.IsVanilla)
                return sel.Data;

            if (MessageBox.Show(
                    $"Выбрана встроенная (ванильная) траектория «{sel.DisplayText}».\n\nСоздать редактируемую копию на её основе и присвоить выбранному вооружению?",
                    "Создать копию для присвоения",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) != DialogResult.Yes)
                return null;

            return CloneItemToCustom(sel);
        }

        private void AssignToSelectedAmmo()
        {
            CustomTrajectoryDto traj = ResolveOrCloneTargetForAssign();
            if (traj == null)
                return;

            List<AmmoWeaponCatalogItem> selected = GetSelectedAmmoItems();
            if (selected.Count == 0) return;

            foreach (AmmoWeaponCatalogItem item in selected)
                UpsertAssignment(item, traj);

            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private void AssignToEntireWeapon()
        {
            CustomTrajectoryDto traj = ResolveOrCloneTargetForAssign();
            if (traj == null)
                return;

            List<AmmoWeaponCatalogItem> selected = GetSelectedAmmoItems();
            if (selected.Count == 0) return;

            var touchedWeaponIds = new HashSet<int>();
            var touchedAmmoIds = new HashSet<int>();

            foreach (AmmoWeaponCatalogItem item in selected)
            {
                if (item.WeaponIds.Count == 0)
                {
                    if (touchedAmmoIds.Add(item.AmmoId))
                        UpsertAssignment(item, traj);
                    continue;
                }

                foreach (int wid in item.WeaponIds)
                {
                    if (!touchedWeaponIds.Add(wid)) continue;
                    if (_ammoByWeaponId.TryGetValue(wid, out var weaponAmmos))
                    {
                        foreach (AmmoWeaponCatalogItem wa in weaponAmmos)
                        {
                            if (touchedAmmoIds.Add(wa.AmmoId))
                                UpsertAssignment(wa, traj);
                        }
                    }
                }
            }

            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private void UnassignSelected()
        {
            List<AmmoWeaponCatalogItem> selected = GetSelectedAmmoItems();
            if (selected.Count == 0) return;

            var removeIds = new HashSet<int>(selected.Select(x => x.AmmoId));
            _config.WeaponTrajectoryAssignments.RemoveAll(a => removeIds.Contains(a.AmmunitionId));
            RefreshAssignGrid();
            ConfigChanged?.Invoke();
        }

        private void SyncSelectedToAmmoJson()
        {
            var trajById = _config.CustomTrajectories.ToDictionary(t => t.Id);
            var assignByAmmo = _config.WeaponTrajectoryAssignments.ToDictionary(a => a.AmmunitionId);
            List<AmmoWeaponCatalogItem> selected = GetSelectedAmmoItems();

            int synced = 0;
            foreach (AmmoWeaponCatalogItem item in selected)
            {
                if (assignByAmmo.TryGetValue(item.AmmoId, out WeaponTrajectoryAssignmentDto a) &&
                    trajById.TryGetValue(a.CustomTrajectoryId, out CustomTrajectoryDto ct))
                {
                    SyncToAmmoJsonRequested?.Invoke(a, ct);
                    synced++;
                }
            }

            if (synced > 0)
                SetStatus($"Обновлён TrajectoryType в Ammunitions.json для {synced} боепр. (не забудьте сохранить Ammunitions.json!).", Color.ForestGreen);
            else
                MessageBox.Show("Среди выбранных строк нет назначенных пользовательских траекторий.", "Нет назначений", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
