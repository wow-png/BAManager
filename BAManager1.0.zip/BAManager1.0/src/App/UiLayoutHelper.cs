using System;
using System.Drawing;
using System.Windows.Forms;

namespace TrajectoryEditor
{
    internal static class UiLayoutHelper
    {
        public static void ApplyInitialSplit(
            SplitContainer sc,
            double ratio = 0.5,
            int minPanel1 = 150,
            int minPanel2 = 150,
            int? fixedPanel1 = null,
            int? fixedPanel2 = null)
        {
            if (sc == null)
                return;

            bool applied = false;

            void TryApply()
            {
                if (applied || sc.IsDisposed)
                    return;

                int total = sc.Orientation == Orientation.Vertical ? sc.Width : sc.Height;
                int minNeeded = minPanel1 + minPanel2 + sc.SplitterWidth + 8;
                if (total < minNeeded)
                    return;

                applied = true;
                sc.Panel1MinSize = minPanel1;
                sc.Panel2MinSize = minPanel2;

                int dist;
                if (fixedPanel1.HasValue)
                    dist = fixedPanel1.Value;
                else if (fixedPanel2.HasValue)
                    dist = total - fixedPanel2.Value - sc.SplitterWidth;
                else
                    dist = (int)Math.Round(total * ratio);

                int maxDist = Math.Max(minPanel1, total - minPanel2 - sc.SplitterWidth);
                sc.SplitterDistance = Math.Clamp(dist, minPanel1, maxDist);
            }

            sc.HandleCreated += (_, _) => TryApply();
            sc.SizeChanged += (_, _) => TryApply();
            sc.Layout += (_, _) => TryApply();
        }

        public static void StyleDataGrid(DataGridView dgv)
        {
            if (dgv == null)
                return;

            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.FixedSingle;
            dgv.GridColor = Color.FromArgb(228, 232, 238);
            dgv.EnableHeadersVisualStyles = true;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.DataError += (_, e) => { e.ThrowException = false; };
        }
    }
}
