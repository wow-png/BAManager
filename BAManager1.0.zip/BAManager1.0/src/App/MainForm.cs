using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows.Forms;

namespace TrajectoryEditor
{
    public sealed class MainForm : Form
    {
        private static readonly JsonSerializerOptions PrettyJsonOpts = new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };

        private string _gameRoot;
        private string _globalConfigPath;

        private TrajectoryConfig _config = new TrajectoryConfig();
        private bool _suppressGlobalEvents;
        private bool _globalDirty;

        // Верхняя статусная панель
        private Label _lblRoot;
        private Label _lblModStatus;
        private Label _lblDbModStatus;

        // Вкладка 1: Глобальные параметры
        private ListBox _lstCategories;
        private TextBox _txtGlobalSearch;
        private DataGridView _dgvGlobal;
        private CheckBox _chkEnabled;
        private TextBox _txtPidP;
        private TextBox _txtPidI;
        private TextBox _txtPidD;
        private ComboBox _cmbCurveSelect;
        private DataGridView _dgvCurve;
        private TrajectoryPreviewPanel _previewPanel;
        private Label _lblGlobalStatus;

        // Вкладки 2–5: Авиация, Саплай и экономика, Формулы игры, Справочник/редактор формул, Конструктор траекторий
        private TabControl _tabs;
        private SettingsSectionControl _planesTabCtrl;
        private SettingsSectionControl _supplyTabCtrl;
        private SettingsSectionControl _formulasTabCtrl;
        private FormulaReferenceControl _formulaRefCtrl;
        private CustomTrajectoryControl _customTrajCtrl;

        // Вкладка 7: Боеприпасы (Ammunitions.json)
        private string _ammoPath;
        private JsonArray _ammoArray;
        private bool _ammoDirty;
        private readonly List<int> _filteredAmmoIndices = new List<int>();
        private int _selectedAmmoIndex = -1;
        private bool _suppressAmmoEvents;
        private bool _suppressAmmoFilterEvents;

        private Label _lblAmmoFile;
        private Label _lblAmmoCount;
        private ComboBox _cmbAmmoTypeFilter;
        private TextBox _txtAmmoSearch;
        private DataGridView _dgvAmmo;
        private Panel _pnlAmmoInspector;
        private readonly Dictionary<string, Control> _ammoFieldControls = new Dictionary<string, Control>(StringComparer.Ordinal);
        private ComboBox _cmbBatchField;
        private ComboBox _cmbBatchOp;
        private TextBox _txtBatchVal;

        public MainForm() : this(FindGameRoot())
        {
        }

        public MainForm(string gameRoot)
        {
            _gameRoot = gameRoot;
            _globalConfigPath = Path.Combine(_gameRoot, "UserData", "TrajectoryEditor.json");
            _ammoPath = Path.Combine(_gameRoot, "UserData", "MLDatabaseMod", "actual", "Ammunitions.json");

            Text = "Broken Arrow — Редактор траекторий, формул, авиации и саплая";
            Size = new Size(1380, 860);
            MinimumSize = new Size(1120, 700);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 9f);

            BuildUi();
            RefreshModStatuses();
            LoadGlobalConfigFromDisk();
            LoadAmmunitionsFromDisk(_ammoPath, silentMissing: true);
        }

        public static string FindGameRoot()
        {
            string[] candidates =
            {
                AppContext.BaseDirectory,
                Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..")),
                Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..")),
                Directory.GetCurrentDirectory()
            };

            foreach (string c in candidates)
            {
                if (string.IsNullOrEmpty(c) || !Directory.Exists(c))
                    continue;

                if (File.Exists(Path.Combine(c, "BrokenArrow.exe")) ||
                    (Directory.Exists(Path.Combine(c, "UserData")) && Directory.Exists(Path.Combine(c, "Mods"))))
                {
                    return Path.GetFullPath(c);
                }
            }

            return Directory.GetCurrentDirectory();
        }

        private void BuildUi()
        {
            var rootLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2
            };
            rootLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            rootLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            // Верхняя статусная панель
            var statusBar = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(8, 6, 8, 6),
                BackColor = Color.FromArgb(242, 244, 248),
                WrapContents = true
            };

            _lblRoot = new Label { AutoSize = true, Margin = new Padding(0, 4, 14, 4), Font = new Font(Font, FontStyle.Bold) };
            _lblModStatus = new Label { AutoSize = true, Margin = new Padding(0, 4, 14, 4), Font = new Font(Font, FontStyle.Bold) };
            _lblDbModStatus = new Label { AutoSize = true, Margin = new Padding(0, 4, 14, 4), Font = new Font(Font, FontStyle.Bold) };

            var btnRefreshStatus = new Button { Text = "Обновить статусы", AutoSize = true, Margin = new Padding(4, 0, 0, 0) };
            btnRefreshStatus.Click += (_, _) => RefreshModStatuses();

            var btnChangeRoot = new Button { Text = "Выбрать папку игры...", AutoSize = true, Margin = new Padding(4, 0, 0, 0) };
            btnChangeRoot.Click += (_, _) => SelectGameRootFolder();

            statusBar.Controls.AddRange(new Control[] { _lblRoot, _lblModStatus, _lblDbModStatus, btnRefreshStatus, btnChangeRoot });

            // Вкладки
            _tabs = new TabControl { Dock = DockStyle.Fill };
            var tabGlobal = new TabPage("Траектории (BattleSystemSettings)");
            var tabPlanes = new TabPage("Авиация: Бомбинг / Штурм / Пресижен");
            var tabSupply = new TabPage("Саплай и экономика");
            var tabFormulas = new TabPage("Формулы игры");
            var tabFormulaRef = new TabPage("Формулы: справочник и редактор");
            var tabCustomTraj = new TabPage("Конструктор траекторий");
            var tabAmmo = new TabPage("Боеприпасы (Ammunitions.json)");

            BuildGlobalTab(tabGlobal);
            _planesTabCtrl = CreateSectionTab(
                tabPlanes,
                TrajectoryCatalog.PlanesCategories,
                TrajectoryCatalog.PlanesSettings);
            _supplyTabCtrl = CreateSectionTab(
                tabSupply,
                TrajectoryCatalog.SupplyEconomyCategories,
                TrajectoryCatalog.SupplyAndEconomySettings,
                FormatSupplySummary);
            _formulasTabCtrl = CreateSectionTab(
                tabFormulas,
                TrajectoryCatalog.GameFormulaCategories,
                TrajectoryCatalog.GameFormulaSettings);
            _formulaRefCtrl = new FormulaReferenceControl { Dock = DockStyle.Fill };
            _formulaRefCtrl.NavigateToTabRequested += idx =>
            {
                if (idx >= 0 && idx < _tabs.TabPages.Count)
                    _tabs.SelectedIndex = idx;
            };
            _formulaRefCtrl.ConfigChanged += () => MarkGlobalDirty(refreshFormulaRef: false);
            _formulaRefCtrl.SaveRequested += SaveGlobalConfig;
            tabFormulaRef.Controls.Add(_formulaRefCtrl);

            _customTrajCtrl = new CustomTrajectoryControl { Dock = DockStyle.Fill };
            _customTrajCtrl.ConfigChanged += () => MarkGlobalDirty(refreshCustomTraj: false);
            _customTrajCtrl.SaveRequested += SaveGlobalConfig;
            _customTrajCtrl.ReloadRequested += LoadGlobalConfigFromDisk;
            _customTrajCtrl.SyncToAmmoJsonRequested += OnSyncCustomTrajectoryToAmmoJson;
            _customTrajCtrl.SetGameRoot(_gameRoot);
            tabCustomTraj.Controls.Add(_customTrajCtrl);

            BuildAmmoTab(tabAmmo);

            _tabs.TabPages.Add(tabGlobal);
            _tabs.TabPages.Add(tabPlanes);
            _tabs.TabPages.Add(tabSupply);
            _tabs.TabPages.Add(tabFormulas);
            _tabs.TabPages.Add(tabFormulaRef);
            _tabs.TabPages.Add(tabCustomTraj);
            _tabs.TabPages.Add(tabAmmo);

            rootLayout.Controls.Add(statusBar, 0, 0);
            rootLayout.Controls.Add(_tabs, 0, 1);
            Controls.Add(rootLayout);
        }

        private void BuildGlobalTab(TabPage page)
        {
            var mainSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1
            };
            UiLayoutHelper.ApplyInitialSplit(mainSplit, minPanel1: 200, minPanel2: 500, fixedPanel1: 250);

            // Левая колонка: категории + поиск
            var leftPanel = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(6), RowCount = 4, ColumnCount = 1 };
            leftPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            leftPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            leftPanel.Controls.Add(new Label { Text = "Поиск параметра:", AutoSize = true, Margin = new Padding(0, 0, 0, 3) }, 0, 0);
            _txtGlobalSearch = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Например: APOGEE, PID, BOMB..." };
            _txtGlobalSearch.TextChanged += (_, _) => PopulateGlobalGrid();
            leftPanel.Controls.Add(_txtGlobalSearch, 0, 1);

            leftPanel.Controls.Add(new Label { Text = "Категории:", AutoSize = true, Margin = new Padding(0, 8, 0, 3) }, 0, 2);
            _lstCategories = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false };
            foreach (string cat in TrajectoryCatalog.Categories)
                _lstCategories.Items.Add(cat);
            _lstCategories.SelectedIndex = 0;
            _lstCategories.SelectedIndexChanged += (_, _) => PopulateGlobalGrid();
            leftPanel.Controls.Add(_lstCategories, 0, 3);
            mainSplit.Panel1.Controls.Add(leftPanel);

            // Правая часть: (Таблица + PID/Кривые) | 2D-превью + нижняя панель кнопок
            var rightOuter = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            rightOuter.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            rightOuter.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var centerRightSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical
            };
            UiLayoutHelper.ApplyInitialSplit(centerRightSplit, ratio: 0.62, minPanel1: 380, minPanel2: 260);

            // Центр: таблица сверху + PID/кривые снизу
            var centerVertSplit = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal
            };
            UiLayoutHelper.ApplyInitialSplit(centerVertSplit, ratio: 0.68, minPanel1: 200, minPanel2: 140);

            _dgvGlobal = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            };
            UiLayoutHelper.StyleDataGrid(_dgvGlobal);
            _dgvGlobal.Columns.Add(new DataGridViewTextBoxColumn { Name = "Key", HeaderText = "Параметр", ReadOnly = true, Width = 290 });
            _dgvGlobal.Columns.Add(new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Значение", Width = 140 });
            _dgvGlobal.Columns.Add(new DataGridViewTextBoxColumn { Name = "Vanilla", HeaderText = "Ваниль", ReadOnly = true, Width = 80 });
            _dgvGlobal.Columns.Add(new DataGridViewTextBoxColumn { Name = "Desc", HeaderText = "Описание", ReadOnly = true, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });

            _dgvGlobal.DataError += (_, e) => { e.ThrowException = false; };
            _dgvGlobal.CurrentCellDirtyStateChanged += (_, _) =>
            {
                if (_dgvGlobal.IsCurrentCellDirty && (_dgvGlobal.CurrentCell is DataGridViewCheckBoxCell || _dgvGlobal.CurrentCell is DataGridViewComboBoxCell))
                    _dgvGlobal.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _dgvGlobal.CellValueChanged += OnGlobalCellValueChanged;

            centerVertSplit.Panel1.Controls.Add(_dgvGlobal);

            // Панель PID + Кривые
            var arraysGroup = new GroupBox { Text = "Крылатые ракеты PID (CRUISE_MISSILE_PID) и кривые (AnimationCurve)", Dock = DockStyle.Fill, Padding = new Padding(6) };
            var arraysLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            arraysLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            arraysLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            var pidFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
            pidFlow.Controls.Add(new Label { Text = "CRUISE_MISSILE_PID:   P:", AutoSize = true, Margin = new Padding(0, 6, 4, 4) });
            _txtPidP = new TextBox { Width = 65 };
            pidFlow.Controls.Add(_txtPidP);
            pidFlow.Controls.Add(new Label { Text = "I:", AutoSize = true, Margin = new Padding(8, 6, 4, 4) });
            _txtPidI = new TextBox { Width = 65 };
            pidFlow.Controls.Add(_txtPidI);
            pidFlow.Controls.Add(new Label { Text = "D:", AutoSize = true, Margin = new Padding(8, 6, 4, 4) });
            _txtPidD = new TextBox { Width = 65 };
            pidFlow.Controls.Add(_txtPidD);

            foreach (TextBox tb in new[] { _txtPidP, _txtPidI, _txtPidD })
                tb.TextChanged += (_, _) => ApplyPidFromUi();

            pidFlow.Controls.Add(new Label { Text = "   Кривая:", AutoSize = true, Margin = new Padding(12, 6, 4, 4) });
            _cmbCurveSelect = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };
            _cmbCurveSelect.Items.Add("ARTILLERY_DISPERSION_CDF");
            _cmbCurveSelect.Items.Add("CRUISE_MISSILE_HEIGHTS_COEFFICIENTS");
            _cmbCurveSelect.SelectedIndex = 0;
            _cmbCurveSelect.SelectedIndexChanged += (_, _) => PopulateCurveGrid();
            pidFlow.Controls.Add(_cmbCurveSelect);

            var btnAddKey = new Button { Text = "+ Точка", AutoSize = true, Margin = new Padding(6, 1, 2, 1) };
            btnAddKey.Click += (_, _) => AddCurveKey();
            var btnDelKey = new Button { Text = "- Точка", AutoSize = true, Margin = new Padding(2, 1, 2, 1) };
            btnDelKey.Click += (_, _) => DeleteCurveKey();
            var btnResetCurve = new Button { Text = "Сброс кривой", AutoSize = true, Margin = new Padding(2, 1, 2, 1) };
            btnResetCurve.Click += (_, _) => ResetSelectedCurve();

            pidFlow.Controls.AddRange(new Control[] { btnAddKey, btnDelKey, btnResetCurve });

            _dgvCurve = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
            UiLayoutHelper.StyleDataGrid(_dgvCurve);
            _dgvCurve.Columns.Add(new DataGridViewTextBoxColumn { Name = "Time", HeaderText = "Time", Width = 100 });
            _dgvCurve.Columns.Add(new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Value", Width = 100 });
            _dgvCurve.Columns.Add(new DataGridViewTextBoxColumn { Name = "InTangent", HeaderText = "InTangent", Width = 110 });
            _dgvCurve.Columns.Add(new DataGridViewTextBoxColumn { Name = "OutTangent", HeaderText = "OutTangent", Width = 110 });
            _dgvCurve.DataError += (_, e) => { e.ThrowException = false; };
            _dgvCurve.CellValueChanged += OnCurveCellChanged;

            arraysLayout.Controls.Add(pidFlow, 0, 0);
            arraysLayout.Controls.Add(_dgvCurve, 0, 1);
            arraysGroup.Controls.Add(arraysLayout);
            centerVertSplit.Panel2.Controls.Add(arraysGroup);

            centerRightSplit.Panel1.Controls.Add(centerVertSplit);

            // Правая панель: 2D превью
            _previewPanel = new TrajectoryPreviewPanel { Dock = DockStyle.Fill };
            centerRightSplit.Panel2.Controls.Add(_previewPanel);

            // Нижняя панель кнопок глобальных параметров
            var bottomFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                Padding = new Padding(6),
                BackColor = Color.FromArgb(242, 244, 248)
            };

            _chkEnabled = new CheckBox { Text = "Включить применение мода (Enabled)", AutoSize = true, Checked = true, Margin = new Padding(4, 6, 12, 4) };
            _chkEnabled.CheckedChanged += (_, _) =>
            {
                if (_suppressGlobalEvents) return;
                _config.Enabled = _chkEnabled.Checked;
                MarkGlobalDirty();
            };

            var btnSaveGlobal = new Button { Text = "Сохранить (UserData\\TrajectoryEditor.json)", AutoSize = true, BackColor = Color.FromArgb(215, 238, 215), Font = new Font(Font, FontStyle.Bold) };
            btnSaveGlobal.Click += (_, _) => SaveGlobalConfig();

            var btnReloadGlobal = new Button { Text = "Перезагрузить", AutoSize = true };
            btnReloadGlobal.Click += (_, _) => LoadGlobalConfigFromDisk();

            var btnResetCat = new Button { Text = "Сбросить категорию", AutoSize = true };
            btnResetCat.Click += (_, _) => ResetGlobalCategory();

            var btnResetAll = new Button { Text = "Сбросить всё к ванили", AutoSize = true };
            btnResetAll.Click += (_, _) => ResetAllGlobal();

            _lblGlobalStatus = new Label { AutoSize = true, Margin = new Padding(12, 6, 4, 4), ForeColor = Color.DimGray };

            bottomFlow.Controls.AddRange(new Control[] { _chkEnabled, btnSaveGlobal, btnReloadGlobal, btnResetCat, btnResetAll, _lblGlobalStatus });

            rightOuter.Controls.Add(centerRightSplit, 0, 0);
            rightOuter.Controls.Add(bottomFlow, 0, 1);

            mainSplit.Panel2.Controls.Add(rightOuter);
            page.Controls.Add(mainSplit);
        }

        private SettingsSectionControl CreateSectionTab(
            TabPage page,
            string[] categories,
            IReadOnlyList<GlobalSettingMeta> settings,
            Func<TrajectoryConfig, string> summaryFunc = null)
        {
            var ctrl = new SettingsSectionControl(
                categories,
                settings,
                c =>
                {
                    foreach (GlobalSettingMeta m in settings)
                        m.Setter(c, m.VanillaValue);
                },
                summaryFunc)
            {
                Dock = DockStyle.Fill
            };
            ctrl.ConfigChanged += MarkGlobalDirty;
            ctrl.SaveRequested += SaveGlobalConfig;
            ctrl.ReloadRequested += LoadGlobalConfigFromDisk;
            page.Controls.Add(ctrl);
            return ctrl;
        }

        private static string FormatSupplySummary(TrajectoryConfig c)
        {
            float kgPerBatch = c.Supply.SupplyExchangeRate;
            float ptsPerBatch = c.Supply.SupplyValueBought;
            if (kgPerBatch <= 0f || ptsPerBatch <= 0f)
                return "Саплай: некорректный курс обмена (SupplyExchangeRate / SupplyValueBought <= 0)";

            float ptsPerTon = ptsPerBatch * (1000f / kgPerBatch);
            float kgPerPoint = kgPerBatch / ptsPerBatch;
            return string.Format(
                CultureInfo.InvariantCulture,
                "Цена саплая: {0:0.##} очков за тонну ({1:0.##} очков за {2:0.##} кг; 1 очко = {3:0.##} кг) | Множитель БК: x{4:0.###}",
                ptsPerTon, ptsPerBatch, kgPerBatch, kgPerPoint, c.Supply.AmmoCostMultiplier);
        }

        private void BuildAmmoTab(TabPage page)
        {
            var outer = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            // Верхняя панель фильтрации и загрузки JSON
            var topFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(6), WrapContents = true };
            var btnOpenAmmo = new Button { Text = "Открыть другой JSON...", AutoSize = true };
            btnOpenAmmo.Click += (_, _) => OpenOtherAmmoJson();

            var btnSaveAmmo = new Button { Text = "Сохранить Ammunitions.json", AutoSize = true, BackColor = Color.FromArgb(215, 238, 215), Font = new Font(Font, FontStyle.Bold) };
            btnSaveAmmo.Click += (_, _) => SaveAmmunitionsToDisk();

            var btnBackup = new Button { Text = "Создать бэкап (.bak)", AutoSize = true };
            btnBackup.Click += (_, _) => CreateManualBackup();

            var btnRestore = new Button { Text = "Восстановить из .bak", AutoSize = true };
            btnRestore.Click += (_, _) => RestoreFromBackup();

            var btnSavePrecisionMod = new Button { Text = "Сохранить Precision в мод (TrajectoryEditor.json)", AutoSize = true, BackColor = Color.FromArgb(224, 236, 250) };
            btnSavePrecisionMod.Click += (_, _) => SaveGlobalConfig();

            _lblAmmoFile = new Label { AutoSize = true, Margin = new Padding(8, 6, 8, 4), ForeColor = Color.DimGray };
            topFlow.Controls.AddRange(new Control[] { btnOpenAmmo, btnSaveAmmo, btnBackup, btnRestore, btnSavePrecisionMod, _lblAmmoFile });

            var filterFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(6, 0, 6, 6), WrapContents = true };
            filterFlow.Controls.Add(new Label { Text = "TrajectoryType:", AutoSize = true, Margin = new Padding(0, 6, 4, 4) });
            _cmbAmmoTypeFilter = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 290 };
            _cmbAmmoTypeFilter.SelectedIndexChanged += (_, _) =>
            {
                if (!_suppressAmmoFilterEvents)
                    RefreshAmmoGrid();
            };
            filterFlow.Controls.Add(_cmbAmmoTypeFilter);

            filterFlow.Controls.Add(new Label { Text = "  Поиск (Id / Name / HUDName):", AutoSize = true, Margin = new Padding(8, 6, 4, 4) });
            _txtAmmoSearch = new TextBox { Width = 240, PlaceholderText = "ATGM, Mk82, TOW, 155..." };
            _txtAmmoSearch.TextChanged += (_, _) => RefreshAmmoGrid();
            filterFlow.Controls.Add(_txtAmmoSearch);

            _lblAmmoCount = new Label { AutoSize = true, Margin = new Padding(12, 6, 4, 4), Font = new Font(Font, FontStyle.Bold) };
            filterFlow.Controls.Add(_lblAmmoCount);

            var topStack = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, RowCount = 2, ColumnCount = 1 };
            topStack.Controls.Add(topFlow, 0, 0);
            topStack.Controls.Add(filterFlow, 0, 1);

            // Центральный сплиттер: редактируемая таблица боеприпасов | инспектор 33 полей
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel2
            };
            UiLayoutHelper.ApplyInitialSplit(split, minPanel1: 520, minPanel2: 340, fixedPanel2: 430);

            _dgvAmmo = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = false,
                EditMode = DataGridViewEditMode.EditOnEnter,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            UiLayoutHelper.StyleDataGrid(_dgvAmmo);

            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", HeaderText = "Id", ReadOnly = true, MinimumWidth = 48, FillWeight = 6 });
            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "Name", HeaderText = "Name", ReadOnly = true, MinimumWidth = 175, FillWeight = 23 });
            _dgvAmmo.Columns.Add(new DataGridViewComboBoxColumn
            {
                Name = "TrajectoryType",
                HeaderText = "TrajectoryType",
                DataSource = TrajectoryCatalog.TrajectoryTypes.ToList(),
                DisplayMember = nameof(NamedIntOption.Label),
                ValueMember = nameof(NamedIntOption.Value),
                ValueType = typeof(int),
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton,
                MinimumWidth = 155,
                FillWeight = 18
            });
            _dgvAmmo.Columns.Add(new DataGridViewComboBoxColumn
            {
                Name = "Seeker",
                HeaderText = "Seeker (ГСН)",
                DataSource = TrajectoryCatalog.SeekerTypes.ToList(),
                DisplayMember = nameof(NamedIntOption.Label),
                ValueMember = nameof(NamedIntOption.Value),
                ValueType = typeof(int),
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton,
                MinimumWidth = 120,
                FillWeight = 14
            });
            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "GroundRange", HeaderText = "GroundRange", MinimumWidth = 82, FillWeight = 8 });
            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "MuzzleVelocity", HeaderText = "MuzzleVel", MinimumWidth = 74, FillWeight = 8 });
            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "MaxSpeed", HeaderText = "MaxSpeed", MinimumWidth = 72, FillWeight = 8 });
            _dgvAmmo.Columns.Add(new DataGridViewTextBoxColumn { Name = "DispersionH", HeaderText = "DispH", MinimumWidth = 60, FillWeight = 7 });
            _dgvAmmo.Columns.Add(new DataGridViewCheckBoxColumn { Name = "LaserGuided", HeaderText = "Laser", MinimumWidth = 54, FillWeight = 5 });
            _dgvAmmo.Columns.Add(new DataGridViewCheckBoxColumn { Name = "TopArmorAttack", HeaderText = "TopAtk", MinimumWidth = 58, FillWeight = 6 });
            _dgvAmmo.Columns.Add(new DataGridViewCheckBoxColumn { Name = "PrecisionStrike", HeaderText = "Precision (мод)", MinimumWidth = 88, FillWeight = 8 });

            _dgvAmmo.DataError += (_, e) => { e.ThrowException = false; };
            _dgvAmmo.CurrentCellDirtyStateChanged += (_, _) =>
            {
                if (_dgvAmmo.IsCurrentCellDirty && (_dgvAmmo.CurrentCell is DataGridViewCheckBoxCell || _dgvAmmo.CurrentCell is DataGridViewComboBoxCell))
                    _dgvAmmo.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            _dgvAmmo.CellValueChanged += OnAmmoGridCellValueChanged;
            _dgvAmmo.SelectionChanged += (_, _) => OnAmmoSelectionChanged();
            split.Panel1.Controls.Add(_dgvAmmo);

            _pnlAmmoInspector = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(8) };
            BuildAmmoInspectorControls();
            split.Panel2.Controls.Add(_pnlAmmoInspector);

            // Нижняя панель массового редактирования (Batch Edit)
            var batchGroup = new GroupBox { Text = "Массовое редактирование (Batch Edit)", Dock = DockStyle.Fill, Padding = new Padding(6) };
            var batchFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };

            batchFlow.Controls.Add(new Label { Text = "Поле:", AutoSize = true, Margin = new Padding(0, 6, 4, 4) });
            _cmbBatchField = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 240 };
            foreach (AmmoFieldMeta f in TrajectoryCatalog.AmmoFields)
                _cmbBatchField.Items.Add(f.Name);
            _cmbBatchField.SelectedIndex = 0;
            batchFlow.Controls.Add(_cmbBatchField);

            batchFlow.Controls.Add(new Label { Text = "Операция:", AutoSize = true, Margin = new Padding(6, 6, 4, 4) });
            _cmbBatchOp = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 130 };
            _cmbBatchOp.Items.AddRange(new object[] { "Установить =", "Умножить ×", "Прибавить +" });
            _cmbBatchOp.SelectedIndex = 0;
            batchFlow.Controls.Add(_cmbBatchOp);

            batchFlow.Controls.Add(new Label { Text = "Значение:", AutoSize = true, Margin = new Padding(6, 6, 4, 4) });
            _txtBatchVal = new TextBox { Width = 100, Text = "1" };
            batchFlow.Controls.Add(_txtBatchVal);

            var btnApplySel = new Button { Text = "К выделенным", AutoSize = true, Margin = new Padding(10, 1, 4, 1) };
            btnApplySel.Click += (_, _) => ApplyBatchEdit(toAllFiltered: false);
            var btnApplyFiltered = new Button { Text = "Ко всем отфильтрованным", AutoSize = true, Margin = new Padding(4, 1, 4, 1) };
            btnApplyFiltered.Click += (_, _) => ApplyBatchEdit(toAllFiltered: true);

            batchFlow.Controls.AddRange(new Control[] { btnApplySel, btnApplyFiltered });
            batchGroup.Controls.Add(batchFlow);

            outer.Controls.Add(topStack, 0, 0);
            outer.Controls.Add(split, 0, 1);
            outer.Controls.Add(batchGroup, 0, 2);
            page.Controls.Add(outer);
        }

        private void BuildAmmoInspectorControls()
        {
            var tbl = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 2,
                Padding = new Padding(2, 2, 16, 12)
            };
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            string currentGroup = null;
            int row = 0;

            foreach (AmmoFieldMeta meta in TrajectoryCatalog.AmmoFields)
            {
                if (!string.Equals(currentGroup, meta.Group, StringComparison.Ordinal))
                {
                    currentGroup = meta.Group;
                    var hdr = new Label
                    {
                        Text = $"— {currentGroup} —",
                        AutoSize = true,
                        Font = new Font(Font, FontStyle.Bold),
                        ForeColor = Color.FromArgb(30, 80, 150),
                        Margin = new Padding(0, row == 0 ? 2 : 10, 0, 4)
                    };
                    tbl.RowCount = row + 1;
                    tbl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    tbl.Controls.Add(hdr, 0, row);
                    tbl.SetColumnSpan(hdr, 2);
                    row++;
                }

                tbl.RowCount = row + 1;
                tbl.RowStyles.Add(new RowStyle(SizeType.AutoSize));

                var lbl = new Label
                {
                    Text = meta.Label,
                    AutoSize = true,
                    Anchor = AnchorStyles.Left,
                    Margin = new Padding(0, 5, 6, 3)
                };
                tbl.Controls.Add(lbl, 0, row);

                Control editor;
                if (meta.IsTrajectoryEnum || meta.IsSeekerEnum)
                {
                    var cmb = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 240, Anchor = AnchorStyles.Left | AnchorStyles.Right };
                    foreach (NamedIntOption opt in (meta.IsTrajectoryEnum ? TrajectoryCatalog.TrajectoryTypes : TrajectoryCatalog.SeekerTypes))
                        cmb.Items.Add(opt);
                    cmb.SelectedIndexChanged += (_, _) =>
                    {
                        if (_suppressAmmoEvents || cmb.SelectedItem is not NamedIntOption opt) return;
                        CommitSingleAmmoField(meta, opt.Value);
                    };
                    editor = cmb;
                }
                else if (meta.IsBool)
                {
                    var chk = new CheckBox { AutoSize = true, Margin = new Padding(0, 3, 0, 3) };
                    chk.CheckedChanged += (_, _) =>
                    {
                        if (_suppressAmmoEvents) return;
                        CommitSingleAmmoField(meta, chk.Checked);
                    };
                    editor = chk;
                }
                else
                {
                    var tb = new TextBox { Width = 140, Anchor = AnchorStyles.Left | AnchorStyles.Right };
                    tb.TextChanged += (_, _) =>
                    {
                        if (_suppressAmmoEvents) return;
                        if (TryParseDouble(tb.Text, out double val))
                            CommitSingleAmmoField(meta, val);
                    };
                    tb.Leave += (_, _) =>
                    {
                        if (_suppressAmmoEvents) return;
                        if (TryParseDouble(tb.Text, out double val))
                        {
                            CommitSingleAmmoField(meta, val);
                            _suppressAmmoEvents = true;
                            try { tb.Text = FormatDouble(val); }
                            finally { _suppressAmmoEvents = false; }
                        }
                        else
                        {
                            LoadSelectedAmmoToInspector();
                        }
                    };
                    tb.KeyDown += (_, e) =>
                    {
                        if (e.KeyCode == Keys.Enter)
                        {
                            e.SuppressKeyPress = true;
                            if (TryParseDouble(tb.Text, out double val))
                            {
                                CommitSingleAmmoField(meta, val);
                                _suppressAmmoEvents = true;
                                try { tb.Text = FormatDouble(val); }
                                finally { _suppressAmmoEvents = false; }
                            }
                            else
                            {
                                LoadSelectedAmmoToInspector();
                            }
                        }
                    };
                    editor = tb;
                }

                _ammoFieldControls[meta.Name] = editor;
                tbl.Controls.Add(editor, 1, row);
                row++;
            }

            _pnlAmmoInspector.Controls.Add(tbl);
        }

        private void RefreshModStatuses()
        {
            if (File.Exists(Path.Combine(_gameRoot, "BrokenArrow.exe")))
            {
                _lblRoot.Text = $"Игра: {_gameRoot}";
                _lblRoot.ForeColor = Color.Black;
            }
            else
            {
                _lblRoot.Text = $"Игра (НЕ НАЙДЕН BrokenArrow.exe!): {_gameRoot}";
                _lblRoot.ForeColor = Color.Firebrick;
            }

            string modDll = Path.Combine(_gameRoot, "Mods", "TrajectoryEditorMod.dll");
            if (File.Exists(modDll))
            {
                _lblModStatus.Text = "TrajectoryEditorMod.dll: установлен (горячая перезагрузка)";
                _lblModStatus.ForeColor = Color.ForestGreen;
            }
            else
            {
                _lblModStatus.Text = "TrajectoryEditorMod.dll: не найден в Mods\\";
                _lblModStatus.ForeColor = Color.DarkOrange;
            }

            string dbMod = Path.Combine(_gameRoot, "Mods", "MLDatabaseMod.dll");
            if (File.Exists(dbMod))
            {
                _lblDbModStatus.Text = "MLDatabaseMod.dll: установлен";
                _lblDbModStatus.ForeColor = Color.ForestGreen;
            }
            else
            {
                _lblDbModStatus.Text = "MLDatabaseMod.dll: не найден";
                _lblDbModStatus.ForeColor = Color.DarkOrange;
            }
        }

        private void SelectGameRootFolder()
        {
            if (_globalDirty || _ammoDirty)
            {
                DialogResult res = MessageBox.Show(
                    "Есть несохранённые изменения. Сменить папку игры без сохранения?",
                    "Несохранённые изменения",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);
                if (res != DialogResult.Yes)
                    return;
            }

            using var dlg = new FolderBrowserDialog
            {
                Description = "Выберите корневую папку Broken Arrow (где находится BrokenArrow.exe)",
                SelectedPath = Directory.Exists(_gameRoot) ? _gameRoot : string.Empty,
                UseDescriptionForTitle = true
            };
            if (dlg.ShowDialog(this) != DialogResult.OK || string.IsNullOrWhiteSpace(dlg.SelectedPath))
                return;

            _gameRoot = Path.GetFullPath(dlg.SelectedPath);
            _globalConfigPath = Path.Combine(_gameRoot, "UserData", "TrajectoryEditor.json");
            _ammoPath = Path.Combine(_gameRoot, "UserData", "MLDatabaseMod", "actual", "Ammunitions.json");

            RefreshModStatuses();
            LoadGlobalConfigFromDisk();
            _customTrajCtrl?.SetGameRoot(_gameRoot);
            LoadAmmunitionsFromDisk(_ammoPath, silentMissing: true);
        }

        private void LoadGlobalConfigFromDisk()
        {
            try
            {
                _config = TrajectoryConfig.LoadOrCreate(_globalConfigPath);
                _globalDirty = false;
                SyncGlobalControls();
                SetGlobalStatusAll($"Загружено: {_globalConfigPath}", Color.DimGray);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка чтения {_globalConfigPath}:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SyncGlobalControls()
        {
            _suppressGlobalEvents = true;
            try
            {
                _chkEnabled.Checked = _config.Enabled;
                _txtPidP.Text = _config.CRUISE_MISSILE_PID[0].ToString("G9", CultureInfo.InvariantCulture);
                _txtPidI.Text = _config.CRUISE_MISSILE_PID[1].ToString("G9", CultureInfo.InvariantCulture);
                _txtPidD.Text = _config.CRUISE_MISSILE_PID[2].ToString("G9", CultureInfo.InvariantCulture);
            }
            finally
            {
                _suppressGlobalEvents = false;
            }

            PopulateGlobalGrid();
            PopulateCurveGrid();
            _previewPanel.SetConfig(_config);

            _planesTabCtrl?.BindConfig(_config);
            _supplyTabCtrl?.BindConfig(_config);
            _formulasTabCtrl?.BindConfig(_config);
            _formulaRefCtrl?.BindConfig(_config);
            _customTrajCtrl?.BindConfig(_config);
            RefreshAmmoGridPrecisionColumn();
        }

        private void PopulateGlobalGrid()
        {
            _suppressGlobalEvents = true;
            try
            {
                _dgvGlobal.Rows.Clear();
                string selectedCat = _lstCategories.SelectedItem as string ?? TrajectoryCatalog.CatAll;
                string query = (_txtGlobalSearch.Text ?? string.Empty).Trim();

                foreach (GlobalSettingMeta meta in TrajectoryCatalog.GlobalSettings)
                {
                    if (!string.Equals(selectedCat, TrajectoryCatalog.CatAll, StringComparison.Ordinal) &&
                        !string.Equals(meta.Category, selectedCat, StringComparison.Ordinal))
                        continue;

                    if (!string.IsNullOrEmpty(query) &&
                        meta.Key.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0 &&
                        meta.DescriptionRu.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0)
                        continue;

                    int rowIdx = _dgvGlobal.Rows.Add();
                    DataGridViewRow r = _dgvGlobal.Rows[rowIdx];
                    r.Tag = meta;
                    r.Cells["Key"].Value = meta.Key;
                    r.Cells["Desc"].Value = meta.DescriptionRu;

                    object curVal = meta.Getter(_config);

                    if (meta.Kind == SettingValueKind.Bool)
                    {
                        var chkCell = new DataGridViewCheckBoxCell { Value = Convert.ToBoolean(curVal, CultureInfo.InvariantCulture) };
                        r.Cells["Value"] = chkCell;
                        r.Cells["Vanilla"].Value = Convert.ToBoolean(meta.VanillaValue, CultureInfo.InvariantCulture) ? "true" : "false";
                    }
                    else if (meta.Kind == SettingValueKind.SwitchRuleEnum)
                    {
                        var cmbCell = new DataGridViewComboBoxCell
                        {
                            DataSource = TrajectoryCatalog.SwitchRules.ToList(),
                            DisplayMember = nameof(NamedIntOption.Label),
                            ValueMember = nameof(NamedIntOption.Value),
                            Value = Convert.ToInt32(curVal, CultureInfo.InvariantCulture)
                        };
                        r.Cells["Value"] = cmbCell;
                        r.Cells["Vanilla"].Value = TrajectoryCatalog.FormatSwitchRule(Convert.ToByte(meta.VanillaValue, CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        r.Cells["Value"].Value = FormatNumber(curVal);
                        r.Cells["Vanilla"].Value = FormatNumber(meta.VanillaValue);
                    }

                    UpdateGlobalRowHighlight(r, meta);
                }
            }
            finally
            {
                _suppressGlobalEvents = false;
            }
        }

        private void OnGlobalCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_suppressGlobalEvents || e.RowIndex < 0 || e.ColumnIndex != _dgvGlobal.Columns["Value"].Index)
                return;

            DataGridViewRow row = _dgvGlobal.Rows[e.RowIndex];
            if (row.Tag is not GlobalSettingMeta meta)
                return;

            object raw = row.Cells["Value"].Value;
            bool valid = true;

            try
            {
                switch (meta.Kind)
                {
                    case SettingValueKind.Bool:
                        meta.Setter(_config, Convert.ToBoolean(raw, CultureInfo.InvariantCulture));
                        break;
                    case SettingValueKind.SwitchRuleEnum:
                        meta.Setter(_config, Convert.ToByte(raw, CultureInfo.InvariantCulture));
                        break;
                    case SettingValueKind.Int:
                        if (TryParseInt(Convert.ToString(raw, CultureInfo.InvariantCulture), out int iv))
                        {
                            meta.Setter(_config, iv);
                            _suppressGlobalEvents = true;
                            row.Cells["Value"].Value = iv.ToString(CultureInfo.InvariantCulture);
                            _suppressGlobalEvents = false;
                        }
                        else valid = false;
                        break;
                    case SettingValueKind.Float:
                        if (TryParseFloat(Convert.ToString(raw, CultureInfo.InvariantCulture), out float fv))
                        {
                            meta.Setter(_config, fv);
                            _suppressGlobalEvents = true;
                            row.Cells["Value"].Value = fv.ToString("G9", CultureInfo.InvariantCulture);
                            _suppressGlobalEvents = false;
                        }
                        else valid = false;
                        break;
                }
            }
            catch
            {
                valid = false;
            }

            if (!valid)
            {
                _suppressGlobalEvents = true;
                row.Cells["Value"].Value = FormatNumber(meta.Getter(_config));
                _suppressGlobalEvents = false;
                return;
            }

            UpdateGlobalRowHighlight(row, meta);
            _previewPanel.SetConfig(_config);
            MarkGlobalDirty();
        }

        private void UpdateGlobalRowHighlight(DataGridViewRow row, GlobalSettingMeta meta)
        {
            bool changed = !AreValuesEqual(meta.Getter(_config), meta.VanillaValue, meta.Kind);
            Color bg = changed ? Color.FromArgb(255, 244, 214) : Color.White;
            row.DefaultCellStyle.BackColor = bg;
        }

        private void ApplyPidFromUi()
        {
            if (_suppressGlobalEvents) return;

            if (TryParseFloat(_txtPidP.Text, out float p) &&
                TryParseFloat(_txtPidI.Text, out float i) &&
                TryParseFloat(_txtPidD.Text, out float d))
            {
                _config.CRUISE_MISSILE_PID[0] = p;
                _config.CRUISE_MISSILE_PID[1] = i;
                _config.CRUISE_MISSILE_PID[2] = d;
                MarkGlobalDirty();
            }
        }

        private List<CurveKeyDto> GetActiveCurve() =>
            _cmbCurveSelect.SelectedIndex == 1
                ? _config.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS
                : _config.ARTILLERY_DISPERSION_CDF;

        private void PopulateCurveGrid()
        {
            _suppressGlobalEvents = true;
            try
            {
                _dgvCurve.Rows.Clear();
                List<CurveKeyDto> curve = GetActiveCurve();
                foreach (CurveKeyDto k in curve)
                {
                    _dgvCurve.Rows.Add(
                        k.Time.ToString("G9", CultureInfo.InvariantCulture),
                        k.Value.ToString("G9", CultureInfo.InvariantCulture),
                        k.InTangent.ToString("G9", CultureInfo.InvariantCulture),
                        k.OutTangent.ToString("G9", CultureInfo.InvariantCulture));
                }
            }
            finally
            {
                _suppressGlobalEvents = false;
            }
        }

        private void OnCurveCellChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_suppressGlobalEvents || e.RowIndex < 0)
                return;

            List<CurveKeyDto> curve = GetActiveCurve();
            if (e.RowIndex >= curve.Count)
                return;

            DataGridViewRow row = _dgvCurve.Rows[e.RowIndex];
            CurveKeyDto k = curve[e.RowIndex];
            string text = Convert.ToString(row.Cells[e.ColumnIndex].Value, CultureInfo.InvariantCulture);

            if (!TryParseFloat(text, out float fv))
            {
                PopulateCurveGrid();
                return;
            }

            switch (e.ColumnIndex)
            {
                case 0: k.Time = fv; break;
                case 1: k.Value = fv; break;
                case 2: k.InTangent = fv; break;
                case 3: k.OutTangent = fv; break;
            }

            MarkGlobalDirty();
        }

        private void AddCurveKey()
        {
            List<CurveKeyDto> curve = GetActiveCurve();
            CurveKeyDto last = curve.Count > 0 ? curve[^1].Clone() : new CurveKeyDto();
            curve.Add(last);
            PopulateCurveGrid();
            MarkGlobalDirty();
        }

        private void DeleteCurveKey()
        {
            List<CurveKeyDto> curve = GetActiveCurve();
            if (curve.Count <= 1 || _dgvCurve.CurrentRow == null)
                return;

            int idx = _dgvCurve.CurrentRow.Index;
            if (idx >= 0 && idx < curve.Count)
            {
                curve.RemoveAt(idx);
                PopulateCurveGrid();
                MarkGlobalDirty();
            }
        }

        private void ResetSelectedCurve()
        {
            if (_cmbCurveSelect.SelectedIndex == 1)
                _config.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS = TrajectoryConfig.DefaultCruiseCurve();
            else
                _config.ARTILLERY_DISPERSION_CDF = TrajectoryConfig.DefaultArtilleryCurve();

            PopulateCurveGrid();
            MarkGlobalDirty();
        }

        private void ResetGlobalCategory()
        {
            string selectedCat = _lstCategories.SelectedItem as string ?? TrajectoryCatalog.CatAll;
            if (string.Equals(selectedCat, TrajectoryCatalog.CatAll, StringComparison.Ordinal))
            {
                ResetAllGlobal();
                return;
            }

            foreach (GlobalSettingMeta meta in TrajectoryCatalog.GlobalSettings)
            {
                if (string.Equals(meta.Category, selectedCat, StringComparison.Ordinal))
                    meta.Setter(_config, meta.VanillaValue);
            }

            if (string.Equals(selectedCat, TrajectoryCatalog.CatArty, StringComparison.Ordinal))
                _config.ARTILLERY_DISPERSION_CDF = TrajectoryConfig.DefaultArtilleryCurve();

            if (string.Equals(selectedCat, TrajectoryCatalog.CatCruise, StringComparison.Ordinal))
            {
                _config.CRUISE_MISSILE_PID = new[] { 0.2f, 0f, 13f };
                _config.CRUISE_MISSILE_HEIGHTS_COEFFICIENTS = TrajectoryConfig.DefaultCruiseCurve();
            }

            SyncGlobalControls();
            MarkGlobalDirty();
        }

        private void ResetAllGlobal()
        {
            _config = new TrajectoryConfig();
            SyncGlobalControls();
            MarkGlobalDirty();
        }

        private void SaveGlobalConfig()
        {
            try
            {
                CommitAllPendingEdits();
                _config.Save(_globalConfigPath);
                _globalDirty = false;
                SetGlobalStatusAll($"Сохранено {DateTime.Now:HH:mm:ss} — мод подхватит автоматически", Color.ForestGreen);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения {_globalConfigPath}:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CommitAllPendingEdits()
        {
            Validate();
            _dgvGlobal?.EndEdit();
            _dgvCurve?.EndEdit();
            _dgvAmmo?.EndEdit();
            _planesTabCtrl?.CommitPendingEdits();
            _supplyTabCtrl?.CommitPendingEdits();
            _formulasTabCtrl?.CommitPendingEdits();
            _customTrajCtrl?.CommitPendingEdits();
        }

        private void MarkGlobalDirty() => MarkGlobalDirty(true, true);

        private void MarkGlobalDirty(bool refreshFormulaRef = true, bool refreshCustomTraj = true)
        {
            _globalDirty = true;
            if (refreshFormulaRef)
                _formulaRefCtrl?.RefreshFromConfigExternal(_config);
            if (refreshCustomTraj)
                _customTrajCtrl?.BindConfig(_config);
            RefreshAmmoGridPrecisionColumn();
            SetGlobalStatusAll("Есть несохранённые изменения *", Color.DarkOrange);
        }

        private void RefreshAmmoGridPrecisionColumn()
        {
            if (_ammoArray == null || _dgvAmmo == null || !_dgvAmmo.Columns.Contains("PrecisionStrike"))
                return;

            _suppressAmmoEvents = true;
            try
            {
                foreach (DataGridViewRow row in _dgvAmmo.Rows)
                {
                    if (row.Tag is int idx && idx >= 0 && idx < _ammoArray.Count && _ammoArray[idx] is JsonObject obj)
                    {
                        int ammoId = ReadInt(obj, "Id");
                        int tt = ReadInt(obj, "TrajectoryType");
                        bool laser = ReadBool(obj, "LaserGuided");
                        row.Cells["PrecisionStrike"].Value = IsEffectivePrecision(ammoId, tt, laser);
                    }
                }
            }
            finally
            {
                _suppressAmmoEvents = false;
            }
        }

        private void SetGlobalStatusAll(string text, Color color)
        {
            _lblGlobalStatus.Text = text;
            _lblGlobalStatus.ForeColor = color;
            _planesTabCtrl?.SetStatus(text, color);
            _supplyTabCtrl?.SetStatus(text, color);
            _formulasTabCtrl?.SetStatus(text, color);
            _formulaRefCtrl?.SetStatus(text, color);
            _customTrajCtrl?.SetStatus(text, color);
        }

        private void OnSyncCustomTrajectoryToAmmoJson(WeaponTrajectoryAssignmentDto assignment, CustomTrajectoryDto customTraj)
        {
            if (_ammoArray == null || assignment == null || customTraj == null)
                return;

            foreach (JsonNode node in _ammoArray)
            {
                if (node is JsonObject obj && ReadInt(obj, "Id") == assignment.AmmunitionId)
                {
                    obj["TrajectoryType"] = customTraj.BaseTrajectoryType;
                    _ammoDirty = true;
                    break;
                }
            }

            RebuildAmmoFilterOptions();
            RefreshAmmoGrid();
        }

        private void OpenOtherAmmoJson()
        {
            using var dlg = new OpenFileDialog
            {
                Title = "Выберите Ammunitions.json",
                Filter = "JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*",
                InitialDirectory = File.Exists(_ammoPath) ? Path.GetDirectoryName(_ammoPath) : _gameRoot
            };
            if (dlg.ShowDialog(this) == DialogResult.OK)
                LoadAmmunitionsFromDisk(dlg.FileName, silentMissing: false);
        }

        private void LoadAmmunitionsFromDisk(string path, bool silentMissing)
        {
            _ammoPath = path;
            if (!File.Exists(path))
            {
                _ammoArray = null;
                _lblAmmoFile.Text = $"Не найден: {path}";
                _lblAmmoFile.ForeColor = Color.DarkOrange;
                RebuildAmmoFilterOptions();
                RefreshAmmoGrid();
                if (!silentMissing)
                    MessageBox.Show($"Файл не найден:\n{path}", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                JsonNode parsed = JsonNode.Parse(File.ReadAllText(path));
                if (parsed is not JsonArray arr)
                    throw new InvalidDataException("Ожидался JSON-массив боеприпасов.");

                _ammoArray = arr;
                _ammoDirty = false;
                _lblAmmoFile.Text = $"Файл: {path}";
                _lblAmmoFile.ForeColor = Color.DimGray;
                RebuildAmmoFilterOptions();
                RefreshAmmoGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки {path}:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RebuildAmmoFilterOptions()
        {
            _suppressAmmoFilterEvents = true;
            try
            {
                int prevFilter = (_cmbAmmoTypeFilter.SelectedItem as NamedIntOption)?.Value ?? -1;
                _cmbAmmoTypeFilter.Items.Clear();

                int total = _ammoArray?.Count ?? 0;
                _cmbAmmoTypeFilter.Items.Add(new NamedIntOption(-1, $"Все типы ({total})"));

                var counts = new Dictionary<int, int>();
                if (_ammoArray != null)
                {
                    foreach (JsonNode node in _ammoArray)
                    {
                        if (node is JsonObject obj)
                        {
                            int tt = ReadInt(obj, "TrajectoryType");
                            counts[tt] = counts.TryGetValue(tt, out int c) ? c + 1 : 1;
                        }
                    }
                }

                foreach (NamedIntOption opt in TrajectoryCatalog.TrajectoryTypes)
                {
                    int c = counts.TryGetValue(opt.Value, out int n) ? n : 0;
                    _cmbAmmoTypeFilter.Items.Add(new NamedIntOption(opt.Value, $"{opt.Label} [{c}]"));
                }

                int matchIdx = 0;
                for (int i = 0; i < _cmbAmmoTypeFilter.Items.Count; i++)
                {
                    if (_cmbAmmoTypeFilter.Items[i] is NamedIntOption opt && opt.Value == prevFilter)
                    {
                        matchIdx = i;
                        break;
                    }
                }
                _cmbAmmoTypeFilter.SelectedIndex = matchIdx;
            }
            finally
            {
                _suppressAmmoFilterEvents = false;
            }
        }

        private void RefreshAmmoGrid()
        {
            _suppressAmmoEvents = true;
            try
            {
                _filteredAmmoIndices.Clear();
                _dgvAmmo.Rows.Clear();
                _selectedAmmoIndex = -1;

                if (_ammoArray == null)
                {
                    _lblAmmoCount.Text = "0 записей";
                    return;
                }

                int typeFilter = (_cmbAmmoTypeFilter.SelectedItem as NamedIntOption)?.Value ?? -1;
                string search = (_txtAmmoSearch.Text ?? string.Empty).Trim();

                for (int i = 0; i < _ammoArray.Count; i++)
                {
                    if (_ammoArray[i] is not JsonObject obj)
                        continue;

                    int tt = ReadInt(obj, "TrajectoryType");
                    if (typeFilter >= 0 && tt != typeFilter)
                        continue;

                    if (!string.IsNullOrEmpty(search))
                    {
                        string idStr = obj["Id"]?.ToString() ?? string.Empty;
                        string nameStr = obj["Name"]?.ToString() ?? string.Empty;
                        string hudStr = obj["HUDName"]?.ToString() ?? string.Empty;
                        if (idStr.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0 &&
                            nameStr.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0 &&
                            hudStr.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0)
                            continue;
                    }

                    int ammoId = ReadInt(obj, "Id");
                    int seeker = ReadInt(obj, "Seeker");
                    EnsureComboOption("TrajectoryType", tt);
                    EnsureComboOption("Seeker", seeker);

                    _filteredAmmoIndices.Add(i);
                    int rIdx = _dgvAmmo.Rows.Add();
                    DataGridViewRow row = _dgvAmmo.Rows[rIdx];
                    row.Tag = i;
                    row.Cells["Id"].Value = ammoId;
                    row.Cells["Name"].Value = obj["Name"]?.ToString() ?? "";
                    SyncAmmoGridRow(row, obj);
                }

                _lblAmmoCount.Text = $"Показано {_filteredAmmoIndices.Count} из {_ammoArray.Count}" + (_ammoDirty ? " *" : "");
            }
            finally
            {
                _suppressAmmoEvents = false;
            }

            if (_dgvAmmo.Rows.Count > 0)
            {
                _dgvAmmo.Rows[0].Selected = true;
                OnAmmoSelectionChanged();
            }
            else
            {
                LoadSelectedAmmoToInspector();
            }
        }

        private void EnsureComboOption(string colName, int val)
        {
            if (_dgvAmmo.Columns[colName] is DataGridViewComboBoxColumn col &&
                col.DataSource is List<NamedIntOption> opts &&
                opts.All(o => o.Value != val))
            {
                opts.Add(new NamedIntOption(val, $"{val} — (нестандартный)"));
                col.DataSource = null;
                col.DataSource = opts;
                col.DisplayMember = nameof(NamedIntOption.Label);
                col.ValueMember = nameof(NamedIntOption.Value);
            }
        }

        private bool IsEffectivePrecision(int ammoId, int tt, bool laser)
        {
            if (tt == 200 || tt == 300 || ((tt == 400 || tt == 410) && laser))
                return true;
            if (_config.PrecisionStrikeAmmoIds.Contains(ammoId))
                return true;
            foreach (WeaponTrajectoryAssignmentDto a in _config.WeaponTrajectoryAssignments)
            {
                if (a.AmmunitionId == ammoId)
                {
                    CustomTrajectoryDto ct = _config.CustomTrajectories.FirstOrDefault(t => t.Id == a.CustomTrajectoryId);
                    if (ct != null && ct.AllowPrecisionStrike)
                        return true;
                }
            }
            return false;
        }

        private void OnAmmoGridCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_suppressAmmoEvents || e.RowIndex < 0 || e.ColumnIndex < 0 || _ammoArray == null)
                return;

            DataGridViewRow row = _dgvAmmo.Rows[e.RowIndex];
            if (row.Tag is not int idx || idx < 0 || idx >= _ammoArray.Count || _ammoArray[idx] is not JsonObject obj)
                return;

            string colName = _dgvAmmo.Columns[e.ColumnIndex].Name;
            object raw = row.Cells[e.ColumnIndex].Value;
            int ammoId = ReadInt(obj, "Id");

            if (string.Equals(colName, "PrecisionStrike", StringComparison.Ordinal))
            {
                bool want = Convert.ToBoolean(raw, CultureInfo.InvariantCulture);
                int tt = ReadInt(obj, "TrajectoryType");
                bool laser = ReadBool(obj, "LaserGuided");
                bool isNativePrec = tt == 200 || tt == 300 || ((tt == 400 || tt == 410) && laser);

                if (want)
                {
                    if (!_config.PrecisionStrikeAmmoIds.Contains(ammoId))
                        _config.PrecisionStrikeAmmoIds.Add(ammoId);
                }
                else
                {
                    _config.PrecisionStrikeAmmoIds.Remove(ammoId);
                    if (isNativePrec)
                    {
                        MessageBox.Show(
                            "Для типа 200/300 или 400/410 с LaserGuided=true игра всегда разрешает Precision Strike автоматически.",
                            "Встроенный Precision Strike",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }

                _suppressAmmoEvents = true;
                try { row.Cells["PrecisionStrike"].Value = IsEffectivePrecision(ammoId, tt, laser); }
                finally { _suppressAmmoEvents = false; }

                MarkGlobalDirty(refreshFormulaRef: false, refreshCustomTraj: true);
                return;
            }

            string metaKey = string.Equals(colName, "DispersionH", StringComparison.Ordinal)
                ? "DispersionHorizontalRadius"
                : colName;

            AmmoFieldMeta meta = TrajectoryCatalog.AmmoFields.FirstOrDefault(f => string.Equals(f.Name, metaKey, StringComparison.Ordinal));
            if (meta == null)
                return;

            object parsedVal = null;
            bool ok = true;
            if (meta.IsBool)
            {
                parsedVal = Convert.ToBoolean(raw, CultureInfo.InvariantCulture);
            }
            else if (meta.IsTrajectoryEnum || meta.IsSeekerEnum || meta.IsInt)
            {
                if (raw is int iv) parsedVal = iv;
                else if (TryParseInt(Convert.ToString(raw, CultureInfo.InvariantCulture), out int pInt)) parsedVal = pInt;
                else ok = false;
            }
            else
            {
                if (TryParseDouble(Convert.ToString(raw, CultureInfo.InvariantCulture), out double dVal)) parsedVal = dVal;
                else ok = false;
            }

            if (!ok)
            {
                _suppressAmmoEvents = true;
                try { SyncAmmoGridRow(row, obj); }
                finally { _suppressAmmoEvents = false; }
                return;
            }

            WriteFieldToJsonObject(obj, meta, parsedVal);
            _ammoDirty = true;

            _suppressAmmoEvents = true;
            try { SyncAmmoGridRow(row, obj); }
            finally { _suppressAmmoEvents = false; }

            if (meta.IsTrajectoryEnum)
                RebuildAmmoFilterOptions();

            if (idx == _selectedAmmoIndex)
                LoadSelectedAmmoToInspector();

            _lblAmmoCount.Text = $"Показано {_filteredAmmoIndices.Count} из {_ammoArray.Count} *";
        }

        private void OnAmmoSelectionChanged()
        {
            if (_suppressAmmoEvents)
                return;

            if (_dgvAmmo.CurrentRow != null && _dgvAmmo.CurrentRow.Tag is int idx)
                _selectedAmmoIndex = idx;
            else if (_dgvAmmo.SelectedRows.Count > 0 && _dgvAmmo.SelectedRows[0].Tag is int sidx)
                _selectedAmmoIndex = sidx;
            else
                _selectedAmmoIndex = -1;

            LoadSelectedAmmoToInspector();
        }

        private void LoadSelectedAmmoToInspector()
        {
            _suppressAmmoEvents = true;
            try
            {
                JsonObject obj = (_ammoArray != null && _selectedAmmoIndex >= 0 && _selectedAmmoIndex < _ammoArray.Count)
                    ? _ammoArray[_selectedAmmoIndex] as JsonObject
                    : null;

                foreach (AmmoFieldMeta meta in TrajectoryCatalog.AmmoFields)
                {
                    if (!_ammoFieldControls.TryGetValue(meta.Name, out Control ctrl))
                        continue;

                    ctrl.Enabled = obj != null;
                    if (obj == null)
                        continue;

                    if (ctrl is ComboBox cmb)
                    {
                        int v = ReadInt(obj, meta.Name);
                        int found = -1;
                        for (int i = 0; i < cmb.Items.Count; i++)
                        {
                            if (cmb.Items[i] is NamedIntOption opt && opt.Value == v)
                            {
                                found = i;
                                break;
                            }
                        }
                        cmb.SelectedIndex = found;
                    }
                    else if (ctrl is CheckBox chk)
                    {
                        chk.Checked = ReadBool(obj, meta.Name);
                    }
                    else if (ctrl is TextBox tb)
                    {
                        tb.Text = FormatDouble(ReadDouble(obj, meta.Name));
                    }
                }
            }
            finally
            {
                _suppressAmmoEvents = false;
            }
        }

        private void CommitSingleAmmoField(AmmoFieldMeta meta, object value)
        {
            if (_ammoArray == null || _selectedAmmoIndex < 0 || _selectedAmmoIndex >= _ammoArray.Count)
                return;

            if (_ammoArray[_selectedAmmoIndex] is not JsonObject obj)
                return;

            WriteFieldToJsonObject(obj, meta, value);
            _ammoDirty = true;

            if (_dgvAmmo.CurrentRow != null && _dgvAmmo.CurrentRow.Tag is int rowAmmoIdx && rowAmmoIdx == _selectedAmmoIndex)
            {
                _suppressAmmoEvents = true;
                try { SyncAmmoGridRow(_dgvAmmo.CurrentRow, obj); }
                finally { _suppressAmmoEvents = false; }
            }

            if (meta.IsTrajectoryEnum)
                RebuildAmmoFilterOptions();

            _lblAmmoCount.Text = $"Показано {_filteredAmmoIndices.Count} из {_ammoArray.Count} *";
        }

        private void ApplyBatchEdit(bool toAllFiltered)
        {
            if (_ammoArray == null || _cmbBatchField.SelectedItem is not string fieldName)
                return;

            AmmoFieldMeta meta = TrajectoryCatalog.AmmoFields.FirstOrDefault(f => f.Name == fieldName);
            if (meta == null)
                return;

            var targetRows = new List<DataGridViewRow>();
            if (toAllFiltered)
            {
                foreach (DataGridViewRow r in _dgvAmmo.Rows) targetRows.Add(r);
            }
            else
            {
                foreach (DataGridViewRow r in _dgvAmmo.SelectedRows) targetRows.Add(r);
            }

            if (targetRows.Count == 0)
            {
                MessageBox.Show("Нет строк для массового редактирования.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int opIndex = _cmbBatchOp.SelectedIndex; // 0 = Set, 1 = Mul, 2 = Add
            string rawText = (_txtBatchVal.Text ?? string.Empty).Trim();

            if (meta.IsBool)
            {
                if (opIndex != 0)
                {
                    MessageBox.Show("Для флагов (bool) поддерживается только операция «Установить =» (true/false или 1/0).", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (!TryParseFlexBool(rawText, out bool bVal))
                {
                    MessageBox.Show("Введите true/false или 1/0.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show($"Применить {meta.Name} = {bVal} к {targetRows.Count} боеприпасам?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;

                _suppressAmmoEvents = true;
                try
                {
                    foreach (DataGridViewRow r in targetRows)
                    {
                        if (r.Tag is int idx && _ammoArray[idx] is JsonObject obj)
                        {
                            WriteFieldToJsonObject(obj, meta, bVal);
                            SyncAmmoGridRow(r, obj);
                        }
                    }
                }
                finally
                {
                    _suppressAmmoEvents = false;
                }
            }
            else
            {
                if (!TryParseDouble(rawText, out double dVal))
                {
                    MessageBox.Show("Введите корректное числовое значение.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string opName = opIndex switch { 1 => "×", 2 => "+", _ => "=" };
                if (MessageBox.Show($"Применить {meta.Name} {opName} {dVal.ToString("G", CultureInfo.InvariantCulture)} к {targetRows.Count} боеприпасам?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;

                _suppressAmmoEvents = true;
                try
                {
                    foreach (DataGridViewRow r in targetRows)
                    {
                        if (r.Tag is int idx && _ammoArray[idx] is JsonObject obj)
                        {
                            double cur = ReadDouble(obj, meta.Name);
                            double next = opIndex switch
                            {
                                1 => cur * dVal,
                                2 => cur + dVal,
                                _ => dVal
                            };
                            WriteFieldToJsonObject(obj, meta, next);
                            SyncAmmoGridRow(r, obj);
                        }
                    }
                }
                finally
                {
                    _suppressAmmoEvents = false;
                }
            }

            _ammoDirty = true;
            if (meta.IsTrajectoryEnum)
                RebuildAmmoFilterOptions();
            LoadSelectedAmmoToInspector();
            _lblAmmoCount.Text = $"Показано {_filteredAmmoIndices.Count} из {_ammoArray.Count} *";
        }

        private void SyncAmmoGridRow(DataGridViewRow r, JsonObject obj)
        {
            int ammoId = ReadInt(obj, "Id");
            int tt = ReadInt(obj, "TrajectoryType");
            int seeker = ReadInt(obj, "Seeker");
            bool laser = ReadBool(obj, "LaserGuided");

            EnsureComboOption("TrajectoryType", tt);
            EnsureComboOption("Seeker", seeker);

            r.Cells["TrajectoryType"].Value = tt;
            r.Cells["Seeker"].Value = seeker;
            r.Cells["GroundRange"].Value = FormatDouble(ReadDouble(obj, "GroundRange"));
            r.Cells["MuzzleVelocity"].Value = FormatDouble(ReadDouble(obj, "MuzzleVelocity"));
            r.Cells["MaxSpeed"].Value = FormatDouble(ReadDouble(obj, "MaxSpeed"));
            r.Cells["DispersionH"].Value = FormatDouble(ReadDouble(obj, "DispersionHorizontalRadius"));
            r.Cells["LaserGuided"].Value = laser;
            r.Cells["TopArmorAttack"].Value = ReadBool(obj, "TopArmorAttack");
            r.Cells["PrecisionStrike"].Value = IsEffectivePrecision(ammoId, tt, laser);
        }

        private void SaveAmmunitionsToDisk()
        {
            if (_ammoArray == null || string.IsNullOrEmpty(_ammoPath))
                return;

            try
            {
                Validate();
                _dgvAmmo?.EndEdit();
                string bakPath = _ammoPath + ".bak";
                if (File.Exists(_ammoPath) && !File.Exists(bakPath))
                    File.Copy(_ammoPath, bakPath, overwrite: false);

                string json = _ammoArray.ToJsonString(PrettyJsonOpts);
                string tmpPath = _ammoPath + ".tmp";
                File.WriteAllText(tmpPath, json);
                File.Move(tmpPath, _ammoPath, overwrite: true);
                _ammoDirty = false;
                _lblAmmoCount.Text = $"Показано {_filteredAmmoIndices.Count} из {_ammoArray.Count} (сохранено {DateTime.Now:HH:mm:ss} — мод подхватит автоматически)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения {_ammoPath}:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CreateManualBackup()
        {
            if (string.IsNullOrEmpty(_ammoPath) || !File.Exists(_ammoPath))
                return;

            string bakPath = _ammoPath + ".bak";
            File.Copy(_ammoPath, bakPath, overwrite: true);
            MessageBox.Show($"Бэкап обновлён:\n{bakPath}", "Бэкап", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void RestoreFromBackup()
        {
            if (string.IsNullOrEmpty(_ammoPath))
                return;

            string bakPath = _ammoPath + ".bak";
            if (!File.Exists(bakPath))
            {
                MessageBox.Show($"Файл бэкапа не найден:\n{bakPath}", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Восстановить {_ammoPath} из бэкапа?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            File.Copy(bakPath, _ammoPath, overwrite: true);
            LoadAmmunitionsFromDisk(_ammoPath, silentMissing: false);
        }

        private static int ReadInt(JsonObject obj, string key)
        {
            JsonNode n = obj[key];
            if (n == null) return 0;
            if (n is JsonValue v && v.TryGetValue<double>(out double d))
                return (int)Math.Round(d);
            return TryParseInt(n.ToString(), out int i) ? i : 0;
        }

        private static double ReadDouble(JsonObject obj, string key)
        {
            JsonNode n = obj[key];
            if (n == null) return 0.0;
            if (n is JsonValue v && v.TryGetValue<double>(out double d))
                return d;
            return TryParseDouble(n.ToString(), out double r) ? r : 0.0;
        }

        private static bool ReadBool(JsonObject obj, string key)
        {
            JsonNode n = obj[key];
            if (n == null) return false;
            if (n is JsonValue v && v.TryGetValue<bool>(out bool b))
                return b;
            return TryParseFlexBool(n.ToString(), out bool rb) && rb;
        }

        private static void WriteFieldToJsonObject(JsonObject obj, AmmoFieldMeta meta, object value)
        {
            if (meta.IsBool)
            {
                obj[meta.Name] = Convert.ToBoolean(value, CultureInfo.InvariantCulture);
                return;
            }

            double d = Convert.ToDouble(value, CultureInfo.InvariantCulture);
            if (meta.IsInt)
            {
                obj[meta.Name] = (int)Math.Round(d);
                return;
            }

            if (Math.Abs(d - Math.Round(d)) < 1e-6 && d >= long.MinValue && d <= long.MaxValue)
                obj[meta.Name] = (long)Math.Round(d);
            else
                obj[meta.Name] = Math.Round(d, 6);
        }

        private static bool TryParseDouble(string text, out double value)
        {
            string norm = (text ?? string.Empty).Trim().Replace(',', '.');
            return double.TryParse(norm, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }

        private static bool TryParseFloat(string text, out float value)
        {
            string norm = (text ?? string.Empty).Trim().Replace(',', '.');
            return float.TryParse(norm, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }

        private static bool TryParseInt(string text, out int value)
        {
            return int.TryParse((text ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
        }

        private static bool TryParseFlexBool(string text, out bool value)
        {
            string s = (text ?? string.Empty).Trim().ToLowerInvariant();
            if (s == "true" || s == "1" || s == "да" || s == "yes") { value = true; return true; }
            if (s == "false" || s == "0" || s == "нет" || s == "no") { value = false; return true; }
            value = false;
            return false;
        }

        private static string FormatNumber(object val) => val switch
        {
            float f => f.ToString("G9", CultureInfo.InvariantCulture),
            int i => i.ToString(CultureInfo.InvariantCulture),
            byte b => b.ToString(CultureInfo.InvariantCulture),
            _ => Convert.ToString(val, CultureInfo.InvariantCulture) ?? ""
        };

        private static string FormatDouble(double d)
        {
            if (Math.Abs(d - Math.Round(d)) < 1e-6)
                return ((long)Math.Round(d)).ToString(CultureInfo.InvariantCulture);
            return Math.Round(d, 6).ToString("G12", CultureInfo.InvariantCulture);
        }

        private static bool AreValuesEqual(object a, object b, SettingValueKind kind)
        {
            if (kind == SettingValueKind.Bool)
                return Convert.ToBoolean(a, CultureInfo.InvariantCulture) == Convert.ToBoolean(b, CultureInfo.InvariantCulture);
            if (kind == SettingValueKind.Int || kind == SettingValueKind.SwitchRuleEnum)
                return Convert.ToInt32(a, CultureInfo.InvariantCulture) == Convert.ToInt32(b, CultureInfo.InvariantCulture);
            return Math.Abs(Convert.ToSingle(a, CultureInfo.InvariantCulture) - Convert.ToSingle(b, CultureInfo.InvariantCulture)) < 1e-5f;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_globalDirty || _ammoDirty)
            {
                DialogResult res = MessageBox.Show(
                    "Есть несохранённые изменения. Закрыть программу без сохранения?",
                    "Несохранённые изменения",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);
                if (res != DialogResult.Yes)
                    e.Cancel = true;
            }
            base.OnFormClosing(e);
        }
    }
}
