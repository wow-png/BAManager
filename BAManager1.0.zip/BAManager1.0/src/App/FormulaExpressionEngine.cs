using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace TrajectoryEditorShared
{
    public sealed class CompiledExpression
    {
        private readonly ExprNode _root;
        public string Source { get; }

        internal CompiledExpression(string source, ExprNode root)
        {
            Source = source;
            _root = root;
        }

        public double Evaluate(IReadOnlyDictionary<string, double> vars)
        {
            if (vars == null)
                return Sanitize(_root.Eval(_ => 0.0));
            return Sanitize(_root.Eval(name => vars.TryGetValue(name, out double v) ? v : 0.0));
        }

        public double Evaluate(Func<string, double> resolver)
        {
            return Sanitize(_root.Eval(resolver ?? (_ => 0.0)));
        }

        public IReadOnlyList<string> GetReferencedVariables()
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            _root.CollectVars(set);
            var list = new List<string>(set);
            list.Sort(StringComparer.OrdinalIgnoreCase);
            return list;
        }

        internal static double Sanitize(double v) => (double.IsNaN(v) || double.IsInfinity(v)) ? 0.0 : v;
    }

    internal abstract class ExprNode
    {
        public abstract double Eval(Func<string, double> resolver);
        public virtual void CollectVars(HashSet<string> vars) { }
    }

    internal sealed class NumberNode : ExprNode
    {
        private readonly double _val;
        public NumberNode(double val) => _val = val;
        public override double Eval(Func<string, double> resolver) => _val;
    }

    internal sealed class VarNode : ExprNode
    {
        private readonly string _name;
        public VarNode(string name) => _name = name;
        public override double Eval(Func<string, double> resolver) => CompiledExpression.Sanitize(resolver(_name));
        public override void CollectVars(HashSet<string> vars) => vars.Add(_name);
    }

    internal sealed class UnaryNode : ExprNode
    {
        private readonly char _op;
        private readonly ExprNode _operand;
        public UnaryNode(char op, ExprNode operand) { _op = op; _operand = operand; }

        public override double Eval(Func<string, double> resolver)
        {
            double v = _operand.Eval(resolver);
            return _op switch
            {
                '-' => -v,
                '+' => v,
                '!' => Math.Abs(v) < 1e-12 ? 1.0 : 0.0,
                _ => v
            };
        }

        public override void CollectVars(HashSet<string> vars) => _operand.CollectVars(vars);
    }

    internal sealed class BinaryNode : ExprNode
    {
        private readonly string _op;
        private readonly ExprNode _left;
        private readonly ExprNode _right;

        public BinaryNode(string op, ExprNode left, ExprNode right)
        {
            _op = op;
            _left = left;
            _right = right;
        }

        public override double Eval(Func<string, double> resolver)
        {
            if (_op == "&&")
                return Math.Abs(_left.Eval(resolver)) >= 1e-12 && Math.Abs(_right.Eval(resolver)) >= 1e-12 ? 1.0 : 0.0;
            if (_op == "||")
                return Math.Abs(_left.Eval(resolver)) >= 1e-12 || Math.Abs(_right.Eval(resolver)) >= 1e-12 ? 1.0 : 0.0;

            double a = _left.Eval(resolver);
            double b = _right.Eval(resolver);

            return _op switch
            {
                "+" => a + b,
                "-" => a - b,
                "*" => a * b,
                "/" => Math.Abs(b) < 1e-15 ? 0.0 : a / b,
                "%" => Math.Abs(b) < 1e-15 ? 0.0 : a % b,
                "^" => SafePow(a, b),
                "<" => a < b ? 1.0 : 0.0,
                "<=" => a <= b ? 1.0 : 0.0,
                ">" => a > b ? 1.0 : 0.0,
                ">=" => a >= b ? 1.0 : 0.0,
                "==" => Math.Abs(a - b) < 1e-9 ? 1.0 : 0.0,
                "!=" => Math.Abs(a - b) >= 1e-9 ? 1.0 : 0.0,
                _ => 0.0
            };
        }

        internal static double SafePow(double a, double b)
        {
            if (a < 0.0 && Math.Abs(b - Math.Round(b)) > 1e-9)
                return 0.0;
            double res = Math.Pow(a, b);
            return CompiledExpression.Sanitize(res);
        }

        public override void CollectVars(HashSet<string> vars)
        {
            _left.CollectVars(vars);
            _right.CollectVars(vars);
        }
    }

    internal sealed class TernaryNode : ExprNode
    {
        private readonly ExprNode _cond;
        private readonly ExprNode _t;
        private readonly ExprNode _f;

        public TernaryNode(ExprNode cond, ExprNode t, ExprNode f)
        {
            _cond = cond;
            _t = t;
            _f = f;
        }

        public override double Eval(Func<string, double> resolver) =>
            Math.Abs(_cond.Eval(resolver)) >= 1e-12 ? _t.Eval(resolver) : _f.Eval(resolver);

        public override void CollectVars(HashSet<string> vars)
        {
            _cond.CollectVars(vars);
            _t.CollectVars(vars);
            _f.CollectVars(vars);
        }
    }

    internal sealed class CallNode : ExprNode
    {
        private readonly string _name;
        private readonly ExprNode[] _args;

        public CallNode(string name, ExprNode[] args)
        {
            _name = name;
            _args = args;
        }

        public override double Eval(Func<string, double> resolver)
        {
            switch (_name)
            {
                case "min": return Math.Min(_args[0].Eval(resolver), _args[1].Eval(resolver));
                case "max": return Math.Max(_args[0].Eval(resolver), _args[1].Eval(resolver));
                case "clamp":
                {
                    double x = _args[0].Eval(resolver);
                    double lo = _args[1].Eval(resolver);
                    double hi = _args[2].Eval(resolver);
                    if (lo > hi) (lo, hi) = (hi, lo);
                    return Math.Clamp(x, lo, hi);
                }
                case "clamp01": return Math.Clamp(_args[0].Eval(resolver), 0.0, 1.0);
                case "abs": return Math.Abs(_args[0].Eval(resolver));
                case "sqrt":
                {
                    double x = _args[0].Eval(resolver);
                    return x < 0.0 ? 0.0 : Math.Sqrt(x);
                }
                case "pow": return BinaryNode.SafePow(_args[0].Eval(resolver), _args[1].Eval(resolver));
                case "sin": return Math.Sin(_args[0].Eval(resolver));
                case "cos": return Math.Cos(_args[0].Eval(resolver));
                case "tan": return CompiledExpression.Sanitize(Math.Tan(_args[0].Eval(resolver)));
                case "asin": return Math.Asin(Math.Clamp(_args[0].Eval(resolver), -1.0, 1.0));
                case "acos": return Math.Acos(Math.Clamp(_args[0].Eval(resolver), -1.0, 1.0));
                case "atan": return Math.Atan(_args[0].Eval(resolver));
                case "exp": return CompiledExpression.Sanitize(Math.Exp(Math.Clamp(_args[0].Eval(resolver), -500.0, 500.0)));
                case "log":
                {
                    double x = _args[0].Eval(resolver);
                    return x <= 0.0 ? 0.0 : Math.Log(x);
                }
                case "floor": return Math.Floor(_args[0].Eval(resolver));
                case "ceil": return Math.Ceiling(_args[0].Eval(resolver));
                case "round": return Math.Round(_args[0].Eval(resolver));
                case "sign": return Math.Sign(_args[0].Eval(resolver));
                case "lerp":
                {
                    double a = _args[0].Eval(resolver);
                    double b = _args[1].Eval(resolver);
                    double t = _args[2].Eval(resolver);
                    return a + (b - a) * t;
                }
                case "if":
                    return Math.Abs(_args[0].Eval(resolver)) >= 1e-12 ? _args[1].Eval(resolver) : _args[2].Eval(resolver);
                default:
                    return 0.0;
            }
        }

        public override void CollectVars(HashSet<string> vars)
        {
            foreach (ExprNode a in _args)
                a.CollectVars(vars);
        }
    }

    public static class FormulaExpressionEngine
    {
        private static readonly Dictionary<string, int> FunctionArity = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
        {
            ["min"] = 2,
            ["max"] = 2,
            ["clamp"] = 3,
            ["clamp01"] = 1,
            ["abs"] = 1,
            ["sqrt"] = 1,
            ["pow"] = 2,
            ["sin"] = 1,
            ["cos"] = 1,
            ["tan"] = 1,
            ["asin"] = 1,
            ["acos"] = 1,
            ["atan"] = 1,
            ["exp"] = 1,
            ["log"] = 1,
            ["floor"] = 1,
            ["ceil"] = 1,
            ["round"] = 1,
            ["sign"] = 1,
            ["lerp"] = 3,
            ["if"] = 3
        };

        public static bool TryCompile(string expression, out CompiledExpression compiled, out string error)
        {
            compiled = null;
            if (string.IsNullOrWhiteSpace(expression))
            {
                error = "Пустое выражение.";
                return false;
            }

            try
            {
                var parser = new Parser(expression);
                ExprNode root = parser.ParseRoot();
                compiled = new CompiledExpression(expression, root);
                error = null;
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private sealed class Parser
        {
            private readonly string _s;
            private int _pos;

            public Parser(string s) => _s = s;

            public ExprNode ParseRoot()
            {
                SkipWs();
                ExprNode node = ParseTernary();
                SkipWs();
                if (_pos < _s.Length)
                    throw new FormatException($"Неожиданный символ '{_s[_pos]}' в позиции {_pos + 1}.");
                return node;
            }

            private void SkipWs()
            {
                while (_pos < _s.Length && char.IsWhiteSpace(_s[_pos]))
                    _pos++;
            }

            private bool Match(string op)
            {
                SkipWs();
                if (_pos + op.Length > _s.Length)
                    return false;
                for (int i = 0; i < op.Length; i++)
                {
                    if (_s[_pos + i] != op[i])
                        return false;
                }
                if (op.Length == 1 && _pos + 1 < _s.Length)
                {
                    char next = _s[_pos + 1];
                    if ((op == "<" || op == ">" || op == "!") && next == '=')
                        return false;
                    if (op == "=" && next == '=')
                        return false;
                }
                _pos += op.Length;
                return true;
            }

            private ExprNode ParseTernary()
            {
                ExprNode cond = ParseOr();
                if (Match("?"))
                {
                    ExprNode whenTrue = ParseTernary();
                    if (!Match(":"))
                        throw new FormatException($"Ожидалось ':' в тернарном операторе (поз. {_pos + 1}).");
                    ExprNode whenFalse = ParseTernary();
                    return new TernaryNode(cond, whenTrue, whenFalse);
                }
                return cond;
            }

            private ExprNode ParseOr()
            {
                ExprNode left = ParseAnd();
                while (Match("||"))
                    left = new BinaryNode("||", left, ParseAnd());
                return left;
            }

            private ExprNode ParseAnd()
            {
                ExprNode left = ParseEquality();
                while (Match("&&"))
                    left = new BinaryNode("&&", left, ParseEquality());
                return left;
            }

            private ExprNode ParseEquality()
            {
                ExprNode left = ParseComparison();
                while (true)
                {
                    if (Match("==")) left = new BinaryNode("==", left, ParseComparison());
                    else if (Match("!=")) left = new BinaryNode("!=", left, ParseComparison());
                    else break;
                }
                return left;
            }

            private ExprNode ParseComparison()
            {
                ExprNode left = ParseAddSub();
                while (true)
                {
                    if (Match("<=")) left = new BinaryNode("<=", left, ParseAddSub());
                    else if (Match(">=")) left = new BinaryNode(">=", left, ParseAddSub());
                    else if (Match("<")) left = new BinaryNode("<", left, ParseAddSub());
                    else if (Match(">")) left = new BinaryNode(">", left, ParseAddSub());
                    else break;
                }
                return left;
            }

            private ExprNode ParseAddSub()
            {
                ExprNode left = ParseMulDiv();
                while (true)
                {
                    if (Match("+")) left = new BinaryNode("+", left, ParseMulDiv());
                    else if (Match("-")) left = new BinaryNode("-", left, ParseMulDiv());
                    else break;
                }
                return left;
            }

            private ExprNode ParseMulDiv()
            {
                ExprNode left = ParsePower();
                while (true)
                {
                    if (Match("*")) left = new BinaryNode("*", left, ParsePower());
                    else if (Match("/")) left = new BinaryNode("/", left, ParsePower());
                    else if (Match("%")) left = new BinaryNode("%", left, ParsePower());
                    else break;
                }
                return left;
            }

            private ExprNode ParsePower()
            {
                ExprNode left = ParseUnary();
                if (Match("^"))
                {
                    ExprNode right = ParsePower();
                    return new BinaryNode("^", left, right);
                }
                return left;
            }

            private ExprNode ParseUnary()
            {
                if (Match("-")) return new UnaryNode('-', ParseUnary());
                if (Match("+")) return new UnaryNode('+', ParseUnary());
                if (Match("!")) return new UnaryNode('!', ParseUnary());
                return ParsePrimary();
            }

            private ExprNode ParsePrimary()
            {
                SkipWs();
                if (_pos >= _s.Length)
                    throw new FormatException("Неожиданный конец формулы.");

                if (Match("("))
                {
                    ExprNode inner = ParseTernary();
                    if (!Match(")"))
                        throw new FormatException($"Не закрыта скобка ')' (поз. {_pos + 1}).");
                    return inner;
                }

                char ch = _s[_pos];
                if (char.IsDigit(ch) || ch == '.')
                    return ParseNumber();

                if (char.IsLetter(ch) || ch == '_')
                    return ParseIdentOrCall();

                throw new FormatException($"Неожиданный символ '{ch}' в позиции {_pos + 1}.");
            }

            private ExprNode ParseNumber()
            {
                int start = _pos;
                bool hasDot = false;
                while (_pos < _s.Length)
                {
                    char c = _s[_pos];
                    if (char.IsDigit(c))
                    {
                        _pos++;
                    }
                    else if (c == '.' && !hasDot)
                    {
                        hasDot = true;
                        _pos++;
                    }
                    else if ((c == 'e' || c == 'E') && _pos > start)
                    {
                        _pos++;
                        if (_pos < _s.Length && (_s[_pos] == '+' || _s[_pos] == '-'))
                            _pos++;
                    }
                    else
                    {
                        break;
                    }
                }

                string token = _s.Substring(start, _pos - start);
                if (!double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out double val))
                    throw new FormatException($"Некорректное число '{token}' (поз. {start + 1}).");

                return new NumberNode(val);
            }

            private ExprNode ParseIdentOrCall()
            {
                int start = _pos;
                while (_pos < _s.Length && (char.IsLetterOrDigit(_s[_pos]) || _s[_pos] == '_'))
                    _pos++;
                string ident = _s.Substring(start, _pos - start);

                if (Match("("))
                {
                    var args = new List<ExprNode>();
                    SkipWs();
                    if (!Match(")"))
                    {
                        while (true)
                        {
                            args.Add(ParseTernary());
                            if (Match(",")) continue;
                            if (Match(")")) break;
                            throw new FormatException($"Ожидалась ',' или ')' в вызове {ident}(...) (поз. {_pos + 1}).");
                        }
                    }

                    if (!FunctionArity.TryGetValue(ident, out int expected))
                        throw new FormatException($"Неизвестная функция '{ident}'.");
                    if (args.Count != expected)
                        throw new FormatException($"Функция '{ident}' требует {expected} арг., передано {args.Count}.");

                    return new CallNode(ident.ToLowerInvariant(), args.ToArray());
                }

                if (string.Equals(ident, "pi", StringComparison.OrdinalIgnoreCase)) return new NumberNode(Math.PI);
                if (string.Equals(ident, "e", StringComparison.OrdinalIgnoreCase)) return new NumberNode(Math.E);
                if (string.Equals(ident, "true", StringComparison.OrdinalIgnoreCase)) return new NumberNode(1.0);
                if (string.Equals(ident, "false", StringComparison.OrdinalIgnoreCase)) return new NumberNode(0.0);

                return new VarNode(ident);
            }
        }
    }
}
